import 'package:carrermagnet/presentation/bookmark_view/bookmark/screens/bookmark_Screen.dart';
import 'package:carrermagnet/presentation/home_view/home_view.dart';
import 'package:carrermagnet/presentation/navigation_view/navigation_view.dart';
import 'package:carrermagnet/presentation/profile_view/profile_create_and_edit_view.dart';
import 'package:carrermagnet/presentation/profile_view/profile_edit_view.dart';
import 'package:carrermagnet/presentation/profile_view/profile_view.dart';
import 'package:carrermagnet/presentation/recruiter_view/recruiter_sign_up.dart';
import 'package:carrermagnet/presentation/sign_up/signup_view.dart';
import 'package:flutter/material.dart';

import '../presentation/add_new_project/add_new_project_view.dart';
import '../presentation/job_detail_view/job_detail_view.dart';
import '../presentation/recruiter_view/add_hiring_announcement_view.dart';
import '../presentation/explore_view/screen/explore_screen.dart';
import '../presentation/login/login_view.dart';
import '../presentation/recruiter_navigation_view/recruiter_navigation_view.dart';
import '../presentation/recruiter_view/all_add_job_post_view.dart';
import '../presentation/recruiter_view/all_apply_user_detail_view.dart';
import '../presentation/recruiter_view/send_response_view.dart';
import '../presentation/search_job_view/search_job_view.dart';
import '../presentation/splash/splash_view.dart';
import 'routes_name.dart';

class Routes {
  static Route<dynamic> genarateRoute(RouteSettings settings) {
    switch (settings.name) {
      case RoutesName.splashView:
        return MaterialPageRoute(
            builder: (BuildContext context) => SplashView());

      case RoutesName.signUpView:
        return MaterialPageRoute(
            builder: (BuildContext context) => SignUpView());

      case RoutesName.recruiterSignUp:
        return MaterialPageRoute(
            builder: (BuildContext context) => RecruiterSignUp());

      case RoutesName.addNewProjectView:
        return MaterialPageRoute(
            builder: (BuildContext context) => AddNewProjectView());

      case RoutesName.loginView:
        return MaterialPageRoute(
            builder: (BuildContext context) => LoginView());

      case RoutesName.addHiringAnnouncementView:
        return MaterialPageRoute(
            builder: (BuildContext context) => AddHiringAnnouncementView());

      case RoutesName.searchJobView:
        return MaterialPageRoute(
            builder: (BuildContext context) => SearchJobView());

      case RoutesName.jobDetailView:
        return MaterialPageRoute(builder: (BuildContext context) {
          final arguments = settings.arguments as Map<String, dynamic>;
          return JobDetailView(
            searchJobsResponseData: arguments['searchJobsResponseData'],
          );
        });

      case RoutesName.sendResponseView:
        return MaterialPageRoute(builder: (BuildContext context) {
          final arguments = settings.arguments as Map<String, dynamic>;
          return SendResponseView(
            hiringID: arguments['hiringID'],
            userID: arguments['userID'],
          );
        });

      case RoutesName.homeView:
        return MaterialPageRoute(builder: (BuildContext context) => HomeView());

      case RoutesName.allAddJobPostView:
        return MaterialPageRoute(
            builder: (BuildContext context) => AllAddJobPostView());

      case RoutesName.exploreScreen:
        return MaterialPageRoute(
            builder: (BuildContext context) => ExploreScreen());

      case RoutesName.bookMarkScreen:
        return MaterialPageRoute(
            builder: (BuildContext context) => BookMarkScreen());

      case RoutesName.profileView:
        return MaterialPageRoute(
            builder: (BuildContext context) => const ProfileView());

      case RoutesName.allApplyUserDetailView:
        return MaterialPageRoute(builder: (BuildContext context) {
          final arguments = settings.arguments as Map<String, dynamic>;
          return AllApplyUserDetailView(
            hiringId: arguments['hiringId'],
          );
        });

      case RoutesName.profileCreateAndEditView:
        return MaterialPageRoute(builder: (BuildContext context) {
          final arguments = settings.arguments as Map<String, dynamic>;
          return ProfileCreateAndEditView(
            email: arguments['email']!,
          );
        });

      case RoutesName.editProfileScreen:
        return MaterialPageRoute(
            builder: (BuildContext context) => const EditProfileScreen());

      case RoutesName.navigationView:
        return MaterialPageRoute(
            builder: (BuildContext context) => NavigationView());

      case RoutesName.recruiterNavigationView:
        return MaterialPageRoute(
            builder: (BuildContext context) => RecruiterNavigationView());

      // case RoutesName.winnerDetailScreen:
      //   return MaterialPageRoute(
      //     builder: (BuildContext context) {
      //       final arguments = settings.arguments as Map<String, dynamic>;
      //       return WinnerDetailScreen(
      //         getWinProductData: arguments['getWinProductData']!,
      //       );
      //     },
      //   );

      // case RoutesName.creditCardDetailScreen:
      //   return MaterialPageRoute(
      //     builder: (BuildContext context) {
      //       final arguments = settings.arguments as Map<String, dynamic>;
      //       return CreditCardDetailScreen(
      //         productId: arguments['productId']!,
      //         getWinProductData: arguments['getWinProductData']!,
      //       );
      //     },
      //   );

      // case RoutesName.editProductDetailView:
      //   return MaterialPageRoute(
      //     builder: (BuildContext context) {
      //       final arguments = settings.arguments as Map<String, dynamic>;
      //       return EditProductDetailView(
      //         productId: arguments['productId']!,
      //       );
      //     },
      //   );

      // case RoutesName.homeView:
      //   return MaterialPageRoute(
      //       builder: (BuildContext context) => const HomeView());

      // case RoutesName.myBidViewWidget:
      //   return MaterialPageRoute(
      //     builder: (BuildContext context) {
      //       final arguments = settings.arguments as Map<String, dynamic>;
      //       return MyBidViewWidget(
      //         allMyBidsProductsList: arguments['allMyBidsProductsList']!,
      //       );
      //     },
      //   );

      // case RoutesName.myBidView:
      //   return MaterialPageRoute(
      //       builder: (BuildContext context) => const MyBidView());

      // case RoutesName.navigationView:
      //   return MaterialPageRoute(
      //       builder: (BuildContext context) => NavigationView());

      // case RoutesName.myProductView:
      //   return MaterialPageRoute(
      //     builder: (BuildContext context) {
      //       final arguments = settings.arguments as Map<String, dynamic>;
      //       return MyProductView(
      //         productId: arguments['productId']!,
      //       );
      //     },
      //   );

      // case RoutesName.navigationView:
      //   return MaterialPageRoute(
      //       builder: (BuildContext context) => NavigationView());

      // case RoutesName.productView:
      //   return MaterialPageRoute(
      //     builder: (BuildContext context) {
      //       final arguments = settings.arguments as Map<String, dynamic>;
      //       return ProductView(
      //         imageUrl: arguments['imageUrl']!,
      //         productId: arguments['productId']!,
      //       );
      //     },
      //   );

      // case RoutesName.myProductViewWidget:
      //   return MaterialPageRoute(
      //     builder: (BuildContext context) {
      //       final arguments = settings.arguments as Map<String, dynamic>;
      //       return MyProductViewWidget(
      //         myProductList: arguments['myProductList']!,
      //       );
      //     },
      //   );

      // case RoutesName.profileView:
      //   return MaterialPageRoute(
      //       builder: (BuildContext context) => const ProfileView());

      // case RoutesName.updateUserDetailView:
      //   return MaterialPageRoute(
      //       builder: (BuildContext context) => UpdateUserDetailView());

      // case RoutesName.loginView:
      //   return MaterialPageRoute(
      //       builder: (BuildContext context) => LoginView());

      // case RoutesName.signUpView:
      //   return MaterialPageRoute(
      //       builder: (BuildContext context) => SignUpView());

      default:
        return MaterialPageRoute(builder: (_) {
          return const Scaffold(
            body: Center(child: Text('No route defined')),
          );
        });
    }
  }
}
