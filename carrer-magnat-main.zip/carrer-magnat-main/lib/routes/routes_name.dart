class RoutesName {
  // authen

  static const String loginView = 'Login_view';
  static const String signUpView = 'signUp_View';

  static const String splashView = 'Splash_View';
  static const String homeView = 'Home_View';
  static const String exploreScreen = 'Explore_Screen';
  static const String bookMarkScreen = 'BookMark_Screen';
  static const String profileView = 'ProfileView';
  static const String profileCreateAndEditView = 'ProfileCreateAndEditView';
  static const String editProfileScreen = 'EditProfileScreen';
  static const String navigationView = 'NavigationView';
  static const String recruiterSignUp = 'RecruiterSignUp';
  static const String addHiringAnnouncementView = 'addHiringAnnouncementView';
  static const String recruiterNavigationView = 'RecruiterNavigation_View';
  static const String addNewProjectView = 'AddNewProject_View';
  static const String jobDetailView = 'JobDetail_View';
  static const String searchJobView = 'SearchJob_View';
  static const String allAddJobPostView = 'AllAddJobPost_View';
  static const String allApplyUserDetailView = 'AllApplyUserDetail_View';
  static const String sendResponseView = 'sendResponse_View';
}
