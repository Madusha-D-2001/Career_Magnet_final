import 'package:carrermagnet/application/navigation/navigation_state.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import 'navigation_state_notifier.dart';

final navigationStateNotifierProvider =
    StateNotifierProvider<NavigationStateNotifier, NavigationState>((ref) {
  return NavigationStateNotifier();
});
