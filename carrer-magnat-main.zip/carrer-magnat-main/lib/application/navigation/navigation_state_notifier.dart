import 'package:carrermagnet/application/navigation/navigation_state.dart';
import 'package:carrermagnet/utils/log_utils.dart';

import 'package:hooks_riverpod/hooks_riverpod.dart';

class NavigationStateNotifier extends StateNotifier<NavigationState> {
  NavigationStateNotifier() : super(NavigationState.initial()) {
    _logUtils.log("init");
  }

  static final LogUtils _logUtils = LogUtils(
    featureName: "NavigationStateNotifier",
    printLog: true,
  );

  void indexChange(int index) {
    state = state.copyWith(
      index: index,
    );
  }
}
