import 'package:carrermagnet/application/login/login_state.dart';
import 'package:carrermagnet/domain/core/i_local_repository.dart';
import 'package:carrermagnet/domain/login/i_login_repository.dart';
import 'package:carrermagnet/domain/login/login_request.dart';
import 'package:carrermagnet/utils/log_utils.dart';
import 'package:dartz/dartz.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

class LoginNotifier extends StateNotifier<LoginState> {
  LoginNotifier(this._loginRepository, this._localRepository)
      : super(LoginState.initial()) {
    _logUtils.log("init");
  }

  final ILoginRepository _loginRepository;
  final ILocalRepository _localRepository;

  static final LogUtils _logUtils = LogUtils(
    featureName: "LoginNotifier",
    printLog: true,
  );

  setValues({
    required String email,
    required String password,
  }) {
    state = state.copyWith(
      email: email,
      password: password,
    );
  }

  Future<void> login() async {
    _logUtils.log("login");
    state = state.copyWith(
      isLoading: true,
      responseFailure: none(),
      loginResponse: none(),
    );

    final loginResponse = LoginRequest(
      email: state.email,
      password: state.password,
    );

    _logUtils.log("LoginRequest ::: ${loginResponse}");

    final loginSucessOrFailure = await _loginRepository.login(loginResponse);

    loginSucessOrFailure.fold((failure) {
      state = state.copyWith(
        isLoading: false,
        responseFailure: optionOf(failure),
      );
    }, (response) {
      _localRepository.createOrUpdate('is_logged_in', true.toString());
      _localRepository.createOrUpdate('login_sign_up_email', state.email);
      _localRepository.createOrUpdate('profile_email', state.email);
      state = state.copyWith(
        isLoading: false,
        responseFailure: none(),
        loginResponse: optionOf(response),
      );
    });
  }

  Future<void> logout() async {
    _localRepository.deleteAll();
  }
}
