import 'package:carrermagnet/application/login/login_state.dart';
import 'package:carrermagnet/application/login/login_state_notifier.dart';
import 'package:carrermagnet/infrastructure/core/providers.dart';
import 'package:carrermagnet/infrastructure/login/providers.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

final loginStateNotifierProvider =
    StateNotifierProvider<LoginNotifier, LoginState>((ref) {
  final loginRepository = ref.read(loginRepositoryProvider);
  final localRepository = ref.read(localRepositoryProvider);

  return LoginNotifier(loginRepository, localRepository);
});
