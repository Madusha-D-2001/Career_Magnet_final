import 'package:carrermagnet/domain/core/failure.dart';
import 'package:carrermagnet/domain/login/login_response.dart';
import 'package:dartz/dartz.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'login_state.freezed.dart';

@freezed
class LoginState with _$LoginState {
  factory LoginState({
    required String email,
    required String password,
    required bool isLoading,
    required Option<Failure> responseFailure,
    required Option<LoginResponse> loginResponse,
  }) = _LoginState;

  factory LoginState.initial() {
    return LoginState(
      email: '',
      password: '',
      isLoading: false,
      responseFailure: none(),
      loginResponse: none(),
    );
  }
}
