import 'package:carrermagnet/domain/core/failure.dart';
import 'package:carrermagnet/domain/get_user_profile/get_user_profile_response.dart';
import 'package:carrermagnet/domain/profile_creation/profile_creation_response.dart';
import 'package:dartz/dartz.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kt_dart/kt.dart';

import '../../domain/add_hiring_announcement/add_hiring_announcement_response.dart';
import '../../domain/get_all_applied_vacancies/get_all_applied_vacancies_data.dart';
import '../../domain/get_all_applied_vacancies/get_all_applied_vacancies_response.dart';
import '../../domain/get_all_job/get_all_job_data.dart';
import '../../domain/get_all_job/get_all_job_response.dart';
import '../../domain/get_user_profile/user_projects_data.dart';
import '../../domain/search_jobs/search_jobs_response.dart';
import '../../domain/search_jobs/search_jobs_response_data.dart';

part 'profile_creation_state.freezed.dart';

@freezed
class ProfileCreationState with _$ProfileCreationState {
  factory ProfileCreationState({
    required String JobType,
    required bool isLoading,
    required bool isGetAllJobsLoading,
    required bool isGetAllSuggestedJobsLoading,
    required bool isSearchJobLoading,
    required bool isClickFilter,
    required bool isClickSearch,
    required bool isOpenFilterSection,
    required bool isProfileCreate,
    required bool isAddProjectLoading,
    required bool isRemoveProjectLoading,
    required bool isRemoveProject,
    required bool isAddVacancy,
    required String searchJobType,
    required String searchJobLocation,
    required String searchJobCompany,
    required String userProfileID,
    required String firstName,
    required String lastName,
    required String fullName,
    required String address,
    required String birthDay,
    required String email,
    required String contact,
    required String profileInfo,
    required String education,
    required String university,
    required String position,
    required List<String> results,
    required KtList<UserProjectsData> projectDetailList,
    required KtList<GetAllAppliedVacanciesData> getAllAppliedJobVacancyList,
    required KtList<GetAllJobData> searchJobList,
    required KtList<GetAllJobData> getAllJobList,
    required KtList<GetAllJobData> getAllSuggestedJobList,
    required List<String>? skillList,
    required Option<Failure> responseFailure,
    required Option<ProfileCreationResponse> profileCreationResponse,
    required Option<GetAllJobResponse> getAllJobsResponse,
    required Option<GetAllJobResponse> getAllSuggestedJobsResponse,
    required Option<GetUserProfileResponse> getUserProfileResponse,
    required Option<SearchJobsResponse> searchJobResponse,
    required Option<AddHiringAnnouncementResponse> addNewProjectResponse,
    required Option<AddHiringAnnouncementResponse> applyToVacancyResponse,
    required Option<AddHiringAnnouncementResponse> removeProjectResponse,
    required Option<GetAllAppliedVacanciesResponse>
        getAllAppliedJobVacancyResponse,
  }) = _ProfileCreationState;

  factory ProfileCreationState.initial() {
    return ProfileCreationState(
      JobType: "Full Stack Developer",
      getAllJobList: emptyList(),
      searchJobList: emptyList(),
      getAllAppliedJobVacancyList: emptyList(),
      getAllSuggestedJobList: emptyList(),
      getAllSuggestedJobsResponse: none(),
      getAllJobsResponse: none(),
      isGetAllSuggestedJobsLoading: false,
      isSearchJobLoading: false,
      isAddVacancy: false,
      isClickSearch: false,
      isGetAllJobsLoading: false,
      isClickFilter: false,
      isOpenFilterSection: false,
      searchJobCompany: '',
      searchJobLocation: '',
      searchJobType: '',
      userProfileID: '',
      address: '',
      birthDay: '',
      contact: '',
      education: '',
      email: '',
      firstName: '',
      fullName: '',
      lastName: '',
      position: '',
      profileInfo: '',
      university: '',
      isLoading: false,
      isAddProjectLoading: false,
      isRemoveProject: false,
      isRemoveProjectLoading: false,
      results: [],
      skillList: [],
      isProfileCreate: false,
      responseFailure: none(),
      projectDetailList: emptyList(),
      profileCreationResponse: none(),
      getUserProfileResponse: none(),
      addNewProjectResponse: none(),
      removeProjectResponse: none(),
      searchJobResponse: none(),
      applyToVacancyResponse: none(),
      getAllAppliedJobVacancyResponse: none(),
    );
  }
}
