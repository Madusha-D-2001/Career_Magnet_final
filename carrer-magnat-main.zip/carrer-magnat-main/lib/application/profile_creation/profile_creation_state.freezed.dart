// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'profile_creation_state.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$ProfileCreationState {
  String get JobType => throw _privateConstructorUsedError;
  bool get isLoading => throw _privateConstructorUsedError;
  bool get isGetAllJobsLoading => throw _privateConstructorUsedError;
  bool get isGetAllSuggestedJobsLoading => throw _privateConstructorUsedError;
  bool get isSearchJobLoading => throw _privateConstructorUsedError;
  bool get isClickFilter => throw _privateConstructorUsedError;
  bool get isClickSearch => throw _privateConstructorUsedError;
  bool get isOpenFilterSection => throw _privateConstructorUsedError;
  bool get isProfileCreate => throw _privateConstructorUsedError;
  bool get isAddProjectLoading => throw _privateConstructorUsedError;
  bool get isRemoveProjectLoading => throw _privateConstructorUsedError;
  bool get isRemoveProject => throw _privateConstructorUsedError;
  bool get isAddVacancy => throw _privateConstructorUsedError;
  String get searchJobType => throw _privateConstructorUsedError;
  String get searchJobLocation => throw _privateConstructorUsedError;
  String get searchJobCompany => throw _privateConstructorUsedError;
  String get userProfileID => throw _privateConstructorUsedError;
  String get firstName => throw _privateConstructorUsedError;
  String get lastName => throw _privateConstructorUsedError;
  String get fullName => throw _privateConstructorUsedError;
  String get address => throw _privateConstructorUsedError;
  String get birthDay => throw _privateConstructorUsedError;
  String get email => throw _privateConstructorUsedError;
  String get contact => throw _privateConstructorUsedError;
  String get profileInfo => throw _privateConstructorUsedError;
  String get education => throw _privateConstructorUsedError;
  String get university => throw _privateConstructorUsedError;
  String get position => throw _privateConstructorUsedError;
  List<String> get results => throw _privateConstructorUsedError;
  KtList<UserProjectsData> get projectDetailList =>
      throw _privateConstructorUsedError;
  KtList<GetAllAppliedVacanciesData> get getAllAppliedJobVacancyList =>
      throw _privateConstructorUsedError;
  KtList<GetAllJobData> get searchJobList => throw _privateConstructorUsedError;
  KtList<GetAllJobData> get getAllJobList => throw _privateConstructorUsedError;
  KtList<GetAllJobData> get getAllSuggestedJobList =>
      throw _privateConstructorUsedError;
  List<String>? get skillList => throw _privateConstructorUsedError;
  Option<Failure> get responseFailure => throw _privateConstructorUsedError;
  Option<ProfileCreationResponse> get profileCreationResponse =>
      throw _privateConstructorUsedError;
  Option<GetAllJobResponse> get getAllJobsResponse =>
      throw _privateConstructorUsedError;
  Option<GetAllJobResponse> get getAllSuggestedJobsResponse =>
      throw _privateConstructorUsedError;
  Option<GetUserProfileResponse> get getUserProfileResponse =>
      throw _privateConstructorUsedError;
  Option<SearchJobsResponse> get searchJobResponse =>
      throw _privateConstructorUsedError;
  Option<AddHiringAnnouncementResponse> get addNewProjectResponse =>
      throw _privateConstructorUsedError;
  Option<AddHiringAnnouncementResponse> get applyToVacancyResponse =>
      throw _privateConstructorUsedError;
  Option<AddHiringAnnouncementResponse> get removeProjectResponse =>
      throw _privateConstructorUsedError;
  Option<GetAllAppliedVacanciesResponse> get getAllAppliedJobVacancyResponse =>
      throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $ProfileCreationStateCopyWith<ProfileCreationState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProfileCreationStateCopyWith<$Res> {
  factory $ProfileCreationStateCopyWith(ProfileCreationState value,
          $Res Function(ProfileCreationState) then) =
      _$ProfileCreationStateCopyWithImpl<$Res, ProfileCreationState>;
  @useResult
  $Res call(
      {String JobType,
      bool isLoading,
      bool isGetAllJobsLoading,
      bool isGetAllSuggestedJobsLoading,
      bool isSearchJobLoading,
      bool isClickFilter,
      bool isClickSearch,
      bool isOpenFilterSection,
      bool isProfileCreate,
      bool isAddProjectLoading,
      bool isRemoveProjectLoading,
      bool isRemoveProject,
      bool isAddVacancy,
      String searchJobType,
      String searchJobLocation,
      String searchJobCompany,
      String userProfileID,
      String firstName,
      String lastName,
      String fullName,
      String address,
      String birthDay,
      String email,
      String contact,
      String profileInfo,
      String education,
      String university,
      String position,
      List<String> results,
      KtList<UserProjectsData> projectDetailList,
      KtList<GetAllAppliedVacanciesData> getAllAppliedJobVacancyList,
      KtList<GetAllJobData> searchJobList,
      KtList<GetAllJobData> getAllJobList,
      KtList<GetAllJobData> getAllSuggestedJobList,
      List<String>? skillList,
      Option<Failure> responseFailure,
      Option<ProfileCreationResponse> profileCreationResponse,
      Option<GetAllJobResponse> getAllJobsResponse,
      Option<GetAllJobResponse> getAllSuggestedJobsResponse,
      Option<GetUserProfileResponse> getUserProfileResponse,
      Option<SearchJobsResponse> searchJobResponse,
      Option<AddHiringAnnouncementResponse> addNewProjectResponse,
      Option<AddHiringAnnouncementResponse> applyToVacancyResponse,
      Option<AddHiringAnnouncementResponse> removeProjectResponse,
      Option<GetAllAppliedVacanciesResponse> getAllAppliedJobVacancyResponse});
}

/// @nodoc
class _$ProfileCreationStateCopyWithImpl<$Res,
        $Val extends ProfileCreationState>
    implements $ProfileCreationStateCopyWith<$Res> {
  _$ProfileCreationStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? JobType = null,
    Object? isLoading = null,
    Object? isGetAllJobsLoading = null,
    Object? isGetAllSuggestedJobsLoading = null,
    Object? isSearchJobLoading = null,
    Object? isClickFilter = null,
    Object? isClickSearch = null,
    Object? isOpenFilterSection = null,
    Object? isProfileCreate = null,
    Object? isAddProjectLoading = null,
    Object? isRemoveProjectLoading = null,
    Object? isRemoveProject = null,
    Object? isAddVacancy = null,
    Object? searchJobType = null,
    Object? searchJobLocation = null,
    Object? searchJobCompany = null,
    Object? userProfileID = null,
    Object? firstName = null,
    Object? lastName = null,
    Object? fullName = null,
    Object? address = null,
    Object? birthDay = null,
    Object? email = null,
    Object? contact = null,
    Object? profileInfo = null,
    Object? education = null,
    Object? university = null,
    Object? position = null,
    Object? results = null,
    Object? projectDetailList = null,
    Object? getAllAppliedJobVacancyList = null,
    Object? searchJobList = null,
    Object? getAllJobList = null,
    Object? getAllSuggestedJobList = null,
    Object? skillList = freezed,
    Object? responseFailure = null,
    Object? profileCreationResponse = null,
    Object? getAllJobsResponse = null,
    Object? getAllSuggestedJobsResponse = null,
    Object? getUserProfileResponse = null,
    Object? searchJobResponse = null,
    Object? addNewProjectResponse = null,
    Object? applyToVacancyResponse = null,
    Object? removeProjectResponse = null,
    Object? getAllAppliedJobVacancyResponse = null,
  }) {
    return _then(_value.copyWith(
      JobType: null == JobType
          ? _value.JobType
          : JobType // ignore: cast_nullable_to_non_nullable
              as String,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isGetAllJobsLoading: null == isGetAllJobsLoading
          ? _value.isGetAllJobsLoading
          : isGetAllJobsLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isGetAllSuggestedJobsLoading: null == isGetAllSuggestedJobsLoading
          ? _value.isGetAllSuggestedJobsLoading
          : isGetAllSuggestedJobsLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isSearchJobLoading: null == isSearchJobLoading
          ? _value.isSearchJobLoading
          : isSearchJobLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isClickFilter: null == isClickFilter
          ? _value.isClickFilter
          : isClickFilter // ignore: cast_nullable_to_non_nullable
              as bool,
      isClickSearch: null == isClickSearch
          ? _value.isClickSearch
          : isClickSearch // ignore: cast_nullable_to_non_nullable
              as bool,
      isOpenFilterSection: null == isOpenFilterSection
          ? _value.isOpenFilterSection
          : isOpenFilterSection // ignore: cast_nullable_to_non_nullable
              as bool,
      isProfileCreate: null == isProfileCreate
          ? _value.isProfileCreate
          : isProfileCreate // ignore: cast_nullable_to_non_nullable
              as bool,
      isAddProjectLoading: null == isAddProjectLoading
          ? _value.isAddProjectLoading
          : isAddProjectLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isRemoveProjectLoading: null == isRemoveProjectLoading
          ? _value.isRemoveProjectLoading
          : isRemoveProjectLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isRemoveProject: null == isRemoveProject
          ? _value.isRemoveProject
          : isRemoveProject // ignore: cast_nullable_to_non_nullable
              as bool,
      isAddVacancy: null == isAddVacancy
          ? _value.isAddVacancy
          : isAddVacancy // ignore: cast_nullable_to_non_nullable
              as bool,
      searchJobType: null == searchJobType
          ? _value.searchJobType
          : searchJobType // ignore: cast_nullable_to_non_nullable
              as String,
      searchJobLocation: null == searchJobLocation
          ? _value.searchJobLocation
          : searchJobLocation // ignore: cast_nullable_to_non_nullable
              as String,
      searchJobCompany: null == searchJobCompany
          ? _value.searchJobCompany
          : searchJobCompany // ignore: cast_nullable_to_non_nullable
              as String,
      userProfileID: null == userProfileID
          ? _value.userProfileID
          : userProfileID // ignore: cast_nullable_to_non_nullable
              as String,
      firstName: null == firstName
          ? _value.firstName
          : firstName // ignore: cast_nullable_to_non_nullable
              as String,
      lastName: null == lastName
          ? _value.lastName
          : lastName // ignore: cast_nullable_to_non_nullable
              as String,
      fullName: null == fullName
          ? _value.fullName
          : fullName // ignore: cast_nullable_to_non_nullable
              as String,
      address: null == address
          ? _value.address
          : address // ignore: cast_nullable_to_non_nullable
              as String,
      birthDay: null == birthDay
          ? _value.birthDay
          : birthDay // ignore: cast_nullable_to_non_nullable
              as String,
      email: null == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String,
      contact: null == contact
          ? _value.contact
          : contact // ignore: cast_nullable_to_non_nullable
              as String,
      profileInfo: null == profileInfo
          ? _value.profileInfo
          : profileInfo // ignore: cast_nullable_to_non_nullable
              as String,
      education: null == education
          ? _value.education
          : education // ignore: cast_nullable_to_non_nullable
              as String,
      university: null == university
          ? _value.university
          : university // ignore: cast_nullable_to_non_nullable
              as String,
      position: null == position
          ? _value.position
          : position // ignore: cast_nullable_to_non_nullable
              as String,
      results: null == results
          ? _value.results
          : results // ignore: cast_nullable_to_non_nullable
              as List<String>,
      projectDetailList: null == projectDetailList
          ? _value.projectDetailList
          : projectDetailList // ignore: cast_nullable_to_non_nullable
              as KtList<UserProjectsData>,
      getAllAppliedJobVacancyList: null == getAllAppliedJobVacancyList
          ? _value.getAllAppliedJobVacancyList
          : getAllAppliedJobVacancyList // ignore: cast_nullable_to_non_nullable
              as KtList<GetAllAppliedVacanciesData>,
      searchJobList: null == searchJobList
          ? _value.searchJobList
          : searchJobList // ignore: cast_nullable_to_non_nullable
              as KtList<GetAllJobData>,
      getAllJobList: null == getAllJobList
          ? _value.getAllJobList
          : getAllJobList // ignore: cast_nullable_to_non_nullable
              as KtList<GetAllJobData>,
      getAllSuggestedJobList: null == getAllSuggestedJobList
          ? _value.getAllSuggestedJobList
          : getAllSuggestedJobList // ignore: cast_nullable_to_non_nullable
              as KtList<GetAllJobData>,
      skillList: freezed == skillList
          ? _value.skillList
          : skillList // ignore: cast_nullable_to_non_nullable
              as List<String>?,
      responseFailure: null == responseFailure
          ? _value.responseFailure
          : responseFailure // ignore: cast_nullable_to_non_nullable
              as Option<Failure>,
      profileCreationResponse: null == profileCreationResponse
          ? _value.profileCreationResponse
          : profileCreationResponse // ignore: cast_nullable_to_non_nullable
              as Option<ProfileCreationResponse>,
      getAllJobsResponse: null == getAllJobsResponse
          ? _value.getAllJobsResponse
          : getAllJobsResponse // ignore: cast_nullable_to_non_nullable
              as Option<GetAllJobResponse>,
      getAllSuggestedJobsResponse: null == getAllSuggestedJobsResponse
          ? _value.getAllSuggestedJobsResponse
          : getAllSuggestedJobsResponse // ignore: cast_nullable_to_non_nullable
              as Option<GetAllJobResponse>,
      getUserProfileResponse: null == getUserProfileResponse
          ? _value.getUserProfileResponse
          : getUserProfileResponse // ignore: cast_nullable_to_non_nullable
              as Option<GetUserProfileResponse>,
      searchJobResponse: null == searchJobResponse
          ? _value.searchJobResponse
          : searchJobResponse // ignore: cast_nullable_to_non_nullable
              as Option<SearchJobsResponse>,
      addNewProjectResponse: null == addNewProjectResponse
          ? _value.addNewProjectResponse
          : addNewProjectResponse // ignore: cast_nullable_to_non_nullable
              as Option<AddHiringAnnouncementResponse>,
      applyToVacancyResponse: null == applyToVacancyResponse
          ? _value.applyToVacancyResponse
          : applyToVacancyResponse // ignore: cast_nullable_to_non_nullable
              as Option<AddHiringAnnouncementResponse>,
      removeProjectResponse: null == removeProjectResponse
          ? _value.removeProjectResponse
          : removeProjectResponse // ignore: cast_nullable_to_non_nullable
              as Option<AddHiringAnnouncementResponse>,
      getAllAppliedJobVacancyResponse: null == getAllAppliedJobVacancyResponse
          ? _value.getAllAppliedJobVacancyResponse
          : getAllAppliedJobVacancyResponse // ignore: cast_nullable_to_non_nullable
              as Option<GetAllAppliedVacanciesResponse>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ProfileCreationStateImplCopyWith<$Res>
    implements $ProfileCreationStateCopyWith<$Res> {
  factory _$$ProfileCreationStateImplCopyWith(_$ProfileCreationStateImpl value,
          $Res Function(_$ProfileCreationStateImpl) then) =
      __$$ProfileCreationStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String JobType,
      bool isLoading,
      bool isGetAllJobsLoading,
      bool isGetAllSuggestedJobsLoading,
      bool isSearchJobLoading,
      bool isClickFilter,
      bool isClickSearch,
      bool isOpenFilterSection,
      bool isProfileCreate,
      bool isAddProjectLoading,
      bool isRemoveProjectLoading,
      bool isRemoveProject,
      bool isAddVacancy,
      String searchJobType,
      String searchJobLocation,
      String searchJobCompany,
      String userProfileID,
      String firstName,
      String lastName,
      String fullName,
      String address,
      String birthDay,
      String email,
      String contact,
      String profileInfo,
      String education,
      String university,
      String position,
      List<String> results,
      KtList<UserProjectsData> projectDetailList,
      KtList<GetAllAppliedVacanciesData> getAllAppliedJobVacancyList,
      KtList<GetAllJobData> searchJobList,
      KtList<GetAllJobData> getAllJobList,
      KtList<GetAllJobData> getAllSuggestedJobList,
      List<String>? skillList,
      Option<Failure> responseFailure,
      Option<ProfileCreationResponse> profileCreationResponse,
      Option<GetAllJobResponse> getAllJobsResponse,
      Option<GetAllJobResponse> getAllSuggestedJobsResponse,
      Option<GetUserProfileResponse> getUserProfileResponse,
      Option<SearchJobsResponse> searchJobResponse,
      Option<AddHiringAnnouncementResponse> addNewProjectResponse,
      Option<AddHiringAnnouncementResponse> applyToVacancyResponse,
      Option<AddHiringAnnouncementResponse> removeProjectResponse,
      Option<GetAllAppliedVacanciesResponse> getAllAppliedJobVacancyResponse});
}

/// @nodoc
class __$$ProfileCreationStateImplCopyWithImpl<$Res>
    extends _$ProfileCreationStateCopyWithImpl<$Res, _$ProfileCreationStateImpl>
    implements _$$ProfileCreationStateImplCopyWith<$Res> {
  __$$ProfileCreationStateImplCopyWithImpl(_$ProfileCreationStateImpl _value,
      $Res Function(_$ProfileCreationStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? JobType = null,
    Object? isLoading = null,
    Object? isGetAllJobsLoading = null,
    Object? isGetAllSuggestedJobsLoading = null,
    Object? isSearchJobLoading = null,
    Object? isClickFilter = null,
    Object? isClickSearch = null,
    Object? isOpenFilterSection = null,
    Object? isProfileCreate = null,
    Object? isAddProjectLoading = null,
    Object? isRemoveProjectLoading = null,
    Object? isRemoveProject = null,
    Object? isAddVacancy = null,
    Object? searchJobType = null,
    Object? searchJobLocation = null,
    Object? searchJobCompany = null,
    Object? userProfileID = null,
    Object? firstName = null,
    Object? lastName = null,
    Object? fullName = null,
    Object? address = null,
    Object? birthDay = null,
    Object? email = null,
    Object? contact = null,
    Object? profileInfo = null,
    Object? education = null,
    Object? university = null,
    Object? position = null,
    Object? results = null,
    Object? projectDetailList = null,
    Object? getAllAppliedJobVacancyList = null,
    Object? searchJobList = null,
    Object? getAllJobList = null,
    Object? getAllSuggestedJobList = null,
    Object? skillList = freezed,
    Object? responseFailure = null,
    Object? profileCreationResponse = null,
    Object? getAllJobsResponse = null,
    Object? getAllSuggestedJobsResponse = null,
    Object? getUserProfileResponse = null,
    Object? searchJobResponse = null,
    Object? addNewProjectResponse = null,
    Object? applyToVacancyResponse = null,
    Object? removeProjectResponse = null,
    Object? getAllAppliedJobVacancyResponse = null,
  }) {
    return _then(_$ProfileCreationStateImpl(
      JobType: null == JobType
          ? _value.JobType
          : JobType // ignore: cast_nullable_to_non_nullable
              as String,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isGetAllJobsLoading: null == isGetAllJobsLoading
          ? _value.isGetAllJobsLoading
          : isGetAllJobsLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isGetAllSuggestedJobsLoading: null == isGetAllSuggestedJobsLoading
          ? _value.isGetAllSuggestedJobsLoading
          : isGetAllSuggestedJobsLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isSearchJobLoading: null == isSearchJobLoading
          ? _value.isSearchJobLoading
          : isSearchJobLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isClickFilter: null == isClickFilter
          ? _value.isClickFilter
          : isClickFilter // ignore: cast_nullable_to_non_nullable
              as bool,
      isClickSearch: null == isClickSearch
          ? _value.isClickSearch
          : isClickSearch // ignore: cast_nullable_to_non_nullable
              as bool,
      isOpenFilterSection: null == isOpenFilterSection
          ? _value.isOpenFilterSection
          : isOpenFilterSection // ignore: cast_nullable_to_non_nullable
              as bool,
      isProfileCreate: null == isProfileCreate
          ? _value.isProfileCreate
          : isProfileCreate // ignore: cast_nullable_to_non_nullable
              as bool,
      isAddProjectLoading: null == isAddProjectLoading
          ? _value.isAddProjectLoading
          : isAddProjectLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isRemoveProjectLoading: null == isRemoveProjectLoading
          ? _value.isRemoveProjectLoading
          : isRemoveProjectLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isRemoveProject: null == isRemoveProject
          ? _value.isRemoveProject
          : isRemoveProject // ignore: cast_nullable_to_non_nullable
              as bool,
      isAddVacancy: null == isAddVacancy
          ? _value.isAddVacancy
          : isAddVacancy // ignore: cast_nullable_to_non_nullable
              as bool,
      searchJobType: null == searchJobType
          ? _value.searchJobType
          : searchJobType // ignore: cast_nullable_to_non_nullable
              as String,
      searchJobLocation: null == searchJobLocation
          ? _value.searchJobLocation
          : searchJobLocation // ignore: cast_nullable_to_non_nullable
              as String,
      searchJobCompany: null == searchJobCompany
          ? _value.searchJobCompany
          : searchJobCompany // ignore: cast_nullable_to_non_nullable
              as String,
      userProfileID: null == userProfileID
          ? _value.userProfileID
          : userProfileID // ignore: cast_nullable_to_non_nullable
              as String,
      firstName: null == firstName
          ? _value.firstName
          : firstName // ignore: cast_nullable_to_non_nullable
              as String,
      lastName: null == lastName
          ? _value.lastName
          : lastName // ignore: cast_nullable_to_non_nullable
              as String,
      fullName: null == fullName
          ? _value.fullName
          : fullName // ignore: cast_nullable_to_non_nullable
              as String,
      address: null == address
          ? _value.address
          : address // ignore: cast_nullable_to_non_nullable
              as String,
      birthDay: null == birthDay
          ? _value.birthDay
          : birthDay // ignore: cast_nullable_to_non_nullable
              as String,
      email: null == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String,
      contact: null == contact
          ? _value.contact
          : contact // ignore: cast_nullable_to_non_nullable
              as String,
      profileInfo: null == profileInfo
          ? _value.profileInfo
          : profileInfo // ignore: cast_nullable_to_non_nullable
              as String,
      education: null == education
          ? _value.education
          : education // ignore: cast_nullable_to_non_nullable
              as String,
      university: null == university
          ? _value.university
          : university // ignore: cast_nullable_to_non_nullable
              as String,
      position: null == position
          ? _value.position
          : position // ignore: cast_nullable_to_non_nullable
              as String,
      results: null == results
          ? _value._results
          : results // ignore: cast_nullable_to_non_nullable
              as List<String>,
      projectDetailList: null == projectDetailList
          ? _value.projectDetailList
          : projectDetailList // ignore: cast_nullable_to_non_nullable
              as KtList<UserProjectsData>,
      getAllAppliedJobVacancyList: null == getAllAppliedJobVacancyList
          ? _value.getAllAppliedJobVacancyList
          : getAllAppliedJobVacancyList // ignore: cast_nullable_to_non_nullable
              as KtList<GetAllAppliedVacanciesData>,
      searchJobList: null == searchJobList
          ? _value.searchJobList
          : searchJobList // ignore: cast_nullable_to_non_nullable
              as KtList<GetAllJobData>,
      getAllJobList: null == getAllJobList
          ? _value.getAllJobList
          : getAllJobList // ignore: cast_nullable_to_non_nullable
              as KtList<GetAllJobData>,
      getAllSuggestedJobList: null == getAllSuggestedJobList
          ? _value.getAllSuggestedJobList
          : getAllSuggestedJobList // ignore: cast_nullable_to_non_nullable
              as KtList<GetAllJobData>,
      skillList: freezed == skillList
          ? _value._skillList
          : skillList // ignore: cast_nullable_to_non_nullable
              as List<String>?,
      responseFailure: null == responseFailure
          ? _value.responseFailure
          : responseFailure // ignore: cast_nullable_to_non_nullable
              as Option<Failure>,
      profileCreationResponse: null == profileCreationResponse
          ? _value.profileCreationResponse
          : profileCreationResponse // ignore: cast_nullable_to_non_nullable
              as Option<ProfileCreationResponse>,
      getAllJobsResponse: null == getAllJobsResponse
          ? _value.getAllJobsResponse
          : getAllJobsResponse // ignore: cast_nullable_to_non_nullable
              as Option<GetAllJobResponse>,
      getAllSuggestedJobsResponse: null == getAllSuggestedJobsResponse
          ? _value.getAllSuggestedJobsResponse
          : getAllSuggestedJobsResponse // ignore: cast_nullable_to_non_nullable
              as Option<GetAllJobResponse>,
      getUserProfileResponse: null == getUserProfileResponse
          ? _value.getUserProfileResponse
          : getUserProfileResponse // ignore: cast_nullable_to_non_nullable
              as Option<GetUserProfileResponse>,
      searchJobResponse: null == searchJobResponse
          ? _value.searchJobResponse
          : searchJobResponse // ignore: cast_nullable_to_non_nullable
              as Option<SearchJobsResponse>,
      addNewProjectResponse: null == addNewProjectResponse
          ? _value.addNewProjectResponse
          : addNewProjectResponse // ignore: cast_nullable_to_non_nullable
              as Option<AddHiringAnnouncementResponse>,
      applyToVacancyResponse: null == applyToVacancyResponse
          ? _value.applyToVacancyResponse
          : applyToVacancyResponse // ignore: cast_nullable_to_non_nullable
              as Option<AddHiringAnnouncementResponse>,
      removeProjectResponse: null == removeProjectResponse
          ? _value.removeProjectResponse
          : removeProjectResponse // ignore: cast_nullable_to_non_nullable
              as Option<AddHiringAnnouncementResponse>,
      getAllAppliedJobVacancyResponse: null == getAllAppliedJobVacancyResponse
          ? _value.getAllAppliedJobVacancyResponse
          : getAllAppliedJobVacancyResponse // ignore: cast_nullable_to_non_nullable
              as Option<GetAllAppliedVacanciesResponse>,
    ));
  }
}

/// @nodoc

class _$ProfileCreationStateImpl implements _ProfileCreationState {
  _$ProfileCreationStateImpl(
      {required this.JobType,
      required this.isLoading,
      required this.isGetAllJobsLoading,
      required this.isGetAllSuggestedJobsLoading,
      required this.isSearchJobLoading,
      required this.isClickFilter,
      required this.isClickSearch,
      required this.isOpenFilterSection,
      required this.isProfileCreate,
      required this.isAddProjectLoading,
      required this.isRemoveProjectLoading,
      required this.isRemoveProject,
      required this.isAddVacancy,
      required this.searchJobType,
      required this.searchJobLocation,
      required this.searchJobCompany,
      required this.userProfileID,
      required this.firstName,
      required this.lastName,
      required this.fullName,
      required this.address,
      required this.birthDay,
      required this.email,
      required this.contact,
      required this.profileInfo,
      required this.education,
      required this.university,
      required this.position,
      required final List<String> results,
      required this.projectDetailList,
      required this.getAllAppliedJobVacancyList,
      required this.searchJobList,
      required this.getAllJobList,
      required this.getAllSuggestedJobList,
      required final List<String>? skillList,
      required this.responseFailure,
      required this.profileCreationResponse,
      required this.getAllJobsResponse,
      required this.getAllSuggestedJobsResponse,
      required this.getUserProfileResponse,
      required this.searchJobResponse,
      required this.addNewProjectResponse,
      required this.applyToVacancyResponse,
      required this.removeProjectResponse,
      required this.getAllAppliedJobVacancyResponse})
      : _results = results,
        _skillList = skillList;

  @override
  final String JobType;
  @override
  final bool isLoading;
  @override
  final bool isGetAllJobsLoading;
  @override
  final bool isGetAllSuggestedJobsLoading;
  @override
  final bool isSearchJobLoading;
  @override
  final bool isClickFilter;
  @override
  final bool isClickSearch;
  @override
  final bool isOpenFilterSection;
  @override
  final bool isProfileCreate;
  @override
  final bool isAddProjectLoading;
  @override
  final bool isRemoveProjectLoading;
  @override
  final bool isRemoveProject;
  @override
  final bool isAddVacancy;
  @override
  final String searchJobType;
  @override
  final String searchJobLocation;
  @override
  final String searchJobCompany;
  @override
  final String userProfileID;
  @override
  final String firstName;
  @override
  final String lastName;
  @override
  final String fullName;
  @override
  final String address;
  @override
  final String birthDay;
  @override
  final String email;
  @override
  final String contact;
  @override
  final String profileInfo;
  @override
  final String education;
  @override
  final String university;
  @override
  final String position;
  final List<String> _results;
  @override
  List<String> get results {
    if (_results is EqualUnmodifiableListView) return _results;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_results);
  }

  @override
  final KtList<UserProjectsData> projectDetailList;
  @override
  final KtList<GetAllAppliedVacanciesData> getAllAppliedJobVacancyList;
  @override
  final KtList<GetAllJobData> searchJobList;
  @override
  final KtList<GetAllJobData> getAllJobList;
  @override
  final KtList<GetAllJobData> getAllSuggestedJobList;
  final List<String>? _skillList;
  @override
  List<String>? get skillList {
    final value = _skillList;
    if (value == null) return null;
    if (_skillList is EqualUnmodifiableListView) return _skillList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  final Option<Failure> responseFailure;
  @override
  final Option<ProfileCreationResponse> profileCreationResponse;
  @override
  final Option<GetAllJobResponse> getAllJobsResponse;
  @override
  final Option<GetAllJobResponse> getAllSuggestedJobsResponse;
  @override
  final Option<GetUserProfileResponse> getUserProfileResponse;
  @override
  final Option<SearchJobsResponse> searchJobResponse;
  @override
  final Option<AddHiringAnnouncementResponse> addNewProjectResponse;
  @override
  final Option<AddHiringAnnouncementResponse> applyToVacancyResponse;
  @override
  final Option<AddHiringAnnouncementResponse> removeProjectResponse;
  @override
  final Option<GetAllAppliedVacanciesResponse> getAllAppliedJobVacancyResponse;

  @override
  String toString() {
    return 'ProfileCreationState(JobType: $JobType, isLoading: $isLoading, isGetAllJobsLoading: $isGetAllJobsLoading, isGetAllSuggestedJobsLoading: $isGetAllSuggestedJobsLoading, isSearchJobLoading: $isSearchJobLoading, isClickFilter: $isClickFilter, isClickSearch: $isClickSearch, isOpenFilterSection: $isOpenFilterSection, isProfileCreate: $isProfileCreate, isAddProjectLoading: $isAddProjectLoading, isRemoveProjectLoading: $isRemoveProjectLoading, isRemoveProject: $isRemoveProject, isAddVacancy: $isAddVacancy, searchJobType: $searchJobType, searchJobLocation: $searchJobLocation, searchJobCompany: $searchJobCompany, userProfileID: $userProfileID, firstName: $firstName, lastName: $lastName, fullName: $fullName, address: $address, birthDay: $birthDay, email: $email, contact: $contact, profileInfo: $profileInfo, education: $education, university: $university, position: $position, results: $results, projectDetailList: $projectDetailList, getAllAppliedJobVacancyList: $getAllAppliedJobVacancyList, searchJobList: $searchJobList, getAllJobList: $getAllJobList, getAllSuggestedJobList: $getAllSuggestedJobList, skillList: $skillList, responseFailure: $responseFailure, profileCreationResponse: $profileCreationResponse, getAllJobsResponse: $getAllJobsResponse, getAllSuggestedJobsResponse: $getAllSuggestedJobsResponse, getUserProfileResponse: $getUserProfileResponse, searchJobResponse: $searchJobResponse, addNewProjectResponse: $addNewProjectResponse, applyToVacancyResponse: $applyToVacancyResponse, removeProjectResponse: $removeProjectResponse, getAllAppliedJobVacancyResponse: $getAllAppliedJobVacancyResponse)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ProfileCreationStateImpl &&
            (identical(other.JobType, JobType) || other.JobType == JobType) &&
            (identical(other.isLoading, isLoading) ||
                other.isLoading == isLoading) &&
            (identical(other.isGetAllJobsLoading, isGetAllJobsLoading) ||
                other.isGetAllJobsLoading == isGetAllJobsLoading) &&
            (identical(other.isGetAllSuggestedJobsLoading, isGetAllSuggestedJobsLoading) ||
                other.isGetAllSuggestedJobsLoading ==
                    isGetAllSuggestedJobsLoading) &&
            (identical(other.isSearchJobLoading, isSearchJobLoading) ||
                other.isSearchJobLoading == isSearchJobLoading) &&
            (identical(other.isClickFilter, isClickFilter) ||
                other.isClickFilter == isClickFilter) &&
            (identical(other.isClickSearch, isClickSearch) ||
                other.isClickSearch == isClickSearch) &&
            (identical(other.isOpenFilterSection, isOpenFilterSection) ||
                other.isOpenFilterSection == isOpenFilterSection) &&
            (identical(other.isProfileCreate, isProfileCreate) ||
                other.isProfileCreate == isProfileCreate) &&
            (identical(other.isAddProjectLoading, isAddProjectLoading) ||
                other.isAddProjectLoading == isAddProjectLoading) &&
            (identical(other.isRemoveProjectLoading, isRemoveProjectLoading) ||
                other.isRemoveProjectLoading == isRemoveProjectLoading) &&
            (identical(other.isRemoveProject, isRemoveProject) ||
                other.isRemoveProject == isRemoveProject) &&
            (identical(other.isAddVacancy, isAddVacancy) ||
                other.isAddVacancy == isAddVacancy) &&
            (identical(other.searchJobType, searchJobType) ||
                other.searchJobType == searchJobType) &&
            (identical(other.searchJobLocation, searchJobLocation) ||
                other.searchJobLocation == searchJobLocation) &&
            (identical(other.searchJobCompany, searchJobCompany) ||
                other.searchJobCompany == searchJobCompany) &&
            (identical(other.userProfileID, userProfileID) ||
                other.userProfileID == userProfileID) &&
            (identical(other.firstName, firstName) ||
                other.firstName == firstName) &&
            (identical(other.lastName, lastName) ||
                other.lastName == lastName) &&
            (identical(other.fullName, fullName) ||
                other.fullName == fullName) &&
            (identical(other.address, address) || other.address == address) &&
            (identical(other.birthDay, birthDay) ||
                other.birthDay == birthDay) &&
            (identical(other.email, email) || other.email == email) &&
            (identical(other.contact, contact) || other.contact == contact) &&
            (identical(other.profileInfo, profileInfo) ||
                other.profileInfo == profileInfo) &&
            (identical(other.education, education) ||
                other.education == education) &&
            (identical(other.university, university) ||
                other.university == university) &&
            (identical(other.position, position) ||
                other.position == position) &&
            const DeepCollectionEquality().equals(other._results, _results) &&
            (identical(other.projectDetailList, projectDetailList) ||
                other.projectDetailList == projectDetailList) &&
            (identical(other.getAllAppliedJobVacancyList, getAllAppliedJobVacancyList) ||
                other.getAllAppliedJobVacancyList ==
                    getAllAppliedJobVacancyList) &&
            (identical(other.searchJobList, searchJobList) ||
                other.searchJobList == searchJobList) &&
            (identical(other.getAllJobList, getAllJobList) ||
                other.getAllJobList == getAllJobList) &&
            (identical(other.getAllSuggestedJobList, getAllSuggestedJobList) ||
                other.getAllSuggestedJobList == getAllSuggestedJobList) &&
            const DeepCollectionEquality()
                .equals(other._skillList, _skillList) &&
            (identical(other.responseFailure, responseFailure) ||
                other.responseFailure == responseFailure) &&
            (identical(other.profileCreationResponse, profileCreationResponse) ||
                other.profileCreationResponse == profileCreationResponse) &&
            (identical(other.getAllJobsResponse, getAllJobsResponse) || other.getAllJobsResponse == getAllJobsResponse) &&
            (identical(other.getAllSuggestedJobsResponse, getAllSuggestedJobsResponse) || other.getAllSuggestedJobsResponse == getAllSuggestedJobsResponse) &&
            (identical(other.getUserProfileResponse, getUserProfileResponse) || other.getUserProfileResponse == getUserProfileResponse) &&
            (identical(other.searchJobResponse, searchJobResponse) || other.searchJobResponse == searchJobResponse) &&
            (identical(other.addNewProjectResponse, addNewProjectResponse) || other.addNewProjectResponse == addNewProjectResponse) &&
            (identical(other.applyToVacancyResponse, applyToVacancyResponse) || other.applyToVacancyResponse == applyToVacancyResponse) &&
            (identical(other.removeProjectResponse, removeProjectResponse) || other.removeProjectResponse == removeProjectResponse) &&
            (identical(other.getAllAppliedJobVacancyResponse, getAllAppliedJobVacancyResponse) || other.getAllAppliedJobVacancyResponse == getAllAppliedJobVacancyResponse));
  }

  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        JobType,
        isLoading,
        isGetAllJobsLoading,
        isGetAllSuggestedJobsLoading,
        isSearchJobLoading,
        isClickFilter,
        isClickSearch,
        isOpenFilterSection,
        isProfileCreate,
        isAddProjectLoading,
        isRemoveProjectLoading,
        isRemoveProject,
        isAddVacancy,
        searchJobType,
        searchJobLocation,
        searchJobCompany,
        userProfileID,
        firstName,
        lastName,
        fullName,
        address,
        birthDay,
        email,
        contact,
        profileInfo,
        education,
        university,
        position,
        const DeepCollectionEquality().hash(_results),
        projectDetailList,
        getAllAppliedJobVacancyList,
        searchJobList,
        getAllJobList,
        getAllSuggestedJobList,
        const DeepCollectionEquality().hash(_skillList),
        responseFailure,
        profileCreationResponse,
        getAllJobsResponse,
        getAllSuggestedJobsResponse,
        getUserProfileResponse,
        searchJobResponse,
        addNewProjectResponse,
        applyToVacancyResponse,
        removeProjectResponse,
        getAllAppliedJobVacancyResponse
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ProfileCreationStateImplCopyWith<_$ProfileCreationStateImpl>
      get copyWith =>
          __$$ProfileCreationStateImplCopyWithImpl<_$ProfileCreationStateImpl>(
              this, _$identity);
}

abstract class _ProfileCreationState implements ProfileCreationState {
  factory _ProfileCreationState(
      {required final String JobType,
      required final bool isLoading,
      required final bool isGetAllJobsLoading,
      required final bool isGetAllSuggestedJobsLoading,
      required final bool isSearchJobLoading,
      required final bool isClickFilter,
      required final bool isClickSearch,
      required final bool isOpenFilterSection,
      required final bool isProfileCreate,
      required final bool isAddProjectLoading,
      required final bool isRemoveProjectLoading,
      required final bool isRemoveProject,
      required final bool isAddVacancy,
      required final String searchJobType,
      required final String searchJobLocation,
      required final String searchJobCompany,
      required final String userProfileID,
      required final String firstName,
      required final String lastName,
      required final String fullName,
      required final String address,
      required final String birthDay,
      required final String email,
      required final String contact,
      required final String profileInfo,
      required final String education,
      required final String university,
      required final String position,
      required final List<String> results,
      required final KtList<UserProjectsData> projectDetailList,
      required final KtList<GetAllAppliedVacanciesData>
          getAllAppliedJobVacancyList,
      required final KtList<GetAllJobData> searchJobList,
      required final KtList<GetAllJobData> getAllJobList,
      required final KtList<GetAllJobData> getAllSuggestedJobList,
      required final List<String>? skillList,
      required final Option<Failure> responseFailure,
      required final Option<ProfileCreationResponse> profileCreationResponse,
      required final Option<GetAllJobResponse> getAllJobsResponse,
      required final Option<GetAllJobResponse> getAllSuggestedJobsResponse,
      required final Option<GetUserProfileResponse> getUserProfileResponse,
      required final Option<SearchJobsResponse> searchJobResponse,
      required final Option<AddHiringAnnouncementResponse>
          addNewProjectResponse,
      required final Option<AddHiringAnnouncementResponse>
          applyToVacancyResponse,
      required final Option<AddHiringAnnouncementResponse>
          removeProjectResponse,
      required final Option<GetAllAppliedVacanciesResponse>
          getAllAppliedJobVacancyResponse}) = _$ProfileCreationStateImpl;

  @override
  String get JobType;
  @override
  bool get isLoading;
  @override
  bool get isGetAllJobsLoading;
  @override
  bool get isGetAllSuggestedJobsLoading;
  @override
  bool get isSearchJobLoading;
  @override
  bool get isClickFilter;
  @override
  bool get isClickSearch;
  @override
  bool get isOpenFilterSection;
  @override
  bool get isProfileCreate;
  @override
  bool get isAddProjectLoading;
  @override
  bool get isRemoveProjectLoading;
  @override
  bool get isRemoveProject;
  @override
  bool get isAddVacancy;
  @override
  String get searchJobType;
  @override
  String get searchJobLocation;
  @override
  String get searchJobCompany;
  @override
  String get userProfileID;
  @override
  String get firstName;
  @override
  String get lastName;
  @override
  String get fullName;
  @override
  String get address;
  @override
  String get birthDay;
  @override
  String get email;
  @override
  String get contact;
  @override
  String get profileInfo;
  @override
  String get education;
  @override
  String get university;
  @override
  String get position;
  @override
  List<String> get results;
  @override
  KtList<UserProjectsData> get projectDetailList;
  @override
  KtList<GetAllAppliedVacanciesData> get getAllAppliedJobVacancyList;
  @override
  KtList<GetAllJobData> get searchJobList;
  @override
  KtList<GetAllJobData> get getAllJobList;
  @override
  KtList<GetAllJobData> get getAllSuggestedJobList;
  @override
  List<String>? get skillList;
  @override
  Option<Failure> get responseFailure;
  @override
  Option<ProfileCreationResponse> get profileCreationResponse;
  @override
  Option<GetAllJobResponse> get getAllJobsResponse;
  @override
  Option<GetAllJobResponse> get getAllSuggestedJobsResponse;
  @override
  Option<GetUserProfileResponse> get getUserProfileResponse;
  @override
  Option<SearchJobsResponse> get searchJobResponse;
  @override
  Option<AddHiringAnnouncementResponse> get addNewProjectResponse;
  @override
  Option<AddHiringAnnouncementResponse> get applyToVacancyResponse;
  @override
  Option<AddHiringAnnouncementResponse> get removeProjectResponse;
  @override
  Option<GetAllAppliedVacanciesResponse> get getAllAppliedJobVacancyResponse;
  @override
  @JsonKey(ignore: true)
  _$$ProfileCreationStateImplCopyWith<_$ProfileCreationStateImpl>
      get copyWith => throw _privateConstructorUsedError;
}
