import 'package:carrermagnet/application/profile_creation/profile_creation_state.dart';
import 'package:carrermagnet/domain/addNewProject/add_new_project_request.dart';
import 'package:carrermagnet/domain/core/i_local_repository.dart';
import 'package:carrermagnet/domain/profile_creation/i_profile_creation_repository.dart';
import 'package:carrermagnet/domain/profile_creation/profile_creation_request.dart';
import 'package:carrermagnet/utils/log_utils.dart';
import 'package:dartz/dartz.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kt_dart/kt.dart';

import '../../domain/apply_to_vacancy/apply_to_vacancy_request.dart';
import '../../domain/search_jobs/search_jobs_request.dart';

class ProfileCreationStateNotifier extends StateNotifier<ProfileCreationState> {
  ProfileCreationStateNotifier(
    this._profileCreationRepository,
    this._localRepository,
  ) : super(ProfileCreationState.initial()) {
    _logUtils.log("init");
  }

  final IProfileCreationRepository _profileCreationRepository;
  final ILocalRepository _localRepository;

  static final LogUtils _logUtils = LogUtils(
    featureName: "Profile Creation State Notifier",
    printLog: true,
  );

  // get All Applied Vacancies ------------------------

  Future<void> getAllAppliedJobVacancy({required String email}) async {
    _logUtils.log(":::: get All Job Vacancy ::::");
    state = state.copyWith(
      // isGetAllJobsLoading: true,
      responseFailure: none(),
      getAllAppliedJobVacancyResponse: none(),
    );

    final getAllJobsSucessOrFailure =
        await _profileCreationRepository.getAllAppliedVacancies(email);

    getAllJobsSucessOrFailure.fold((failure) {
      state = state.copyWith(
        // isGetAllJobsLoading: false,
        responseFailure: optionOf(failure),
      );
    }, (response) {
      state = state.copyWith(
        // isGetAllJobsLoading: false,
        responseFailure: none(),
        getAllAppliedJobVacancyResponse: optionOf(response),
        getAllAppliedJobVacancyList: response.data,
      );
    });
  }

  // set Search Job Type ---

  setSearchJobType({required String JobType}) {
    state = state.copyWith(
      JobType: JobType,
    );
  }

  // Search Jobs --------------------------------------------------------------

  Future<void> searchJobs() async {
    _logUtils.log(":::: get All Jobs ::::");
    state = state.copyWith(
      isSearchJobLoading: true,
      responseFailure: none(),
      searchJobResponse: none(),
    );

    final searchJobsRequest = SearchJobsRequest(
      companyName: '',
      jobType: state.JobType,
      location: '',
    );

    final searchJobsRequestSucessOrFailure =
        await _profileCreationRepository.searchJob(searchJobsRequest);

    searchJobsRequestSucessOrFailure.fold((failure) {
      state = state.copyWith(
        isSearchJobLoading: false,
        responseFailure: optionOf(failure),
      );
    }, (response) {
      state = state.copyWith(
        isSearchJobLoading: false,
        responseFailure: none(),
        getAllJobsResponse: optionOf(response),
        searchJobList: response.data,
      );
    });
  }

  // get All Jobs --------------------------------------------------------------

  Future<void> getAllJobs() async {
    _logUtils.log(":::: get All Jobs ::::");
    state = state.copyWith(
      isGetAllJobsLoading: true,
      responseFailure: none(),
      getAllJobsResponse: none(),
    );

    final getAllJobsSucessOrFailure =
        await _profileCreationRepository.getAllJobs();

    getAllJobsSucessOrFailure.fold((failure) {
      state = state.copyWith(
        isGetAllJobsLoading: false,
        responseFailure: optionOf(failure),
      );
    }, (response) {
      state = state.copyWith(
        isGetAllJobsLoading: false,
        responseFailure: none(),
        getAllJobsResponse: optionOf(response),
        getAllJobList: response.data,
      );
    });
  }

  // get All Suggested Job --------------------------------------------------------------

  Future<void> getAllSuggestedJobs({required String email}) async {
    _logUtils.log(":::: get All Suggested Jobs ::::");
    state = state.copyWith(
      isGetAllSuggestedJobsLoading: true,
      responseFailure: none(),
      getAllSuggestedJobsResponse: none(),
    );

    final getAllSuggestedJobsSucessOrFailure =
        await _profileCreationRepository.getAllSuggestedJob(email);

    getAllSuggestedJobsSucessOrFailure.fold((failure) {
      state = state.copyWith(
        isGetAllSuggestedJobsLoading: false,
        responseFailure: optionOf(failure),
      );
    }, (response) {
      state = state.copyWith(
        isGetAllSuggestedJobsLoading: false,
        responseFailure: none(),
        getAllSuggestedJobsResponse: optionOf(response),
        getAllSuggestedJobList: response.data,
      );
    });
  }

  //  setSkillsToList

  setSkillsToList(List<String> skilResults) {
    state = state.copyWith(
      results: skilResults,
    );
  }

  getJobType() {
    final List<String> list = [
      "Software Engineer (SE)",
      "Senior Software Engineer (SSE)",
      "Software Developer",
      "Full Stack Developer",
      "Front-end Developer",
      "Back-end Developer",
      "Web Developer",
      "Mobile App Developer",
      "DevOps Engineer",
      "Cloud Engineer",
      "Site Reliability Engineer (SRE)",
      "Database Administrator (DBA)",
      "System Administrator (SysAdmin)",
      "Network Administrator",
      "Quality Assurance (QA) Engineer",
      "Automation Test Engineer",
      "Performance Test Engineer",
      "Security Engineer",
      "Information Security Analyst",
      "Cybersecurity Specialist",
      "IT Support Specialist",
      "Help Desk Technician",
      "Technical Support Engineer",
      "Product Manager",
      "Project Manager (PM)",
      "Technical Project Manager",
      "Program Manager",
      "Business Analyst (BA)",
      "Systems Analyst",
      "Data Analyst",
      "Data Scientist",
      "Data Engineer",
      "Big Data Engineer",
      "Machine Learning Engineer",
      "AI Specialist",
      "NLP Engineer",
      "Computer Vision Engineer",
      "Data Architect",
      "Solutions Architect",
      "Cloud Architect",
      "Enterprise Architect",
      "Software Architect",
      "Application Architect",
      "Infrastructure Architect",
      "IT Manager",
      "IT Director",
      "Chief Technology Officer (CTO)",
      "Chief Information Officer (CIO)",
      "Tech Lead",
      "Engineering Manager",
      "UI/UX Designer",
      "Product Designer",
      "User Experience Researcher",
      "Graphic Designer",
      "Technical Writer",
      "Scrum Master",
      "Agile Coach",
      "Business Intelligence (BI) Developer",
      "BI Analyst",
      "Cloud Consultant",
      "IT Consultant",
      "Software Consultant",
      "Network Engineer",
      "System Engineer",
      "Support Engineer",
      "Release Manager",
      "Build Engineer",
      "Integration Engineer",
      "API Developer",
      "Embedded Software Engineer",
      "Firmware Engineer",
      "Mobile Application Manager",
      "IT Auditor",
      "Compliance Specialist",
      "ERP Consultant",
      "CRM Consultant",
      "IT Operations Manager",
      "IT Service Manager",
      "Technical Account Manager",
      "Customer Success Manager",
      "Digital Transformation Specialist",
      "Robotic Process Automation (RPA) Developer",
      "DevSecOps Engineer",
      "Penetration Tester",
      "Ethical Hacker",
      "Cloud Support Engineer",
      "Cloud Solutions Engineer",
      "Cloud DevOps Engineer",
      "Container Engineer",
      "Kubernetes Engineer",
      "Docker Engineer",
      "Artificial Intelligence Engineer",
      "Deep Learning Engineer",
      "Virtualization Engineer",
      "Augmented Reality (AR) Developer",
      "Virtual Reality (VR) Developer",
      "Blockchain Developer",
      "IoT Developer (Internet of Things)",
      "Smart Contract Developer",
      "Game Developer",
      "Video Game Designer",
      "Game Tester",
      "E-commerce Specialist",
      "Digital Marketing Specialist",
      "SEO Specialist",
      "Content Manager",
      "IT Infrastructure Engineer",
      "IT Operations Analyst",
      "IT Support Manager",
      "Application Support Analyst",
      "ERP Support Specialist",
      "IT Trainer",
      "Software Quality Analyst",
      "Data Visualization Specialist",
      "AI Research Scientist",
      "IT Risk Manager",
      "Cloud Platform Engineer",
      "Network Security Engineer",
      "Network Consultant",
      "Data Privacy Officer",
      "IT Governance Specialist",
      "Chief Data Officer (CDO)",
      "Full Stack Software Engineer",
      "Web Application Developer",
      "Backend Systems Developer",
      "Microservices Developer",
      "API Integration Specialist",
      "Functional Consultant",
      "Technical Consultant",
      "System Integration Specialist",
      "Configuration Manager",
      "Release Coordinator",
      "Version Control Specialist",
      "Embedded Systems Developer",
      "Field Service Engineer",
      "VoIP Engineer",
      "Cloud Migration Specialist",
      "IT Business Partner",
      "AI/ML Product Manager",
      "Platform Engineer",
      "IT Service Delivery Manager",
      "Enterprise Solutions Consultant",
      "Digital Product Manager"
    ];

    return list;
  }
  // profile creation ----------------------------------------------------------

  Future<void> profileCreation(
    String email,
    String fullName,
    String address,
    DateTime birthDay,
    String profileInfo,
    String education,
    String university,
    String position,
  ) async {
    _logUtils.log(":::: profileCreation ::::");
    state = state.copyWith(
      isProfileCreate: false,
      isLoading: true,
      responseFailure: none(),
      profileCreationResponse: none(),
    );

    final profileCreationRequest = ProfileCreationRequest(
      email: email,
      fullName: fullName,
      address: address,
      birthDay: "1998-12-12",
      profileInfo: profileInfo,
      education: education,
      university: university,
      position: position,
      // skillList: skill.toImmutableList(),
      //skillList: state.results.toImmutableList(),
      skillList: ["Java", "MySQL", "Springboot", "Angular"],
    );

    _logUtils.log(":::: profileCreationRequest :::: $profileCreationRequest");

    final profileCreationSucessOrFailure = await _profileCreationRepository
        .profileCreation(profileCreationRequest);

    // store profile detail in local storage ---------------------------------
    _localRepository.createOrUpdate('profile_email', email);
    _localRepository.createOrUpdate('profile_full_name', fullName);
    _localRepository.createOrUpdate('profile_address', address);
    _localRepository.createOrUpdate('profile_info', profileInfo);
    _localRepository.createOrUpdate('profile_education', education);
    _localRepository.createOrUpdate('profile_university', university);
    _localRepository.createOrUpdate('profile_postion', position);
    _localRepository.createOrUpdate('is_Profile_Create', true.toString());

    state = state.copyWith(
      isProfileCreate: false,
    );

    profileCreationSucessOrFailure.fold((failure) {
      state = state.copyWith(
        isProfileCreate: false,
        isLoading: false,
        responseFailure: optionOf(failure),
      );
    }, (response) {
      _localRepository.createOrUpdate('is_logged_in', true.toString());

      state = state.copyWith(
        isProfileCreate: true,
        isLoading: false,
        responseFailure: none(),
        profileCreationResponse: optionOf(response),
      );
    });
  }

  // apply Vacancy -------------------------------------------------------------

  Future<void> applyJobVacancy({
    required String userID,
    required String hiringAnnouncementID,
  }) async {
    _logUtils.log(":::: profileCreation ::::");
    state = state.copyWith(
      isAddVacancy: true,
      responseFailure: none(),
      applyToVacancyResponse: none(),
    );

    final applyToVacancyRequest = ApplyToVacancyRequest(
      userID: userID,
      hiringAnnouncementID: hiringAnnouncementID,
    );

    _logUtils.log(":::: add New Project Request :::: $applyToVacancyRequest");

    final applyJobSucessOrFailure =
        await _profileCreationRepository.applyJob(applyToVacancyRequest);

    applyJobSucessOrFailure.fold((failure) {
      state = state.copyWith(
        isAddVacancy: false,
        responseFailure: optionOf(failure),
      );
    }, (response) {
      state = state.copyWith(
        isAddVacancy: false,
        responseFailure: none(),
        applyToVacancyResponse: optionOf(response),
      );
    });
  }

  // get Profile Details -------------------------------------------------------

  Future<void> getProfileDetail(String email) async {
    _logUtils.log(":::: get Profile Detail  :::: $email");
    state = state.copyWith(
      isProfileCreate: false,
      isLoading: true,
      responseFailure: none(),
      profileCreationResponse: none(),
    );

    //final getProfileDetailRequest = getProfileDetail(email);

    //_logUtils.log(":::: profileCreationRequest :::: ");

    final getProfileDetailSucessOrFailure =
        await _profileCreationRepository.getUserProfileDetail(email);

    _logUtils.log(
        ":::: get Profile Detail Sucess Or Failure :::: $getProfileDetailSucessOrFailure");

    getProfileDetailSucessOrFailure.fold((failure) {
      state = state.copyWith(
        isProfileCreate: false,
        isLoading: false,
        responseFailure: optionOf(failure),
      );
    }, (response) {
      state = state.copyWith(
        isProfileCreate: true,
        isLoading: false,
        responseFailure: none(),
        getUserProfileResponse: optionOf(response),
        userProfileID: response.data.userProfileID,
        fullName: response.data.fullName,
        profileInfo: response.data.profileInfo,
        address: response.data.address,
        birthDay: response.data.birthDay.toString(),
        contact: response.data.contact,
        email: response.data.email,
        education: response.data.education,
        university: response.data.university,
        position: response.data.position,
        projectDetailList: response.data.projectDTOS,
      );
    });
  }

  // Add new Projjects ---------------------------------------------------------

  Future<void> addNewProjects({
    required String userProfileID,
    required String projectName,
    required String projectDescription,
  }) async {
    _logUtils.log(":::: profileCreation ::::");
    state = state.copyWith(
      isAddProjectLoading: true,
      responseFailure: none(),
      addNewProjectResponse: none(),
    );

    final addNewProjectRequest = AddNewProjectRequest(
      description: projectDescription,
      project_name: projectName,
      user_profile_id: userProfileID,
      used_skills: ["Java", "MySQL", "Springboot", "Angular"].toImmutableList(),
    );

    _logUtils.log(":::: add New Project Request :::: $addNewProjectRequest");

    final profileCreationSucessOrFailure =
        await _profileCreationRepository.addNewProject(addNewProjectRequest);

    profileCreationSucessOrFailure.fold((failure) {
      state = state.copyWith(
        isAddProjectLoading: false,
        responseFailure: optionOf(failure),
      );
    }, (response) {
      state = state.copyWith(
        isAddProjectLoading: false,
        responseFailure: none(),
        addNewProjectResponse: optionOf(response),
      );
    });
  }

  // remove Projjects ---------------------------------------------------------

  Future<void> removeProjects({
    required String projectID,
  }) async {
    state = state.copyWith(
      isAddProjectLoading: true,
      isRemoveProject: false,
      responseFailure: none(),
      removeProjectResponse: none(),
    );

    final profileCreationSucessOrFailure =
        await _profileCreationRepository.removeProject(projectID);

    profileCreationSucessOrFailure.fold((failure) {
      state = state.copyWith(
        isRemoveProject: false,
        isAddProjectLoading: false,
        responseFailure: optionOf(failure),
      );
    }, (response) {
      state = state.copyWith(
        isRemoveProject: true,
        isAddProjectLoading: false,
        responseFailure: none(),
        addNewProjectResponse: optionOf(response),
      );
    });
  }

  // Click Filter -------------------------------------------------------

  void clickFilter() {
    if (state.isClickFilter) {
      state = state.copyWith(
        isClickFilter: false,
      );
      _logUtils.log("::::Filter  Section Open");
    } else {
      state = state.copyWith(
        isClickFilter: true,
      );
      _logUtils.log("::::Filter  Section close");
    }
  }

  // --------

  void isClickSearchButton(bool value) {
    _logUtils.log("::::is Click Searc hButton value :::: $value");

    if (value) {
      _logUtils.log(":::: isClickSearchButton :::: true");
      state = state.copyWith(
        isClickFilter: false,
      );
    } else {
      _logUtils.log(":::: isClickSearchButton :::: false");

      state = state.copyWith(
        isClickFilter: true,
      );
    }
  }

  // Is Click Job Filter -------------------------------------------------------

  void clickFilterSection() {
    if (state.isClickFilter) {
      state = state.copyWith(
        isOpenFilterSection: true,
      );
    } else {
      state = state.copyWith(
        isOpenFilterSection: false,
      );
    }
  }

  // Job Filter ----------------------------------------------------------------

  Future<void> searchJob({
    required String jobType,
    required String location,
    required String companyName,
  }) async {
    state = state.copyWith(
      isSearchJobLoading: true,
      responseFailure: none(),
    );

    final searchJobsRequest = SearchJobsRequest(
      location: location,
      companyName: companyName,
      jobType: jobType,
    );

    _logUtils.log(":::: searchJobsRequest :::: $searchJobsRequest");

    final profileCreationSucessOrFailure =
        await _profileCreationRepository.searchJob(searchJobsRequest);

    profileCreationSucessOrFailure.fold((failure) {
      state = state.copyWith(
        isSearchJobLoading: false,
        responseFailure: optionOf(failure),
      );
    }, (response) {
      state = state.copyWith(
        isSearchJobLoading: false,
        responseFailure: none(),
        // searchJobResponse: optionOf(response),
      );
    });
  }
}
