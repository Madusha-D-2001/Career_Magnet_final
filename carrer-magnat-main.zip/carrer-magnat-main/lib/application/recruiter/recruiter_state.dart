import 'package:dartz/dartz.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kt_dart/kt.dart';

import '../../domain/add_hiring_announcement/add_hiring_announcement_response.dart';
import '../../domain/core/failure.dart';
import '../../domain/get_All_Applied_User_Profiles_By_Hiring_ID/get_All_Applied_User_Profiles_By_Hiring_ID_data.dart';
import '../../domain/get_All_Applied_User_Profiles_By_Hiring_ID/get_All_Applied_User_Profiles_By_Hiring_ID_response.dart';
import '../../domain/get_all_posted_jobs_by_recruiter_id/get_all_posted_jobs_by_recruiter_data.dart';
import '../../domain/get_all_posted_jobs_by_recruiter_id/get_all_posted_jobs_by_recruiter_id_request.dart';

part 'recruiter_state.freezed.dart';

@freezed
class RecruiterState with _$RecruiterState {
  factory RecruiterState({
    required bool isLoadingAddHiring,
    required String JobType,
    required bool isLoadingReply,
    required bool isLoadingGetAllAppliedUser,
    required bool isdeleteHiringAnnouncementLoading,
    required bool isDeleteHiringAnnouncement,
    required bool isLoadingGetPostedJobs,
    required List<String> skillList,
    required KtList<GetAllPostedJobsByRecruiterData>
        getAllPostedJobsByRecruiterIDList,
    required KtList<GetAllAppliedUserProfilesByHiringIdData>
        getAllAppliedUserProfilesByHiringIDList,
    required Option<Failure> responseFailure,
    required Option<AddHiringAnnouncementResponse>
        addHiringAnnouncementResponse,
    required Option<AddHiringAnnouncementResponse>
        deleteHiringAnnouncementResponse,
    required Option<GetAllPostedJobsByRecruiterIdRequest>
        getAllPostedJobsByRecruiterIDResponse,
    required Option<GetAllAppliedUserProfilesByHiringIdResponse>
        getAllAppliedUserProfilesByHiringIDResponse,
    required Option<AddHiringAnnouncementResponse> sendReplyResponse,
  }) = _RecruiterState;

  factory RecruiterState.initial() {
    return RecruiterState(
      JobType: "Full Stack Developer",
      isdeleteHiringAnnouncementLoading: false,
      isDeleteHiringAnnouncement: false,
      isLoadingReply: false,
      isLoadingAddHiring: false,
      isLoadingGetPostedJobs: false,
      isLoadingGetAllAppliedUser: false,
      skillList: [],
      getAllPostedJobsByRecruiterIDList: emptyList(),
      getAllAppliedUserProfilesByHiringIDList: emptyList(),
      responseFailure: none(),
      addHiringAnnouncementResponse: none(),
      deleteHiringAnnouncementResponse: none(),
      getAllPostedJobsByRecruiterIDResponse: none(),
      getAllAppliedUserProfilesByHiringIDResponse: none(),
      sendReplyResponse: none(),
    );
  }
}
