// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'recruiter_state.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$RecruiterState {
  bool get isLoadingAddHiring => throw _privateConstructorUsedError;
  String get JobType => throw _privateConstructorUsedError;
  bool get isLoadingReply => throw _privateConstructorUsedError;
  bool get isLoadingGetAllAppliedUser => throw _privateConstructorUsedError;
  bool get isdeleteHiringAnnouncementLoading =>
      throw _privateConstructorUsedError;
  bool get isDeleteHiringAnnouncement => throw _privateConstructorUsedError;
  bool get isLoadingGetPostedJobs => throw _privateConstructorUsedError;
  List<String> get skillList => throw _privateConstructorUsedError;
  KtList<GetAllPostedJobsByRecruiterData>
      get getAllPostedJobsByRecruiterIDList =>
          throw _privateConstructorUsedError;
  KtList<GetAllAppliedUserProfilesByHiringIdData>
      get getAllAppliedUserProfilesByHiringIDList =>
          throw _privateConstructorUsedError;
  Option<Failure> get responseFailure => throw _privateConstructorUsedError;
  Option<AddHiringAnnouncementResponse> get addHiringAnnouncementResponse =>
      throw _privateConstructorUsedError;
  Option<AddHiringAnnouncementResponse> get deleteHiringAnnouncementResponse =>
      throw _privateConstructorUsedError;
  Option<GetAllPostedJobsByRecruiterIdRequest>
      get getAllPostedJobsByRecruiterIDResponse =>
          throw _privateConstructorUsedError;
  Option<GetAllAppliedUserProfilesByHiringIdResponse>
      get getAllAppliedUserProfilesByHiringIDResponse =>
          throw _privateConstructorUsedError;
  Option<AddHiringAnnouncementResponse> get sendReplyResponse =>
      throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $RecruiterStateCopyWith<RecruiterState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $RecruiterStateCopyWith<$Res> {
  factory $RecruiterStateCopyWith(
          RecruiterState value, $Res Function(RecruiterState) then) =
      _$RecruiterStateCopyWithImpl<$Res, RecruiterState>;
  @useResult
  $Res call(
      {bool isLoadingAddHiring,
      String JobType,
      bool isLoadingReply,
      bool isLoadingGetAllAppliedUser,
      bool isdeleteHiringAnnouncementLoading,
      bool isDeleteHiringAnnouncement,
      bool isLoadingGetPostedJobs,
      List<String> skillList,
      KtList<GetAllPostedJobsByRecruiterData> getAllPostedJobsByRecruiterIDList,
      KtList<GetAllAppliedUserProfilesByHiringIdData>
          getAllAppliedUserProfilesByHiringIDList,
      Option<Failure> responseFailure,
      Option<AddHiringAnnouncementResponse> addHiringAnnouncementResponse,
      Option<AddHiringAnnouncementResponse> deleteHiringAnnouncementResponse,
      Option<GetAllPostedJobsByRecruiterIdRequest>
          getAllPostedJobsByRecruiterIDResponse,
      Option<GetAllAppliedUserProfilesByHiringIdResponse>
          getAllAppliedUserProfilesByHiringIDResponse,
      Option<AddHiringAnnouncementResponse> sendReplyResponse});
}

/// @nodoc
class _$RecruiterStateCopyWithImpl<$Res, $Val extends RecruiterState>
    implements $RecruiterStateCopyWith<$Res> {
  _$RecruiterStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isLoadingAddHiring = null,
    Object? JobType = null,
    Object? isLoadingReply = null,
    Object? isLoadingGetAllAppliedUser = null,
    Object? isdeleteHiringAnnouncementLoading = null,
    Object? isDeleteHiringAnnouncement = null,
    Object? isLoadingGetPostedJobs = null,
    Object? skillList = null,
    Object? getAllPostedJobsByRecruiterIDList = null,
    Object? getAllAppliedUserProfilesByHiringIDList = null,
    Object? responseFailure = null,
    Object? addHiringAnnouncementResponse = null,
    Object? deleteHiringAnnouncementResponse = null,
    Object? getAllPostedJobsByRecruiterIDResponse = null,
    Object? getAllAppliedUserProfilesByHiringIDResponse = null,
    Object? sendReplyResponse = null,
  }) {
    return _then(_value.copyWith(
      isLoadingAddHiring: null == isLoadingAddHiring
          ? _value.isLoadingAddHiring
          : isLoadingAddHiring // ignore: cast_nullable_to_non_nullable
              as bool,
      JobType: null == JobType
          ? _value.JobType
          : JobType // ignore: cast_nullable_to_non_nullable
              as String,
      isLoadingReply: null == isLoadingReply
          ? _value.isLoadingReply
          : isLoadingReply // ignore: cast_nullable_to_non_nullable
              as bool,
      isLoadingGetAllAppliedUser: null == isLoadingGetAllAppliedUser
          ? _value.isLoadingGetAllAppliedUser
          : isLoadingGetAllAppliedUser // ignore: cast_nullable_to_non_nullable
              as bool,
      isdeleteHiringAnnouncementLoading: null ==
              isdeleteHiringAnnouncementLoading
          ? _value.isdeleteHiringAnnouncementLoading
          : isdeleteHiringAnnouncementLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isDeleteHiringAnnouncement: null == isDeleteHiringAnnouncement
          ? _value.isDeleteHiringAnnouncement
          : isDeleteHiringAnnouncement // ignore: cast_nullable_to_non_nullable
              as bool,
      isLoadingGetPostedJobs: null == isLoadingGetPostedJobs
          ? _value.isLoadingGetPostedJobs
          : isLoadingGetPostedJobs // ignore: cast_nullable_to_non_nullable
              as bool,
      skillList: null == skillList
          ? _value.skillList
          : skillList // ignore: cast_nullable_to_non_nullable
              as List<String>,
      getAllPostedJobsByRecruiterIDList: null ==
              getAllPostedJobsByRecruiterIDList
          ? _value.getAllPostedJobsByRecruiterIDList
          : getAllPostedJobsByRecruiterIDList // ignore: cast_nullable_to_non_nullable
              as KtList<GetAllPostedJobsByRecruiterData>,
      getAllAppliedUserProfilesByHiringIDList: null ==
              getAllAppliedUserProfilesByHiringIDList
          ? _value.getAllAppliedUserProfilesByHiringIDList
          : getAllAppliedUserProfilesByHiringIDList // ignore: cast_nullable_to_non_nullable
              as KtList<GetAllAppliedUserProfilesByHiringIdData>,
      responseFailure: null == responseFailure
          ? _value.responseFailure
          : responseFailure // ignore: cast_nullable_to_non_nullable
              as Option<Failure>,
      addHiringAnnouncementResponse: null == addHiringAnnouncementResponse
          ? _value.addHiringAnnouncementResponse
          : addHiringAnnouncementResponse // ignore: cast_nullable_to_non_nullable
              as Option<AddHiringAnnouncementResponse>,
      deleteHiringAnnouncementResponse: null == deleteHiringAnnouncementResponse
          ? _value.deleteHiringAnnouncementResponse
          : deleteHiringAnnouncementResponse // ignore: cast_nullable_to_non_nullable
              as Option<AddHiringAnnouncementResponse>,
      getAllPostedJobsByRecruiterIDResponse: null ==
              getAllPostedJobsByRecruiterIDResponse
          ? _value.getAllPostedJobsByRecruiterIDResponse
          : getAllPostedJobsByRecruiterIDResponse // ignore: cast_nullable_to_non_nullable
              as Option<GetAllPostedJobsByRecruiterIdRequest>,
      getAllAppliedUserProfilesByHiringIDResponse: null ==
              getAllAppliedUserProfilesByHiringIDResponse
          ? _value.getAllAppliedUserProfilesByHiringIDResponse
          : getAllAppliedUserProfilesByHiringIDResponse // ignore: cast_nullable_to_non_nullable
              as Option<GetAllAppliedUserProfilesByHiringIdResponse>,
      sendReplyResponse: null == sendReplyResponse
          ? _value.sendReplyResponse
          : sendReplyResponse // ignore: cast_nullable_to_non_nullable
              as Option<AddHiringAnnouncementResponse>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$RecruiterStateImplCopyWith<$Res>
    implements $RecruiterStateCopyWith<$Res> {
  factory _$$RecruiterStateImplCopyWith(_$RecruiterStateImpl value,
          $Res Function(_$RecruiterStateImpl) then) =
      __$$RecruiterStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {bool isLoadingAddHiring,
      String JobType,
      bool isLoadingReply,
      bool isLoadingGetAllAppliedUser,
      bool isdeleteHiringAnnouncementLoading,
      bool isDeleteHiringAnnouncement,
      bool isLoadingGetPostedJobs,
      List<String> skillList,
      KtList<GetAllPostedJobsByRecruiterData> getAllPostedJobsByRecruiterIDList,
      KtList<GetAllAppliedUserProfilesByHiringIdData>
          getAllAppliedUserProfilesByHiringIDList,
      Option<Failure> responseFailure,
      Option<AddHiringAnnouncementResponse> addHiringAnnouncementResponse,
      Option<AddHiringAnnouncementResponse> deleteHiringAnnouncementResponse,
      Option<GetAllPostedJobsByRecruiterIdRequest>
          getAllPostedJobsByRecruiterIDResponse,
      Option<GetAllAppliedUserProfilesByHiringIdResponse>
          getAllAppliedUserProfilesByHiringIDResponse,
      Option<AddHiringAnnouncementResponse> sendReplyResponse});
}

/// @nodoc
class __$$RecruiterStateImplCopyWithImpl<$Res>
    extends _$RecruiterStateCopyWithImpl<$Res, _$RecruiterStateImpl>
    implements _$$RecruiterStateImplCopyWith<$Res> {
  __$$RecruiterStateImplCopyWithImpl(
      _$RecruiterStateImpl _value, $Res Function(_$RecruiterStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isLoadingAddHiring = null,
    Object? JobType = null,
    Object? isLoadingReply = null,
    Object? isLoadingGetAllAppliedUser = null,
    Object? isdeleteHiringAnnouncementLoading = null,
    Object? isDeleteHiringAnnouncement = null,
    Object? isLoadingGetPostedJobs = null,
    Object? skillList = null,
    Object? getAllPostedJobsByRecruiterIDList = null,
    Object? getAllAppliedUserProfilesByHiringIDList = null,
    Object? responseFailure = null,
    Object? addHiringAnnouncementResponse = null,
    Object? deleteHiringAnnouncementResponse = null,
    Object? getAllPostedJobsByRecruiterIDResponse = null,
    Object? getAllAppliedUserProfilesByHiringIDResponse = null,
    Object? sendReplyResponse = null,
  }) {
    return _then(_$RecruiterStateImpl(
      isLoadingAddHiring: null == isLoadingAddHiring
          ? _value.isLoadingAddHiring
          : isLoadingAddHiring // ignore: cast_nullable_to_non_nullable
              as bool,
      JobType: null == JobType
          ? _value.JobType
          : JobType // ignore: cast_nullable_to_non_nullable
              as String,
      isLoadingReply: null == isLoadingReply
          ? _value.isLoadingReply
          : isLoadingReply // ignore: cast_nullable_to_non_nullable
              as bool,
      isLoadingGetAllAppliedUser: null == isLoadingGetAllAppliedUser
          ? _value.isLoadingGetAllAppliedUser
          : isLoadingGetAllAppliedUser // ignore: cast_nullable_to_non_nullable
              as bool,
      isdeleteHiringAnnouncementLoading: null ==
              isdeleteHiringAnnouncementLoading
          ? _value.isdeleteHiringAnnouncementLoading
          : isdeleteHiringAnnouncementLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isDeleteHiringAnnouncement: null == isDeleteHiringAnnouncement
          ? _value.isDeleteHiringAnnouncement
          : isDeleteHiringAnnouncement // ignore: cast_nullable_to_non_nullable
              as bool,
      isLoadingGetPostedJobs: null == isLoadingGetPostedJobs
          ? _value.isLoadingGetPostedJobs
          : isLoadingGetPostedJobs // ignore: cast_nullable_to_non_nullable
              as bool,
      skillList: null == skillList
          ? _value._skillList
          : skillList // ignore: cast_nullable_to_non_nullable
              as List<String>,
      getAllPostedJobsByRecruiterIDList: null ==
              getAllPostedJobsByRecruiterIDList
          ? _value.getAllPostedJobsByRecruiterIDList
          : getAllPostedJobsByRecruiterIDList // ignore: cast_nullable_to_non_nullable
              as KtList<GetAllPostedJobsByRecruiterData>,
      getAllAppliedUserProfilesByHiringIDList: null ==
              getAllAppliedUserProfilesByHiringIDList
          ? _value.getAllAppliedUserProfilesByHiringIDList
          : getAllAppliedUserProfilesByHiringIDList // ignore: cast_nullable_to_non_nullable
              as KtList<GetAllAppliedUserProfilesByHiringIdData>,
      responseFailure: null == responseFailure
          ? _value.responseFailure
          : responseFailure // ignore: cast_nullable_to_non_nullable
              as Option<Failure>,
      addHiringAnnouncementResponse: null == addHiringAnnouncementResponse
          ? _value.addHiringAnnouncementResponse
          : addHiringAnnouncementResponse // ignore: cast_nullable_to_non_nullable
              as Option<AddHiringAnnouncementResponse>,
      deleteHiringAnnouncementResponse: null == deleteHiringAnnouncementResponse
          ? _value.deleteHiringAnnouncementResponse
          : deleteHiringAnnouncementResponse // ignore: cast_nullable_to_non_nullable
              as Option<AddHiringAnnouncementResponse>,
      getAllPostedJobsByRecruiterIDResponse: null ==
              getAllPostedJobsByRecruiterIDResponse
          ? _value.getAllPostedJobsByRecruiterIDResponse
          : getAllPostedJobsByRecruiterIDResponse // ignore: cast_nullable_to_non_nullable
              as Option<GetAllPostedJobsByRecruiterIdRequest>,
      getAllAppliedUserProfilesByHiringIDResponse: null ==
              getAllAppliedUserProfilesByHiringIDResponse
          ? _value.getAllAppliedUserProfilesByHiringIDResponse
          : getAllAppliedUserProfilesByHiringIDResponse // ignore: cast_nullable_to_non_nullable
              as Option<GetAllAppliedUserProfilesByHiringIdResponse>,
      sendReplyResponse: null == sendReplyResponse
          ? _value.sendReplyResponse
          : sendReplyResponse // ignore: cast_nullable_to_non_nullable
              as Option<AddHiringAnnouncementResponse>,
    ));
  }
}

/// @nodoc

class _$RecruiterStateImpl implements _RecruiterState {
  _$RecruiterStateImpl(
      {required this.isLoadingAddHiring,
      required this.JobType,
      required this.isLoadingReply,
      required this.isLoadingGetAllAppliedUser,
      required this.isdeleteHiringAnnouncementLoading,
      required this.isDeleteHiringAnnouncement,
      required this.isLoadingGetPostedJobs,
      required final List<String> skillList,
      required this.getAllPostedJobsByRecruiterIDList,
      required this.getAllAppliedUserProfilesByHiringIDList,
      required this.responseFailure,
      required this.addHiringAnnouncementResponse,
      required this.deleteHiringAnnouncementResponse,
      required this.getAllPostedJobsByRecruiterIDResponse,
      required this.getAllAppliedUserProfilesByHiringIDResponse,
      required this.sendReplyResponse})
      : _skillList = skillList;

  @override
  final bool isLoadingAddHiring;
  @override
  final String JobType;
  @override
  final bool isLoadingReply;
  @override
  final bool isLoadingGetAllAppliedUser;
  @override
  final bool isdeleteHiringAnnouncementLoading;
  @override
  final bool isDeleteHiringAnnouncement;
  @override
  final bool isLoadingGetPostedJobs;
  final List<String> _skillList;
  @override
  List<String> get skillList {
    if (_skillList is EqualUnmodifiableListView) return _skillList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_skillList);
  }

  @override
  final KtList<GetAllPostedJobsByRecruiterData>
      getAllPostedJobsByRecruiterIDList;
  @override
  final KtList<GetAllAppliedUserProfilesByHiringIdData>
      getAllAppliedUserProfilesByHiringIDList;
  @override
  final Option<Failure> responseFailure;
  @override
  final Option<AddHiringAnnouncementResponse> addHiringAnnouncementResponse;
  @override
  final Option<AddHiringAnnouncementResponse> deleteHiringAnnouncementResponse;
  @override
  final Option<GetAllPostedJobsByRecruiterIdRequest>
      getAllPostedJobsByRecruiterIDResponse;
  @override
  final Option<GetAllAppliedUserProfilesByHiringIdResponse>
      getAllAppliedUserProfilesByHiringIDResponse;
  @override
  final Option<AddHiringAnnouncementResponse> sendReplyResponse;

  @override
  String toString() {
    return 'RecruiterState(isLoadingAddHiring: $isLoadingAddHiring, JobType: $JobType, isLoadingReply: $isLoadingReply, isLoadingGetAllAppliedUser: $isLoadingGetAllAppliedUser, isdeleteHiringAnnouncementLoading: $isdeleteHiringAnnouncementLoading, isDeleteHiringAnnouncement: $isDeleteHiringAnnouncement, isLoadingGetPostedJobs: $isLoadingGetPostedJobs, skillList: $skillList, getAllPostedJobsByRecruiterIDList: $getAllPostedJobsByRecruiterIDList, getAllAppliedUserProfilesByHiringIDList: $getAllAppliedUserProfilesByHiringIDList, responseFailure: $responseFailure, addHiringAnnouncementResponse: $addHiringAnnouncementResponse, deleteHiringAnnouncementResponse: $deleteHiringAnnouncementResponse, getAllPostedJobsByRecruiterIDResponse: $getAllPostedJobsByRecruiterIDResponse, getAllAppliedUserProfilesByHiringIDResponse: $getAllAppliedUserProfilesByHiringIDResponse, sendReplyResponse: $sendReplyResponse)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RecruiterStateImpl &&
            (identical(other.isLoadingAddHiring, isLoadingAddHiring) ||
                other.isLoadingAddHiring == isLoadingAddHiring) &&
            (identical(other.JobType, JobType) || other.JobType == JobType) &&
            (identical(other.isLoadingReply, isLoadingReply) ||
                other.isLoadingReply == isLoadingReply) &&
            (identical(other.isLoadingGetAllAppliedUser, isLoadingGetAllAppliedUser) ||
                other.isLoadingGetAllAppliedUser ==
                    isLoadingGetAllAppliedUser) &&
            (identical(other.isdeleteHiringAnnouncementLoading, isdeleteHiringAnnouncementLoading) ||
                other.isdeleteHiringAnnouncementLoading ==
                    isdeleteHiringAnnouncementLoading) &&
            (identical(other.isDeleteHiringAnnouncement, isDeleteHiringAnnouncement) ||
                other.isDeleteHiringAnnouncement ==
                    isDeleteHiringAnnouncement) &&
            (identical(other.isLoadingGetPostedJobs, isLoadingGetPostedJobs) ||
                other.isLoadingGetPostedJobs == isLoadingGetPostedJobs) &&
            const DeepCollectionEquality()
                .equals(other._skillList, _skillList) &&
            (identical(other.getAllPostedJobsByRecruiterIDList, getAllPostedJobsByRecruiterIDList) ||
                other.getAllPostedJobsByRecruiterIDList ==
                    getAllPostedJobsByRecruiterIDList) &&
            (identical(other.getAllAppliedUserProfilesByHiringIDList, getAllAppliedUserProfilesByHiringIDList) ||
                other.getAllAppliedUserProfilesByHiringIDList ==
                    getAllAppliedUserProfilesByHiringIDList) &&
            (identical(other.responseFailure, responseFailure) ||
                other.responseFailure == responseFailure) &&
            (identical(other.addHiringAnnouncementResponse, addHiringAnnouncementResponse) ||
                other.addHiringAnnouncementResponse ==
                    addHiringAnnouncementResponse) &&
            (identical(other.deleteHiringAnnouncementResponse, deleteHiringAnnouncementResponse) ||
                other.deleteHiringAnnouncementResponse ==
                    deleteHiringAnnouncementResponse) &&
            (identical(other.getAllPostedJobsByRecruiterIDResponse, getAllPostedJobsByRecruiterIDResponse) ||
                other.getAllPostedJobsByRecruiterIDResponse ==
                    getAllPostedJobsByRecruiterIDResponse) &&
            (identical(other.getAllAppliedUserProfilesByHiringIDResponse,
                    getAllAppliedUserProfilesByHiringIDResponse) ||
                other.getAllAppliedUserProfilesByHiringIDResponse ==
                    getAllAppliedUserProfilesByHiringIDResponse) &&
            (identical(other.sendReplyResponse, sendReplyResponse) || other.sendReplyResponse == sendReplyResponse));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      isLoadingAddHiring,
      JobType,
      isLoadingReply,
      isLoadingGetAllAppliedUser,
      isdeleteHiringAnnouncementLoading,
      isDeleteHiringAnnouncement,
      isLoadingGetPostedJobs,
      const DeepCollectionEquality().hash(_skillList),
      getAllPostedJobsByRecruiterIDList,
      getAllAppliedUserProfilesByHiringIDList,
      responseFailure,
      addHiringAnnouncementResponse,
      deleteHiringAnnouncementResponse,
      getAllPostedJobsByRecruiterIDResponse,
      getAllAppliedUserProfilesByHiringIDResponse,
      sendReplyResponse);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$RecruiterStateImplCopyWith<_$RecruiterStateImpl> get copyWith =>
      __$$RecruiterStateImplCopyWithImpl<_$RecruiterStateImpl>(
          this, _$identity);
}

abstract class _RecruiterState implements RecruiterState {
  factory _RecruiterState(
      {required final bool isLoadingAddHiring,
      required final String JobType,
      required final bool isLoadingReply,
      required final bool isLoadingGetAllAppliedUser,
      required final bool isdeleteHiringAnnouncementLoading,
      required final bool isDeleteHiringAnnouncement,
      required final bool isLoadingGetPostedJobs,
      required final List<String> skillList,
      required final KtList<GetAllPostedJobsByRecruiterData>
          getAllPostedJobsByRecruiterIDList,
      required final KtList<GetAllAppliedUserProfilesByHiringIdData>
          getAllAppliedUserProfilesByHiringIDList,
      required final Option<Failure> responseFailure,
      required final Option<AddHiringAnnouncementResponse>
          addHiringAnnouncementResponse,
      required final Option<AddHiringAnnouncementResponse>
          deleteHiringAnnouncementResponse,
      required final Option<GetAllPostedJobsByRecruiterIdRequest>
          getAllPostedJobsByRecruiterIDResponse,
      required final Option<GetAllAppliedUserProfilesByHiringIdResponse>
          getAllAppliedUserProfilesByHiringIDResponse,
      required final Option<AddHiringAnnouncementResponse>
          sendReplyResponse}) = _$RecruiterStateImpl;

  @override
  bool get isLoadingAddHiring;
  @override
  String get JobType;
  @override
  bool get isLoadingReply;
  @override
  bool get isLoadingGetAllAppliedUser;
  @override
  bool get isdeleteHiringAnnouncementLoading;
  @override
  bool get isDeleteHiringAnnouncement;
  @override
  bool get isLoadingGetPostedJobs;
  @override
  List<String> get skillList;
  @override
  KtList<GetAllPostedJobsByRecruiterData> get getAllPostedJobsByRecruiterIDList;
  @override
  KtList<GetAllAppliedUserProfilesByHiringIdData>
      get getAllAppliedUserProfilesByHiringIDList;
  @override
  Option<Failure> get responseFailure;
  @override
  Option<AddHiringAnnouncementResponse> get addHiringAnnouncementResponse;
  @override
  Option<AddHiringAnnouncementResponse> get deleteHiringAnnouncementResponse;
  @override
  Option<GetAllPostedJobsByRecruiterIdRequest>
      get getAllPostedJobsByRecruiterIDResponse;
  @override
  Option<GetAllAppliedUserProfilesByHiringIdResponse>
      get getAllAppliedUserProfilesByHiringIDResponse;
  @override
  Option<AddHiringAnnouncementResponse> get sendReplyResponse;
  @override
  @JsonKey(ignore: true)
  _$$RecruiterStateImplCopyWith<_$RecruiterStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
