import 'package:carrermagnet/domain/add_hiring_announcement/add_hiring_announcement_request.dart';
import 'package:carrermagnet/utils/log_utils.dart';
import 'package:dartz/dartz.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:kt_dart/kt.dart';

import '../../domain/core/i_local_repository.dart';
import '../../domain/recruiter/i_recruiter_repository.dart';
import '../../domain/response_To_Application/response_to_application.dart';
import 'recruiter_state.dart';

class RecruiterStateNotifier extends StateNotifier<RecruiterState> {
  RecruiterStateNotifier(
    this._recruiterRepository,
    this._localRepository,
  ) : super(RecruiterState.initial()) {
    _logUtils.log("init");
  }

  final IRecruiterRepository _recruiterRepository;
  final ILocalRepository _localRepository;

  static final LogUtils _logUtils = LogUtils(
    featureName: "Recruiter State Notifier",
    printLog: true,
  );

  setJobType({required String JobType}) {
    state = state.copyWith(
      JobType: JobType,
    );
  }

  setSkillsToList(List<String> skilResults) {
    state = state.copyWith(
      skillList: skilResults,
    );

    _logUtils.log(":::: ${state.skillList} ::::");
  }

  //add Hiring Announcement -----------------------------------------------------

  Future<void> addHiringAnnouncement({
    required String recruiterID,
    required String jobDescription,
    required String jobType,
    required String location,
    required String companyName,
    required DateTime postedDate,
    required DateTime closeDate,
  }) async {
    _logUtils.log(":::: add Hiring Announcement ::::");
    state = state.copyWith(
      isLoadingAddHiring: true,
      responseFailure: none(),
      addHiringAnnouncementResponse: none(),
    );

    // final DateTime postedDate = DateTime.utc(2024, 10, 1, 9, 0, 0);

    // Assuming closeDateString is a String

    final addHiringAnnouncementRequest = AddHiringAnnouncementRequest(
      recruiterID: recruiterID,
      jobDescription: jobDescription,
      jobType: state.JobType,
      location: location,
      companyName: companyName,
      postedDate: postedDate,
      closeDate: closeDate,
      skillList: state.skillList.toImmutableList(),
    );

    _logUtils
        .log(":::: add Hiring Announcement :::: $addHiringAnnouncementRequest");

    final addHiringSucessOrFailure = await _recruiterRepository
        .addHiringAnnouncement(addHiringAnnouncementRequest);

    addHiringSucessOrFailure.fold((failure) {
      state = state.copyWith(
        isLoadingAddHiring: false,
        responseFailure: optionOf(failure),
      );
    }, (response) {
      state = state.copyWith(
        isLoadingAddHiring: false,
        responseFailure: none(),
        addHiringAnnouncementResponse: optionOf(response),
      );
    });
  }

  //  get All Posted Jobs By Recruiter ID --------------------------------------

  Future<void> getAllPostedJobsByRecruiterID(
      {required String recruiterID}) async {
    _logUtils.log(":::: get All Posted Jobs By Recruiter ID::::");
    state = state.copyWith(
      isLoadingGetPostedJobs: true,
      responseFailure: none(),
      addHiringAnnouncementResponse: none(),
    );

    final addHiringSucessOrFailure =
        await _recruiterRepository.getAllPostedJobsByRecruiterID(recruiterID);

    addHiringSucessOrFailure.fold((failure) {
      state = state.copyWith(
        isLoadingGetPostedJobs: false,
        responseFailure: optionOf(failure),
      );
    }, (response) {
      state = state.copyWith(
        isLoadingGetPostedJobs: false,
        responseFailure: none(),
        getAllPostedJobsByRecruiterIDResponse: optionOf(response),
        getAllPostedJobsByRecruiterIDList: response.data,
      );
    });
  }

  // delete Hiring Announcement

  Future<void> deleteHiringAnnouncement({required String hiringID}) async {
    _logUtils.log(":::: delete Hiring Announcement::::");
    state = state.copyWith(
      isdeleteHiringAnnouncementLoading: true,
      isDeleteHiringAnnouncement: false,
      responseFailure: none(),
      addHiringAnnouncementResponse: none(),
    );

    final deleteHiringAnnouncementSucessOrFailure =
        await _recruiterRepository.deleteHiringAnnouncement(hiringID);

    deleteHiringAnnouncementSucessOrFailure.fold((failure) {
      state = state.copyWith(
        isdeleteHiringAnnouncementLoading: false,
        isDeleteHiringAnnouncement: false,
        responseFailure: optionOf(failure),
      );
    }, (response) {
      state = state.copyWith(
        isdeleteHiringAnnouncementLoading: false,
        isDeleteHiringAnnouncement: true,
        responseFailure: none(),
        deleteHiringAnnouncementResponse: optionOf(response),
      );
    });
  }

  // get All Applied User Profiles By Hiring ID --------------------------------

  Future<void> getAllAppliedUserProfilesByHiringID({
    required String hiringID,
  }) async {
    _logUtils.log(":::: get All Applied User Profiles By Hiring ID::::");
    state = state.copyWith(
      isLoadingGetAllAppliedUser: true,
      responseFailure: none(),
      getAllAppliedUserProfilesByHiringIDResponse: none(),
    );

    final addHiringSucessOrFailure = await _recruiterRepository
        .getAllAppliedUserProfilesByHiringID(hiringID);

    addHiringSucessOrFailure.fold((failure) {
      state = state.copyWith(
        isLoadingGetAllAppliedUser: false,
        responseFailure: optionOf(failure),
      );
    }, (response) {
      state = state.copyWith(
        isLoadingGetAllAppliedUser: false,
        responseFailure: none(),
        getAllAppliedUserProfilesByHiringIDResponse: optionOf(response),
        getAllAppliedUserProfilesByHiringIDList: response.data,
      );
    });
  }

  // send Response -------------------------------------------------------------

  Future<void> sendReponse({
    required String hiringID,
    required String userID,
    required String companyRespondStatus,
    required String message,
  }) async {
    _logUtils.log(":::: add Hiring Announcement ::::");
    state = state.copyWith(
      isLoadingReply: true,
      responseFailure: none(),
      sendReplyResponse: none(),
    );

    final responseToApplicationRequest = ResponseToApplication(
      hiringID: hiringID,
      userID: userID,
      companyRespondStatus: companyRespondStatus,
      message: message,
    );

    _logUtils.log(
        ":::: responseToApplicationRequest :::: $responseToApplicationRequest");

    final responseToApplicationRequestSucessOrFailure =
        await _recruiterRepository.sendReponse(responseToApplicationRequest);

    responseToApplicationRequestSucessOrFailure.fold((failure) {
      state = state.copyWith(
        isLoadingReply: false,
        responseFailure: optionOf(failure),
      );
    }, (response) {
      state = state.copyWith(
        isLoadingReply: false,
        responseFailure: none(),
        sendReplyResponse: optionOf(response),
      );
    });
  }
}
