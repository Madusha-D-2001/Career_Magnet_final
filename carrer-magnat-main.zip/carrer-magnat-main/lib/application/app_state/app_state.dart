import 'package:dartz/dartz.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'app_state.freezed.dart';

@freezed
class AppState with _$AppState {
  factory AppState({
    required String loginSignUpEmail,
    required String accessToken,
    required String refreshToken,
    required String userRole,
    required String userId,
    required String profileEmail,
    required String profileFullName,
    required String profileAddress,
    required String profileBirth,
    required String profileInfo,
    required String profileEducation,
    required String profileUniversity,
    required String profilePostion,
    required bool isProfileCreate,
    required bool isLoggedIn,
    required Option<bool> isAppStarted,
  }) = _AppState;

  factory AppState.initial() {
    return AppState(
      loginSignUpEmail: "",
      accessToken: "",
      refreshToken: "",
      userRole: "",
      userId: "",
      profileEmail: "",
      profileFullName: "",
      profileAddress: "",
      profileBirth: "",
      profileInfo: "",
      profileEducation: "",
      profileUniversity: "",
      profilePostion: "",
      isProfileCreate: false,
      isLoggedIn: false,
      isAppStarted: none(),
    );
  }
}
