import 'package:carrermagnet/application/app_state/app_state.dart';
import 'package:carrermagnet/domain/core/i_local_repository.dart';
import 'package:carrermagnet/utils/app_utils.dart';
import 'package:carrermagnet/utils/log_utils.dart';
import 'package:carrermagnet/utils/string_extensions.dart';
import 'package:dartz/dartz.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

class AppStateNotifier extends StateNotifier<AppState> {
  AppStateNotifier(this._localRepository)
      : super(
          AppState.initial(),
        ) {
    _logUtils.log("init");
  }

  static final LogUtils _logUtils = LogUtils(
    featureName: "AppStateNotifier",
    printLog: true,
  );

  final ILocalRepository _localRepository;

  Future<void> appStart() async {
    state = state.copyWith(
      isAppStarted: none(),
    );

    final isLoggedIn = (await _localRepository.read('is_logged_in'))
        .getOrElse(() => false.toString())
        .toBool();

    final appToken =
        (await _localRepository.read('accessToken')).getOrElse(() => "");

    final userId = (await _localRepository.read('userId')).getOrElse(() => "");

    print("appToken---------$appToken");
    print("isLoggedIn---------$isLoggedIn");

    // final profileEmail =
    //     (await _localRepository.read('profile_email')).getOrElse(() => "");

    final profileFullName =
        (await _localRepository.read('profile_full_name')).getOrElse(() => "");

    final loginSignUpEmail =
        (await _localRepository.read('login_sign_up_email'))
            .getOrElse(() => "");

    final profileAddress =
        (await _localRepository.read('profile_address')).getOrElse(() => "");

    final profileBirth =
        (await _localRepository.read('profile_birth')).getOrElse(() => "");
    final profileInfo =
        (await _localRepository.read('profile_info')).getOrElse(() => "");

    final profileEducation =
        (await _localRepository.read('profile_education')).getOrElse(() => "");

    final profileUniversity =
        (await _localRepository.read('profile_university')).getOrElse(() => "");

    final profilePostion =
        (await _localRepository.read('profile_postion')).getOrElse(() => "");

    final userRole =
        (await _localRepository.read('userRole')).getOrElse(() => "");

    final isProfileCreate = (await _localRepository.read('is_Profile_Create'))
        .getOrElse(() => false.toString())
        .toBool();

    final profileEmail =
        (await _localRepository.read('profile_email')).getOrElse(() => "");

    AppUtils.tempToken = appToken;

    state = state.copyWith(
      userRole: userRole,
      loginSignUpEmail: loginSignUpEmail,
      isLoggedIn: isLoggedIn,
      isAppStarted: some(true),
      accessToken: appToken,
      userId: userId.isNotEmpty ? userId : '0',
      profileEmail: profileEmail,
      profileFullName: profileFullName,
      profileAddress: profileAddress,
      profileBirth: profileBirth,
      profileInfo: profileInfo,
      profileEducation: profileEducation,
      profileUniversity: profileUniversity,
      profilePostion: profilePostion,
      isProfileCreate: isProfileCreate,
    );

    // Future.delayed(const Duration(seconds: 3), () {
    //   state = state.copyWith(
    //     loginSignUpEmail: loginSignUpEmail,
    //     isLoggedIn: isLoggedIn,
    //     isAppStarted: some(true),
    //     accessToken: appToken,
    //     userId: userId.isNotEmpty ? userId : '0',
    //     profileEmail: profileEmail,
    //     profileFullName: profileFullName,
    //     profileAddress: profileAddress,
    //     profileBirth: profileBirth,
    //     profileInfo: profileInfo,
    //     profileEducation: profileEducation,
    //     profileUniversity: profileUniversity,
    //     profilePostion: profilePostion,
    //     isProfileCreate: isProfileCreate,
    //   );
    // });

    _logUtils.log("appStart : after state : $state");
  }

  void setUserId(String userId) {
    _localRepository.createOrUpdate('userId', userId);
    state = state.copyWith(
      userId: userId,
    );
  }

  // get Profile Email ---

  Future<String> getProfileEmail() async {
    final profileEmail =
        (await _localRepository.read('profile_email')).getOrElse(() => "");

    state = state.copyWith(
      profileEmail: profileEmail,
    );
    return profileEmail;
  }

  Future<void> setEmail(String email) async {
    state = state.copyWith(
      profileEmail: email,
    );
  }

  Future<void> setAcessToken(String accessToken) async {
    _localRepository.createOrUpdate('accessToken', accessToken);
    state = state.copyWith(
      accessToken: accessToken,
    );
  }

  Future<void> setRefreshToken(String refreshToken) async {
    _localRepository.createOrUpdate('refreshToken', refreshToken);
    state = state.copyWith(
      refreshToken: refreshToken,
    );
  }

  Future<void> setUserRole(String userRole) async {
    _localRepository.createOrUpdate('userRole', userRole);
    state = state.copyWith(
      userRole: userRole,
    );
  }

  Future<void> login(String loginType) async {
    _localRepository.createOrUpdate('login_method', loginType);
    _localRepository.createOrUpdate('is_logged_in', true.toString());
  }

  Future<void> logout() async {
    _localRepository.createOrUpdate('is_logged_in', false.toString());
    _localRepository.deleteAll();
  }

  // Get User Profile Details --------------------------------------------------

  Future<void> getUserDetails() async {
    final loginSignUpEmail =
        (await _localRepository.read('login_sign_up_email'))
            .getOrElse(() => "");

    final profileEmail =
        (await _localRepository.read('profile_email')).getOrElse(() => "");

    final profileFullName =
        (await _localRepository.read('profile_full_name')).getOrElse(() => "");

    final profileAddress =
        (await _localRepository.read('profile_address')).getOrElse(() => "");

    final profileBirth =
        (await _localRepository.read('profile_birth')).getOrElse(() => "");
    final profileInfo =
        (await _localRepository.read('profile_info')).getOrElse(() => "");

    final profileEducation =
        (await _localRepository.read('profile_education')).getOrElse(() => "");

    final profileUniversity =
        (await _localRepository.read('profile_university')).getOrElse(() => "");

    final profilePostion =
        (await _localRepository.read('profile_postion')).getOrElse(() => "");

    final isProfileCreate = (await _localRepository.read('is_Profile_Create'))
        .getOrElse(() => false.toString())
        .toBool();

    _logUtils.log("login Sign Up Email ::::  :::: : $loginSignUpEmail");
    _logUtils.log("profile Email ::::  :::: : $profileEmail");
    _logUtils.log("profile Full Name ::::  :::: : $profileFullName");
    _logUtils.log("profile Address ::::  :::: : $profileAddress");
    _logUtils.log("profile Birth ::::  :::: : $profileBirth");
    _logUtils.log("profile Info ::::  :::: : $profileInfo");
    _logUtils.log("profile Education ::::  :::: : $profileEducation");
    _logUtils.log("profile University ::::  :::: : $profileUniversity");
    _logUtils.log("profile Postion ::::  :::: : $profilePostion");
    _logUtils.log("is Profile Create ::::  :::: : $isProfileCreate");

    state = state.copyWith(
      loginSignUpEmail: loginSignUpEmail,
      profileEmail: profileEmail,
      profileFullName: profileFullName,
      profileAddress: profileAddress,
      profileBirth: profileBirth,
      profileInfo: profileInfo,
      profileEducation: profileEducation,
      profileUniversity: profileUniversity,
      profilePostion: profilePostion,
      isProfileCreate: isProfileCreate,
    );
  }
}
