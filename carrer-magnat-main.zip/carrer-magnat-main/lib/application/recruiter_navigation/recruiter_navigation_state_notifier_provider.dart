import 'package:hooks_riverpod/hooks_riverpod.dart';

import 'recruiter_navigation_state.dart';
import 'recruiter_navigation_state_notifier.dart';

final recruiterNavigationStateNotifierProvider = StateNotifierProvider<
    RecruiterNavigationStateNotifier, RecruiterNavigationState>((ref) {
  return RecruiterNavigationStateNotifier();
});
