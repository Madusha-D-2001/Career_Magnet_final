// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'recruiter_navigation_state.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$RecruiterNavigationState {
  int get index => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $RecruiterNavigationStateCopyWith<RecruiterNavigationState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $RecruiterNavigationStateCopyWith<$Res> {
  factory $RecruiterNavigationStateCopyWith(RecruiterNavigationState value,
          $Res Function(RecruiterNavigationState) then) =
      _$RecruiterNavigationStateCopyWithImpl<$Res, RecruiterNavigationState>;
  @useResult
  $Res call({int index});
}

/// @nodoc
class _$RecruiterNavigationStateCopyWithImpl<$Res,
        $Val extends RecruiterNavigationState>
    implements $RecruiterNavigationStateCopyWith<$Res> {
  _$RecruiterNavigationStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? index = null,
  }) {
    return _then(_value.copyWith(
      index: null == index
          ? _value.index
          : index // ignore: cast_nullable_to_non_nullable
              as int,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$RecruiterNavigationStateImplCopyWith<$Res>
    implements $RecruiterNavigationStateCopyWith<$Res> {
  factory _$$RecruiterNavigationStateImplCopyWith(
          _$RecruiterNavigationStateImpl value,
          $Res Function(_$RecruiterNavigationStateImpl) then) =
      __$$RecruiterNavigationStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({int index});
}

/// @nodoc
class __$$RecruiterNavigationStateImplCopyWithImpl<$Res>
    extends _$RecruiterNavigationStateCopyWithImpl<$Res,
        _$RecruiterNavigationStateImpl>
    implements _$$RecruiterNavigationStateImplCopyWith<$Res> {
  __$$RecruiterNavigationStateImplCopyWithImpl(
      _$RecruiterNavigationStateImpl _value,
      $Res Function(_$RecruiterNavigationStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? index = null,
  }) {
    return _then(_$RecruiterNavigationStateImpl(
      index: null == index
          ? _value.index
          : index // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$RecruiterNavigationStateImpl implements _RecruiterNavigationState {
  _$RecruiterNavigationStateImpl({required this.index});

  @override
  final int index;

  @override
  String toString() {
    return 'RecruiterNavigationState(index: $index)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RecruiterNavigationStateImpl &&
            (identical(other.index, index) || other.index == index));
  }

  @override
  int get hashCode => Object.hash(runtimeType, index);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$RecruiterNavigationStateImplCopyWith<_$RecruiterNavigationStateImpl>
      get copyWith => __$$RecruiterNavigationStateImplCopyWithImpl<
          _$RecruiterNavigationStateImpl>(this, _$identity);
}

abstract class _RecruiterNavigationState implements RecruiterNavigationState {
  factory _RecruiterNavigationState({required final int index}) =
      _$RecruiterNavigationStateImpl;

  @override
  int get index;
  @override
  @JsonKey(ignore: true)
  _$$RecruiterNavigationStateImplCopyWith<_$RecruiterNavigationStateImpl>
      get copyWith => throw _privateConstructorUsedError;
}
