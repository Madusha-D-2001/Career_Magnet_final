import 'package:carrermagnet/utils/log_utils.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import 'recruiter_navigation_state.dart';

class RecruiterNavigationStateNotifier
    extends StateNotifier<RecruiterNavigationState> {
  RecruiterNavigationStateNotifier()
      : super(RecruiterNavigationState.initial()) {
    _logUtils.log("init");
  }

  static final LogUtils _logUtils = LogUtils(
    featureName: "RecruiterNavigationStateNotifier",
    printLog: true,
  );

  void indexChange(int index) {
    state = state.copyWith(
      index: index,
    );
  }
}
