import 'package:freezed_annotation/freezed_annotation.dart';

part 'recruiter_navigation_state.freezed.dart';

@freezed
class RecruiterNavigationState with _$RecruiterNavigationState {
  factory RecruiterNavigationState({
    required int index,
  }) = _RecruiterNavigationState;

  factory RecruiterNavigationState.initial() {
    return RecruiterNavigationState(
      index: 0,
    );
  }
}
