import 'package:carrermagnet/application/sign_up/signup_state.dart';
import 'package:carrermagnet/domain/core/i_local_repository.dart';
import 'package:carrermagnet/domain/sign_up/i_sign_up_repository.dart';
import 'package:carrermagnet/domain/sign_up/reqruiter_sign_up_resquest.dart';
import 'package:carrermagnet/domain/sign_up/sign_up_resquest.dart';
import 'package:carrermagnet/utils/log_utils.dart';
import 'package:dartz/dartz.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

class SignUpNotifier extends StateNotifier<SignUpState> {
  SignUpNotifier(this._signUpRepository, this._localRepository)
      : super(SignUpState.initial()) {
    _logUtils.log("init");
  }

  final ISignUpRepository _signUpRepository;
  final ILocalRepository _localRepository;

  static final LogUtils _logUtils = LogUtils(
    featureName: "Sign Up Notifier",
    printLog: true,
  );

  setValues({
    required String first_name,
    required String last_name,
    required String email,
    required String contact,
    required String password,
  }) {
    state = state.copyWith(
      email: email,
      password: password,
    );
  }

  // user signUp --------------------------------------------------------------------

  Future<void> signUp() async {
    _logUtils.log("signUp");
    state = state.copyWith(
      isLoading: true,
      responseFailure: none(),
      signUpResponse: none(),
    );

    final signUpRequest = SignUpRequest(
      first_name: state.first_name,
      last_name: state.last_name,
      email: state.email,
      contact: state.contact,
      password: state.password,
    );

    final signUpSucessOrFailure = await _signUpRepository.signUp(signUpRequest);

    signUpSucessOrFailure.fold((failure) {
      state = state.copyWith(
        isLoading: false,
        responseFailure: optionOf(failure),
      );
    }, (response) {
      _localRepository.createOrUpdate('profile_email', state.email);
      // _localRepository.createOrUpdate('is_logged_in', true.toString());
      // _localRepository.createOrUpdate('login_sign_up_email', email);
      // _localRepository.createOrUpdate('profile_email', email);
      state = state.copyWith(
        isLoading: false,
        responseFailure: none(),
        userSignUpResponse: optionOf(response),
      );
    });
  }

  // recruiter SignUp ----------------------

  Future<void> recruiterSignUp({
    required String first_name,
    required String last_name,
    required String email,
    required String contact,
    required String password,
    required String company,
  }) async {
    _logUtils.log("signUp");
    state = state.copyWith(
      isLoading: true,
      responseFailure: none(),
      signUpResponse: none(),
    );

    final signUpRequest = ReqruiterSignUpResquest(
      first_name: first_name,
      last_name: last_name,
      email: email,
      contact: contact,
      password: password,
      company: company,
    );

    final recruiterSignUpSucessOrFailure =
        await _signUpRepository.recruiterSignUp(signUpRequest);

    recruiterSignUpSucessOrFailure.fold((failure) {
      state = state.copyWith(
        isLoading: false,
        responseFailure: optionOf(failure),
      );
    }, (response) {
      _localRepository.createOrUpdate('profile_email', email);
      // _localRepository.createOrUpdate('is_logged_in', true.toString());
      // _localRepository.createOrUpdate('login_sign_up_email', email);
      // _localRepository.createOrUpdate('profile_email', email);
      state = state.copyWith(
        isLoading: false,
        responseFailure: none(),
        signUpResponse: optionOf(response),
      );
    });
  }
}
