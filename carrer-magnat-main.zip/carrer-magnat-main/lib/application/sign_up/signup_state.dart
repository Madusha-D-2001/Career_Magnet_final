import 'package:carrermagnet/domain/sign_up/sign_up_response.dart';
import 'package:carrermagnet/domain/sign_up/user_sign_up_response.dart';
import 'package:dartz/dartz.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../../domain/core/failure.dart';

part 'signup_state.freezed.dart';

@freezed
class SignUpState with _$SignUpState {
  factory SignUpState({
    required String first_name,
    required String last_name,
    required String email,
    required String contact,
    required String name,
    required String address,
    required String password,
    required String address_latitude,
    required String address_longitude,
    required bool isLoading,
    required Option<Failure> responseFailure,
    required Option<SignUpResponse> signUpResponse,
    required Option<UserSignUpResponse> userSignUpResponse,
  }) = _SignUpState;

  factory SignUpState.initial() {
    return SignUpState(
      email: '',
      name: '',
      address: '',
      contact: '',
      address_latitude: '',
      address_longitude: '',
      first_name: '',
      last_name: '',
      password: '',
      isLoading: false,
      responseFailure: none(),
      signUpResponse: none(),
      userSignUpResponse: none(),
    );
  }
}
