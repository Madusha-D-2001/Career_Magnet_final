// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'signup_state.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$SignUpState {
  String get first_name => throw _privateConstructorUsedError;
  String get last_name => throw _privateConstructorUsedError;
  String get email => throw _privateConstructorUsedError;
  String get contact => throw _privateConstructorUsedError;
  String get name => throw _privateConstructorUsedError;
  String get address => throw _privateConstructorUsedError;
  String get password => throw _privateConstructorUsedError;
  String get address_latitude => throw _privateConstructorUsedError;
  String get address_longitude => throw _privateConstructorUsedError;
  bool get isLoading => throw _privateConstructorUsedError;
  Option<Failure> get responseFailure => throw _privateConstructorUsedError;
  Option<SignUpResponse> get signUpResponse =>
      throw _privateConstructorUsedError;
  Option<UserSignUpResponse> get userSignUpResponse =>
      throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $SignUpStateCopyWith<SignUpState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SignUpStateCopyWith<$Res> {
  factory $SignUpStateCopyWith(
          SignUpState value, $Res Function(SignUpState) then) =
      _$SignUpStateCopyWithImpl<$Res, SignUpState>;
  @useResult
  $Res call(
      {String first_name,
      String last_name,
      String email,
      String contact,
      String name,
      String address,
      String password,
      String address_latitude,
      String address_longitude,
      bool isLoading,
      Option<Failure> responseFailure,
      Option<SignUpResponse> signUpResponse,
      Option<UserSignUpResponse> userSignUpResponse});
}

/// @nodoc
class _$SignUpStateCopyWithImpl<$Res, $Val extends SignUpState>
    implements $SignUpStateCopyWith<$Res> {
  _$SignUpStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? first_name = null,
    Object? last_name = null,
    Object? email = null,
    Object? contact = null,
    Object? name = null,
    Object? address = null,
    Object? password = null,
    Object? address_latitude = null,
    Object? address_longitude = null,
    Object? isLoading = null,
    Object? responseFailure = null,
    Object? signUpResponse = null,
    Object? userSignUpResponse = null,
  }) {
    return _then(_value.copyWith(
      first_name: null == first_name
          ? _value.first_name
          : first_name // ignore: cast_nullable_to_non_nullable
              as String,
      last_name: null == last_name
          ? _value.last_name
          : last_name // ignore: cast_nullable_to_non_nullable
              as String,
      email: null == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String,
      contact: null == contact
          ? _value.contact
          : contact // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      address: null == address
          ? _value.address
          : address // ignore: cast_nullable_to_non_nullable
              as String,
      password: null == password
          ? _value.password
          : password // ignore: cast_nullable_to_non_nullable
              as String,
      address_latitude: null == address_latitude
          ? _value.address_latitude
          : address_latitude // ignore: cast_nullable_to_non_nullable
              as String,
      address_longitude: null == address_longitude
          ? _value.address_longitude
          : address_longitude // ignore: cast_nullable_to_non_nullable
              as String,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      responseFailure: null == responseFailure
          ? _value.responseFailure
          : responseFailure // ignore: cast_nullable_to_non_nullable
              as Option<Failure>,
      signUpResponse: null == signUpResponse
          ? _value.signUpResponse
          : signUpResponse // ignore: cast_nullable_to_non_nullable
              as Option<SignUpResponse>,
      userSignUpResponse: null == userSignUpResponse
          ? _value.userSignUpResponse
          : userSignUpResponse // ignore: cast_nullable_to_non_nullable
              as Option<UserSignUpResponse>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$SignUpStateImplCopyWith<$Res>
    implements $SignUpStateCopyWith<$Res> {
  factory _$$SignUpStateImplCopyWith(
          _$SignUpStateImpl value, $Res Function(_$SignUpStateImpl) then) =
      __$$SignUpStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String first_name,
      String last_name,
      String email,
      String contact,
      String name,
      String address,
      String password,
      String address_latitude,
      String address_longitude,
      bool isLoading,
      Option<Failure> responseFailure,
      Option<SignUpResponse> signUpResponse,
      Option<UserSignUpResponse> userSignUpResponse});
}

/// @nodoc
class __$$SignUpStateImplCopyWithImpl<$Res>
    extends _$SignUpStateCopyWithImpl<$Res, _$SignUpStateImpl>
    implements _$$SignUpStateImplCopyWith<$Res> {
  __$$SignUpStateImplCopyWithImpl(
      _$SignUpStateImpl _value, $Res Function(_$SignUpStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? first_name = null,
    Object? last_name = null,
    Object? email = null,
    Object? contact = null,
    Object? name = null,
    Object? address = null,
    Object? password = null,
    Object? address_latitude = null,
    Object? address_longitude = null,
    Object? isLoading = null,
    Object? responseFailure = null,
    Object? signUpResponse = null,
    Object? userSignUpResponse = null,
  }) {
    return _then(_$SignUpStateImpl(
      first_name: null == first_name
          ? _value.first_name
          : first_name // ignore: cast_nullable_to_non_nullable
              as String,
      last_name: null == last_name
          ? _value.last_name
          : last_name // ignore: cast_nullable_to_non_nullable
              as String,
      email: null == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String,
      contact: null == contact
          ? _value.contact
          : contact // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      address: null == address
          ? _value.address
          : address // ignore: cast_nullable_to_non_nullable
              as String,
      password: null == password
          ? _value.password
          : password // ignore: cast_nullable_to_non_nullable
              as String,
      address_latitude: null == address_latitude
          ? _value.address_latitude
          : address_latitude // ignore: cast_nullable_to_non_nullable
              as String,
      address_longitude: null == address_longitude
          ? _value.address_longitude
          : address_longitude // ignore: cast_nullable_to_non_nullable
              as String,
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      responseFailure: null == responseFailure
          ? _value.responseFailure
          : responseFailure // ignore: cast_nullable_to_non_nullable
              as Option<Failure>,
      signUpResponse: null == signUpResponse
          ? _value.signUpResponse
          : signUpResponse // ignore: cast_nullable_to_non_nullable
              as Option<SignUpResponse>,
      userSignUpResponse: null == userSignUpResponse
          ? _value.userSignUpResponse
          : userSignUpResponse // ignore: cast_nullable_to_non_nullable
              as Option<UserSignUpResponse>,
    ));
  }
}

/// @nodoc

class _$SignUpStateImpl implements _SignUpState {
  _$SignUpStateImpl(
      {required this.first_name,
      required this.last_name,
      required this.email,
      required this.contact,
      required this.name,
      required this.address,
      required this.password,
      required this.address_latitude,
      required this.address_longitude,
      required this.isLoading,
      required this.responseFailure,
      required this.signUpResponse,
      required this.userSignUpResponse});

  @override
  final String first_name;
  @override
  final String last_name;
  @override
  final String email;
  @override
  final String contact;
  @override
  final String name;
  @override
  final String address;
  @override
  final String password;
  @override
  final String address_latitude;
  @override
  final String address_longitude;
  @override
  final bool isLoading;
  @override
  final Option<Failure> responseFailure;
  @override
  final Option<SignUpResponse> signUpResponse;
  @override
  final Option<UserSignUpResponse> userSignUpResponse;

  @override
  String toString() {
    return 'SignUpState(first_name: $first_name, last_name: $last_name, email: $email, contact: $contact, name: $name, address: $address, password: $password, address_latitude: $address_latitude, address_longitude: $address_longitude, isLoading: $isLoading, responseFailure: $responseFailure, signUpResponse: $signUpResponse, userSignUpResponse: $userSignUpResponse)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SignUpStateImpl &&
            (identical(other.first_name, first_name) ||
                other.first_name == first_name) &&
            (identical(other.last_name, last_name) ||
                other.last_name == last_name) &&
            (identical(other.email, email) || other.email == email) &&
            (identical(other.contact, contact) || other.contact == contact) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.address, address) || other.address == address) &&
            (identical(other.password, password) ||
                other.password == password) &&
            (identical(other.address_latitude, address_latitude) ||
                other.address_latitude == address_latitude) &&
            (identical(other.address_longitude, address_longitude) ||
                other.address_longitude == address_longitude) &&
            (identical(other.isLoading, isLoading) ||
                other.isLoading == isLoading) &&
            (identical(other.responseFailure, responseFailure) ||
                other.responseFailure == responseFailure) &&
            (identical(other.signUpResponse, signUpResponse) ||
                other.signUpResponse == signUpResponse) &&
            (identical(other.userSignUpResponse, userSignUpResponse) ||
                other.userSignUpResponse == userSignUpResponse));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      first_name,
      last_name,
      email,
      contact,
      name,
      address,
      password,
      address_latitude,
      address_longitude,
      isLoading,
      responseFailure,
      signUpResponse,
      userSignUpResponse);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SignUpStateImplCopyWith<_$SignUpStateImpl> get copyWith =>
      __$$SignUpStateImplCopyWithImpl<_$SignUpStateImpl>(this, _$identity);
}

abstract class _SignUpState implements SignUpState {
  factory _SignUpState(
          {required final String first_name,
          required final String last_name,
          required final String email,
          required final String contact,
          required final String name,
          required final String address,
          required final String password,
          required final String address_latitude,
          required final String address_longitude,
          required final bool isLoading,
          required final Option<Failure> responseFailure,
          required final Option<SignUpResponse> signUpResponse,
          required final Option<UserSignUpResponse> userSignUpResponse}) =
      _$SignUpStateImpl;

  @override
  String get first_name;
  @override
  String get last_name;
  @override
  String get email;
  @override
  String get contact;
  @override
  String get name;
  @override
  String get address;
  @override
  String get password;
  @override
  String get address_latitude;
  @override
  String get address_longitude;
  @override
  bool get isLoading;
  @override
  Option<Failure> get responseFailure;
  @override
  Option<SignUpResponse> get signUpResponse;
  @override
  Option<UserSignUpResponse> get userSignUpResponse;
  @override
  @JsonKey(ignore: true)
  _$$SignUpStateImplCopyWith<_$SignUpStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
