import 'package:carrermagnet/application/sign_up/signup_state.dart';
import 'package:carrermagnet/application/sign_up/signup_state_notifier.dart';
import 'package:carrermagnet/infrastructure/core/providers.dart';
import 'package:carrermagnet/infrastructure/sign_up/providers.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

final signUpStateNotifierProvider =
    StateNotifierProvider<SignUpNotifier, SignUpState>((ref) {
  final signUpRepository = ref.read(signUpRepositoryProvider);
  final localRepository = ref.read(localRepositoryProvider);
  return SignUpNotifier(signUpRepository, localRepository);
});
