import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../utils/constants/colors.dart';

class SearchJobView extends HookConsumerWidget {
  const SearchJobView({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            backgroundColor: JColors.splashBackgroundColor,
            expandedHeight: 150.h,
            flexibleSpace: FlexibleSpaceBar(
              background: Stack(
                children: [
                  Positioned(
                    top: -150,
                    right: -250,
                    child: Container(
                      width: 400.w,
                      height: 400.h,
                      padding: const EdgeInsets.all(0),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(400),
                          color: Colors.white.withOpacity(0.1)),
                      // child: child,
                    ),
                  ),
                  Positioned(
                    top: 100,
                    right: -250,
                    child: Container(
                      width: 400.w,
                      height: 400.h,
                      padding: const EdgeInsets.all(0),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(400),
                        color: Colors.white.withOpacity(0.1),
                        // child: child,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // header part -------------------------------------------------
        ],
      ),
    );
  }
}
