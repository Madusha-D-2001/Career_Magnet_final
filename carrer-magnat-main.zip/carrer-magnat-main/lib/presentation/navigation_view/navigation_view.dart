import 'package:carrermagnet/application/navigation/navigation_state_notifier_provider.dart';
import 'package:carrermagnet/presentation/bookmark_view/bookmark/screens/bookmark_Screen.dart';
import 'package:carrermagnet/presentation/course_view/course_view.dart';
import 'package:carrermagnet/presentation/explore_view/screen/explore_screen.dart';
import 'package:carrermagnet/presentation/home_view/home_view.dart';
import 'package:carrermagnet/presentation/profile_view/profile_view.dart';
import 'package:carrermagnet/utils/constants/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:iconsax/iconsax.dart';

class NavigationView extends HookConsumerWidget {
  NavigationView({super.key});

  int selectedItem = 0;

  final List<Widget> screens = <Widget>[
    HomeView(),
    // Container(color: Colors.purple),
    // ExploreScreen(),
    BookMarkScreen(),
    CourseView(),
    ProfileView(),
  ];

  void onItemTap(int index) {
    selectedItem = index;
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    useEffect(() {
      // Using Future.microtask to ensure these operations happen after the build
      Future.microtask(() {});

      return null;
    }, []);

    var navIndex = ref.watch(navigationStateNotifierProvider);

    return Scaffold(
      backgroundColor: Colors.white,
      bottomNavigationBar: Container(
        margin: EdgeInsets.symmetric(horizontal: 10),
        alignment: Alignment.center,

        height: 65,
        //  margin: EdgeInsets.all(10),
        decoration: const BoxDecoration(
          color: JColors.splashBackgroundColor,
          borderRadius: BorderRadius.all(
            Radius.circular(30),
          ),
        ),
        child: BottomNavigationBar(
          enableFeedback: false,
          onTap: (value) {
            ref
                .watch(navigationStateNotifierProvider.notifier)
                .indexChange(value);
          },
          backgroundColor: Colors.transparent,
          elevation: 0,
          currentIndex: navIndex.index,
          type: BottomNavigationBarType.fixed,
          items: const [
            BottomNavigationBarItem(
              icon: Icon(
                Iconsax.home,
                color: Colors.white,
              ),
              label: '',
            ),
            BottomNavigationBarItem(
              icon: Icon(
                Icons.bookmark,
                size: 30,
                color: Colors.white,
              ),
              label: '',
            ),
            BottomNavigationBarItem(
              icon: Icon(
                Iconsax.book,
                color: Colors.white,
              ),
              label: '',
            ),
            BottomNavigationBarItem(
              icon: Icon(
                Iconsax.user,
                color: Colors.white,
              ),
              label: '',
            ),
          ],
        ),
      ),
      body: Center(child: screens[navIndex.index]),
    );
  }
}
