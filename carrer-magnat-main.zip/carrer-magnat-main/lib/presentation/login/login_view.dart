import 'package:carrermagnet/application/app_state/app_state_notifier_provider.dart';
import 'package:carrermagnet/application/login/login_state_notifier_provider.dart';
import 'package:carrermagnet/domain/core/failure.dart';
import 'package:carrermagnet/domain/login/login_response.dart';
import 'package:carrermagnet/presentation/alert/alert_utils.dart';
import 'package:carrermagnet/presentation/components/footer_button.dart';
import 'package:carrermagnet/presentation/core/widgets/common_loading_indicator.dart';
import 'package:carrermagnet/routes/routes_name.dart';
import 'package:carrermagnet/utils/app_utils.dart';
import 'package:carrermagnet/utils/constants/colors.dart';
import 'package:carrermagnet/utils/validators/validators.dart';
import 'package:dartz/dartz.dart';
import 'package:flutter/material.dart';
import 'package:flutter_overlay_loader/flutter_overlay_loader.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

class LoginView extends HookConsumerWidget {
  LoginView({super.key});

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    var h = MediaQuery.of(context).size.height;
    var w = MediaQuery.of(context).size.width;

    ref.listen<bool>(
      loginStateNotifierProvider.select((value) => value.isLoading),
      (_, value) {
        if (value) {
          Loader.show(context,
              progressIndicator: const CommonLoadingIndicator());
        } else {
          Loader.hide();
        }
      },
    );

    ref.listen<Option<Failure>>(
        loginStateNotifierProvider.select((value) => value.responseFailure),
        (_, value) {
      value.fold(() {}, (failure) {
        AlertUtils.showErrorDialog(
          context: context,
          message: failure.toString(),
        );
      });
    });

    // ref.listen<Option<LoginResponse>>(
    //     loginStateNotifierProvider.select((value) => value.loginResponse),
    //     (_, value) {
    //   value.fold(() {}, (response) {
    //     Get.offAll(() => NavigationView());
    //   });
    // });

    ref.listen<Option<LoginResponse>>(
      loginStateNotifierProvider.select((value) => value.loginResponse),
      (_, value) {
        value.fold(() {}, (response) {
          ref
              .read(appStateNotifierProvider.notifier)
              .setUserId(response.data.user_id);

          ref
              .read(appStateNotifierProvider.notifier)
              .setAcessToken(response.data.access_token);

          ref
              .read(appStateNotifierProvider.notifier)
              .setRefreshToken(response.data.refresh_token);

          ref
              .read(appStateNotifierProvider.notifier)
              .setUserRole(response.data.role);

          AppUtils.tempToken = response.data.access_token;

          if (response.data.role == 'RECRUITER') {
            ref
                .read(appStateNotifierProvider.notifier)
                .setEmail(emailController.text);
            Navigator.pushNamedAndRemoveUntil(
              context,
              RoutesName
                  .recruiterNavigationView, // The name of the route you want to navigate to
              (Route<dynamic> route) => false, // Remove all previous routes
            );
          } else {
            ref
                .read(appStateNotifierProvider.notifier)
                .setEmail(emailController.text);
            Navigator.pushNamedAndRemoveUntil(
              context,
              RoutesName
                  .navigationView, // The name of the route you want to navigate to
              (Route<dynamic> route) => false, // Remove all previous routes
            );
          }
        });
      },
    );

    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                // header part ---------------------------
                Container(
                  width: w,
                  color: Colors.white,
                  child: SizedBox(
                    height: h * 0.35,
                    child: Stack(
                      children: [
                        Positioned(
                          top: -30,
                          right: -60,
                          child: Container(
                            width: 150,
                            height: 150,
                            padding: const EdgeInsets.all(0),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(100),
                                color: Colors.pink.withOpacity(0.1)),
                            // child: child,
                          ),
                        ),
                        Positioned(
                          top: 130,
                          right: 310,
                          child: Container(
                            width: 150,
                            height: 150,
                            padding: const EdgeInsets.all(0),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(100),
                                color: Colors.pink.withOpacity(0.1)),
                            // child: child,
                          ),
                        ),
                        Positioned(
                          top: 170,
                          left: w / 5,
                          child: Container(
                            child: Image.asset(
                              "assets/images/careermagnet_blue_logo.png",
                              scale: 3,
                            ),
                            // child: child,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                const Text(
                  'Login to your account',
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.black),
                ),

                const SizedBox(
                  height: 20,
                ),

                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 30),
                  child: Column(
                    children: [
                      // email text field ----------

                      TextFormField(
                        controller: emailController,
                        keyboardType: TextInputType.emailAddress,
                        validator: (value) => Vvalidator.VvalideEmail(value),
                        decoration: InputDecoration(
                            hintText: 'Email',
                            filled: true,
                            fillColor: Colors.white,
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10)),
                            prefixIcon: const Icon(
                              Icons.email,
                              color: Colors.grey,
                            )),
                      ),

                      const SizedBox(
                        height: 10,
                      ),

                      TextFormField(
                        controller: passwordController,
                        validator: (value) =>
                            Vvalidator.validatePassword(value),
                        decoration: InputDecoration(
                            hintText: 'Password',
                            filled: true,
                            fillColor: Colors.white,
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10)),
                            prefixIcon: const Icon(
                              Icons.lock,
                              color: Colors.grey,
                            )),
                      ),

                      const SizedBox(
                        height: 30,
                      ),

                      InkWell(
                        onTap: () async {
                          FocusScope.of(context).unfocus();

                          if (_formKey.currentState!.validate()) {
                            ref
                                .watch(loginStateNotifierProvider.notifier)
                                .setValues(
                                  email: emailController.text,
                                  password: passwordController.text,
                                );

                            ref
                                .watch(loginStateNotifierProvider.notifier)
                                .login();
                          }
                        },
                        child: Container(
                          height: 44,
                          width: 200,
                          decoration: const BoxDecoration(
                              color: JColors.splashBackgroundColor,
                              borderRadius:
                                  BorderRadius.all(Radius.circular(20))),
                          child: const Center(
                              child: Text(
                            'Sign in',
                            style: TextStyle(color: Colors.white, fontSize: 16),
                          )),
                        ),
                      ),

                      const SizedBox(
                        height: 30,
                      ),

                      CommonFooterButton(
                        onPress: () {
                          Navigator.pushNamedAndRemoveUntil(
                            context,
                            RoutesName.signUpView,
                            (Route<dynamic> route) => false,
                          );
                        },
                        title: 'Create Account',
                      ),

                      const SizedBox(
                        height: 20,
                      ),

                      CommonFooterButton(
                        onPress: () {
                          Navigator.pushNamedAndRemoveUntil(
                            context,
                            RoutesName.recruiterSignUp,
                            (Route<dynamic> route) => false,
                          );
                        },
                        title: 'Create Recruiter Account ',
                      ),
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
