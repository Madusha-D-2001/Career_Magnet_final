import 'package:carrermagnet/utils/constants/colors.dart';
import 'package:flutter/material.dart';

class ExploreScreen extends StatelessWidget {
  const ExploreScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: const Icon(
          Icons.arrow_back,
          color: Colors.white,
        ),
        title: const Text(
          'Explore',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: JColors.splashBackgroundColor,
      ),
      body: const Center(
        child: Text(
          'Not Yet',
          style: TextStyle(
            color: Colors.black,
            fontSize: 14,
          ),
        ),
      ),
    );
  }
}
