import 'package:carrermagnet/domain/get_all_job/get_all_job_data.dart';
import 'package:carrermagnet/domain/search_jobs/search_jobs_response_data.dart';
import 'package:carrermagnet/routes/routes_name.dart';
import 'package:dartz/dartz.dart';
import 'package:flutter/material.dart';
import 'package:flutter_overlay_loader/flutter_overlay_loader.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../application/app_state/app_state_notifier_provider.dart';
import '../../application/profile_creation/profile_creation_state_notifier_provider.dart';
import '../../domain/add_hiring_announcement/add_hiring_announcement_response.dart';
import '../../domain/core/failure.dart';
import '../../utils/constants/colors.dart';
import '../alert/alert_utils.dart';
import '../core/widgets/common_loading_indicator.dart';

class JobDetailView extends HookConsumerWidget {
  JobDetailView({
    super.key,
    required this.searchJobsResponseData,
  });

  GetAllJobData searchJobsResponseData;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profileEmail1 = ref.watch(appStateNotifierProvider.select(
      (value) => value.profileEmail,
    ));

    ref.listen<bool>(
      profileCreationStateNotifierProvider
          .select((value) => value.isAddVacancy),
      (_, value) {
        if (value) {
          Loader.show(context,
              progressIndicator: const CommonLoadingIndicator());
        } else {
          Loader.hide();
        }
      },
    );

    ref.listen<Option<AddHiringAnnouncementResponse>>(
      profileCreationStateNotifierProvider
          .select((value) => value.applyToVacancyResponse),
      (_, value) {
        value.fold(() {}, (response) {
          AlertUtils.showSuccessDialog(
            context: context,
            message: 'Job Apply Sucess',
            onActionPressed: (context) {
              Navigator.pushNamedAndRemoveUntil(
                context,
                RoutesName.navigationView,
                (Route<dynamic> route) => false,
              );
            },
          );
        });
      },
    );

    ref.listen<Option<Failure>>(
        profileCreationStateNotifierProvider
            .select((value) => value.responseFailure), (_, value) {
      value.fold(() {}, (failure) {
        AlertUtils.showErrorDialog(
          context: context,
          message: failure.toString(),
        );
      });
    });

    final userId = ref.watch(appStateNotifierProvider.select(
      (value) => value.userId,
    ));

    return Scaffold(
      appBar: AppBar(
        leading: InkWell(
          onTap: () {
            Navigator.pushNamedAndRemoveUntil(
              context,
              RoutesName
                  .navigationView, // The name of the route you want to navigate to
              (Route<dynamic> route) => false, // Remove all previous routes
            );
          },
          child: const Icon(
            Icons.arrow_back,
            color: Colors.white,
          ),
        ),
        title: const Text(
          'Job Detail',
          style: TextStyle(color: Colors.white),
        ),
        actions: [
          const Icon(
            Icons.bookmark,
            color: Colors.white,
            size: 30,
          ),
          const SizedBox(
            width: 20,
          ),
        ],
        backgroundColor: JColors.splashBackgroundColor,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      //width: 900.w,
                      child: Text(
                        searchJobsResponseData.jobType,
                        style: TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                        ),
                        maxLines: 3,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Text(
                      searchJobsResponseData.companyName,
                      style: TextStyle(
                        color: Colors.grey,
                        fontWeight: FontWeight.bold,
                        fontSize: 19,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    Text(
                      searchJobsResponseData.location,
                      style: TextStyle(
                          color: Colors.grey,
                          fontWeight: FontWeight.normal,
                          fontSize: 18),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    Text(
                      'postedDate : ${searchJobsResponseData.postedDate.substring(0, 10)}',
                      style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.normal,
                        fontSize: 14,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    Text(
                      'closeDate : ${searchJobsResponseData.closeDate.substring(0, 10)}',
                      style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.normal,
                        fontSize: 14,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(
              height: 20,
            ),
            Row(
              children: [
                Expanded(
                  child: Container(
                    height: 26,
                    width: 90,
                    decoration: const BoxDecoration(
                        color: Colors.grey,
                        borderRadius: BorderRadius.all(Radius.circular(5))),
                    child: const Center(child: Text('Full-Time')),
                  ),
                ),
                const SizedBox(
                  width: 6,
                ),
                Expanded(
                  child: Container(
                    height: 26,
                    width: 90,
                    decoration: const BoxDecoration(
                        color: Colors.grey,
                        borderRadius: BorderRadius.all(Radius.circular(5))),
                    child: const Center(child: Text('Remote')),
                  ),
                ),
              ],
            ),
            const SizedBox(
              height: 22,
            ),
            const Text(
              'About The Job',
              style: TextStyle(
                  color: Colors.black,
                  fontWeight: FontWeight.bold,
                  fontSize: 18),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(
              height: 22,
            ),
            Text(
              textAlign: TextAlign.justify,
              searchJobsResponseData.jobDescription,
              style: TextStyle(
                color: Colors.black,
                fontWeight: FontWeight.w500,
                fontSize: 14,
              ),
              maxLines: 10,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(
              height: 20,
            ),
            Text(
              searchJobsResponseData.skillList.toString(),
              style: TextStyle(
                color: Colors.grey.shade500,
                fontWeight: FontWeight.bold,
                fontSize: 15,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            SizedBox(
              height: 40.h,
            ),
            Row(
              children: [
                Expanded(
                  child: InkWell(
                    onTap: () {
                      AlertUtils.showSuccessDialog(
                        context: context,
                        message: 'Are You Apply to This vacancy',
                        onActionPressed: (context) {
                          Navigator.pop(context);

                          ref
                              .watch(
                                  profileCreationStateNotifierProvider.notifier)
                              .applyJobVacancy(
                                hiringAnnouncementID: searchJobsResponseData.id,
                                userID: profileEmail1,
                              );
                        },
                        onCancelActionPressed: (context) {
                          Navigator.pop(context);
                        },
                      );
                    },
                    child: Container(
                      height: 46.h,
                      width: 90,
                      decoration: const BoxDecoration(
                          color: JColors.splashBackgroundColor,
                          borderRadius: BorderRadius.all(Radius.circular(5))),
                      child: const Center(
                          child: Text(
                        'Apply this',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                        ),
                      )),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
