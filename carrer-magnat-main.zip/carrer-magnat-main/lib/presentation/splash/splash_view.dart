import 'package:carrermagnet/application/app_state/app_state_notifier_provider.dart';
import 'package:carrermagnet/routes/routes_name.dart';
import 'package:carrermagnet/utils/constants/colors.dart';
import 'package:dartz/dartz.dart';
import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:flutter_hooks/flutter_hooks.dart';

class SplashView extends HookConsumerWidget {
  const SplashView({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    useEffect(() {
      Future.delayed(Duration.zero, () {
        ref.read(appStateNotifierProvider.notifier).appStart();
      });
      return;
    }, []);

    ref.listen<Option<bool>>(
        appStateNotifierProvider.select((value) => value.isAppStarted),
        (_, value) {
      value.fold(() {}, (value) {
        if (value) {
          final role = ref.read(appStateNotifierProvider).userRole;
          if (ref.read(appStateNotifierProvider).isLoggedIn) {
            if (role.trim().toUpperCase() == 'USER') {
              print('User');
              Navigator.pushNamedAndRemoveUntil(
                context,
                RoutesName
                    .navigationView, // The name of the route you want to navigate to
                (Route<dynamic> route) => false, // Remove all previous routes
              );
            } else {
              print(':::::::::::::::::::RECRUITER');
              print('::::role  ::: $role');
              Navigator.pushNamedAndRemoveUntil(
                context,
                RoutesName
                    .recruiterNavigationView, // The name of the route you want to navigate to
                (Route<dynamic> route) => false, // Remove all previous routes
              );
            }
          } else {
            Navigator.pushNamedAndRemoveUntil(
              context,
              RoutesName
                  .loginView, // The name of the route you want to navigate to
              (Route<dynamic> route) => false, // Remove all previous routes
            );
          }
        }
      });
    });

    return Scaffold(
      backgroundColor: JColors.splashBackgroundColor,
      body: Center(
        child: SizedBox(
            width: double.infinity,
            child: Image.asset(
              'assets/images/careermagnet.png',
              scale: 3,
            )),
      ),
    );
  }
}
