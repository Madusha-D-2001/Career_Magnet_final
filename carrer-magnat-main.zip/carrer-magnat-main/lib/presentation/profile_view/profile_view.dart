import 'package:carrermagnet/application/app_state/app_state_notifier_provider.dart';
import 'package:carrermagnet/application/profile_creation/profile_creation_state_notifier_provider.dart';
import 'package:carrermagnet/presentation/alert/alert_utils.dart';
import 'package:carrermagnet/presentation/core/widgets/common_loading_indicator.dart';
import 'package:carrermagnet/utils/constants/colors.dart';
import 'package:carrermagnet/utils/sizes.dart';
import 'package:flutter/material.dart';
import 'package:flutter_overlay_loader/flutter_overlay_loader.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:flutter_hooks/flutter_hooks.dart';

import '../../routes/routes_name.dart';
import 'log_out_bottopm_sheet.dart';
import 'profile_card.dart';

class ProfileView extends HookConsumerWidget {
  const ProfileView({super.key});
  Widget build(BuildContext context, WidgetRef ref) {
    useEffect(() {
      Future.delayed(Duration.zero, () {
        // Get Login Email ------------------------------------------------------

        final loginSignUpEmail = ref.watch(appStateNotifierProvider.select(
          (value) => value.loginSignUpEmail,
        ));

        final profileEmail = ref.watch(appStateNotifierProvider.select(
          (value) => value.profileEmail,
        ));

        print('loginSignUpEmail ::::: $profileEmail');

        // Get User Detail -------------------------------------------------------
        ref
            .watch(profileCreationStateNotifierProvider.notifier)
            .getProfileDetail(profileEmail);

        // Get All Applied Job Vacancy  -------------------------------------------------------
        ref
            .watch(profileCreationStateNotifierProvider.notifier)
            .getAllAppliedJobVacancy(email: profileEmail);
      });
    }, [
      ref.watch(profileCreationStateNotifierProvider.select(
        (value) => value.isRemoveProject,
      ))
    ]);

    ref.listen<bool>(
      profileCreationStateNotifierProvider.select((value) => value.isLoading),
      (_, value) {
        if (value) {
          Loader.show(context,
              progressIndicator: const CommonLoadingIndicator());
        } else {
          Loader.hide();
        }
      },
    );

    final profileEmail = ref.watch(profileCreationStateNotifierProvider.select(
      (value) => value.email,
    ));

    final prjectDeatilList =
        ref.watch(profileCreationStateNotifierProvider.select(
      (value) => value.projectDetailList,
    ));

    final getAllAppliedJobVacancyList =
        ref.watch(profileCreationStateNotifierProvider.select(
      (value) => value.getAllAppliedJobVacancyList,
    ));

    final profileFullName =
        ref.watch(profileCreationStateNotifierProvider.select(
      (value) => value.fullName,
    ));

    final profileAddress =
        ref.watch(profileCreationStateNotifierProvider.select(
      (value) => value.address,
    ));

    final profileBirth = ref.watch(profileCreationStateNotifierProvider.select(
      (value) => value.birthDay,
    ));

    final profileInfo = ref.watch(profileCreationStateNotifierProvider.select(
      (value) => value.profileInfo,
    ));

    final profileEducation =
        ref.watch(profileCreationStateNotifierProvider.select(
      (value) => value.education,
    ));

    final profileUniversity = ref.watch(profileCreationStateNotifierProvider
        .select((value) => value.university));

    final profilePostion =
        ref.watch(profileCreationStateNotifierProvider.select(
      (value) => value.position,
    ));

    var h = MediaQuery.of(context).size.height;
    var w = MediaQuery.of(context).size.width;

    return Scaffold(
        body: CustomScrollView(
      slivers: [
        SliverAppBar(
          backgroundColor: JColors.splashBackgroundColor,
          expandedHeight: 240.h,
          flexibleSpace: FlexibleSpaceBar(
            background: Stack(
              children: [
                Positioned(
                  top: -150,
                  right: -250,
                  child: Container(
                    width: 400,
                    height: 400,
                    padding: const EdgeInsets.all(0),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(400),
                        color: Colors.white.withOpacity(0.1)),
                    // child: child,
                  ),
                ),
                Positioned(
                  top: 100.h,
                  right: -250,
                  child: Container(
                    width: 400.w,
                    height: 400.h,
                    padding: const EdgeInsets.all(0),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(400),
                      color: Colors.white.withOpacity(0.1),
                      // child: child,
                    ),
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(
                      height: 30.h,
                    ),
                    Row(
                      children: [
                        const Spacer(
                          flex: 1,
                        ),
                        // InkWell(
                        //   onTap: () {
                        //     // Navigator.pushNamed(
                        //     //     context, RoutesName.profileEditView);
                        //     // Get.to(() => EditProfileScreen(),
                        //     //     transition: Transition.downToUp);
                        //     // Get.offAll(
                        //     //     () => ProfileCreateAndEditView());
                        //   },
                        //   child: Container(
                        //     padding:
                        //         const EdgeInsets.symmetric(horizontal: 1),
                        //     alignment: Alignment.centerRight,
                        //     child: const Icon(
                        //       Icons.edit,
                        //       color: Colors.white,
                        //       size: 30,
                        //     ),
                        //   ),
                        // ),
                        InkWell(
                          onTap: () {
                            logOutBottomSheet(context, ref);
                            //    profileViewModel.logOut(context);
                            // profileViewModel.fetchUserData(context);
                            print('log Out ***********************');
                          },
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10),
                            alignment: Alignment.centerRight,
                            child: const Icon(
                              Icons.settings,
                              color: Colors.white,
                              size: 30,
                            ),
                          ),
                        ),

                        SizedBox(
                          width: 10.h,
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: TSizes.spaceBtwItems,
                    ),
                    CircleAvatar(
                      maxRadius: 40.h,
                      backgroundImage: const NetworkImage(
                        'https://thumbs.dreamstime.com/b/default-avatar-profile-icon-vector-social-media-user-image-182145777.jpg',
                      ),
                    ),
                    SizedBox(
                      height: 5.h,
                    ),
                    SizedBox(
                      width: double.infinity,
                      child: Text(
                        textAlign: TextAlign.center,
                        profileFullName,
                        style:
                            const TextStyle(fontSize: 20, color: Colors.white),
                      ),
                    ),
                    SizedBox(
                      height: 5.h,
                    ),
                    Container(
                      width: double.infinity,
                      child: Text(
                        textAlign: TextAlign.center,
                        profilePostion,
                        style:
                            const TextStyle(fontSize: 12, color: Colors.white),
                      ),
                    ),
                    SizedBox(
                      height: 10.h,
                    ),
                    Container(
                      width: double.infinity,
                      child: Text(
                        textAlign: TextAlign.center,
                        profileInfo,
                        style:
                            const TextStyle(fontSize: 12, color: Colors.white),
                      ),
                    ),
                  ],
                )
              ],
            ),
          ),
        ),
        SliverList.list(
          children: <Widget>[
            const SizedBox(
              height: 6,
            ),
            Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 14,
                vertical: 10,
              ),
              width: 1000.w,
              child: const Row(
                children: [
                  Icon(
                    Icons.info_outlined,
                    color: JColors.splashBackgroundColor,
                  ),
                  SizedBox(
                    width: 6,
                  ),
                  Text(
                    'Profile Detail',
                    style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 17,
                    ),
                  ),
                  Spacer(
                    flex: 1,
                  ),
                ],
              ),
            ),
            // Name ------------------------------------------------------------
            ProfileDetailCard(
              profileFullName: profileEmail,
              icon: Icons.email,
              title: 'Email',
            ),
            ProfileDetailCard(
              profileFullName: profileFullName,
              icon: Icons.people,
              title: 'Full Name',
            ),
            ProfileDetailCard(
              profileFullName: profileBirth,
              icon: Icons.calendar_month,
              title: 'Birth Day',
            ),
            ProfileDetailCard(
              profileFullName: profileInfo,
              icon: Icons.details,
              title: 'About',
            ),
            ProfileDetailCard(
              profileFullName: profileEducation,
              icon: Icons.menu_book_rounded,
              title: 'Education',
            ),
            ProfileDetailCard(
              profileFullName: profileUniversity,
              icon: Icons.school,
              title: 'University',
            ),

            ProfileDetailCard(
              profileFullName: profileAddress,
              icon: Icons.home,
              title: 'Address',
            ),

            const SizedBox(
              height: 16,
            ),

            // project section ---------------------------------------------

            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              width: 1000.w,
              child: Row(
                children: [
                  const Icon(
                    Icons.folder_copy,
                    color: JColors.splashBackgroundColor,
                  ),
                  const SizedBox(
                    width: 6,
                  ),
                  const Text(
                    'Projects',
                    style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 17,
                    ),
                  ),
                  const Spacer(
                    flex: 1,
                  ),
                  InkWell(
                    onTap: () {
                      Navigator.popAndPushNamed(
                        context,
                        RoutesName.addNewProjectView,
                      );
                    },
                    child: const Text(
                      '+ Add',
                      style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                        fontSize: 17,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(
              height: 6,
            ),
          ],
        ),
        SliverList(
          delegate: SliverChildBuilderDelegate(
            childCount: prjectDeatilList.size,
            (context, index) {
              final projectName = prjectDeatilList[index].project_name;
              final projectDescription = prjectDeatilList[index].description;
              final skilList = prjectDeatilList[index].used_skills;
              final projectID = prjectDeatilList[index].project_id;
              return Container(
                margin: const EdgeInsets.all(10),
                //height: 190,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.3), // Shadow color
                      spreadRadius: 2, // Spread radius
                      blurRadius: 5, // Blur radius
                      offset: const Offset(0, 3), // Shadow position
                    ),
                  ],
                ),
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            projectName,
                            style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                              fontSize: 15,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          InkWell(
                            onTap: () {
                              AlertUtils.showSuccessDialog(
                                context: context,
                                message: 'Are You Sure To remove this project',
                                onActionPressed: (context) {
                                  ref
                                      .watch(
                                          profileCreationStateNotifierProvider
                                              .notifier)
                                      .removeProjects(projectID: projectID);
                                  Navigator.pop(context);
                                },
                                onCancelActionPressed: (context) {
                                  Navigator.pop(context);
                                },
                              );
                            },
                            child: Icon(
                              Icons.delete,
                              color: JColors.splashBackgroundColor,
                            ),
                          )
                        ],
                      ),
                      const SizedBox(
                        height: 6,
                      ),
                      Text(
                        projectDescription,
                        style: TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.normal,
                          fontSize: 12,
                        ),
                        maxLines: 10,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(
                        height: 6,
                      ),
                      Text(
                        'Technologies : ${skilList}',
                        style: TextStyle(
                          color: Colors.grey.shade500,
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                        ),
                        maxLines: 4,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(
                        height: 6,
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),

        // All Appled Jobs --

        SliverList.list(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              width: 1000.w,
              child: Row(
                children: [
                  const Icon(
                    Icons.work,
                    color: JColors.splashBackgroundColor,
                  ),
                  const SizedBox(
                    width: 6,
                  ),
                  const Text(
                    'Applied Jobs',
                    style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 17,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),

        SliverList(
          delegate: SliverChildBuilderDelegate(
            childCount: getAllAppliedJobVacancyList.size,
            (context, index) {
              final message = getAllAppliedJobVacancyList[index].message;
              final companyName =
                  getAllAppliedJobVacancyList[index].companyName;
              final postedDate = getAllAppliedJobVacancyList[index].postedDate;
              final closeDate = getAllAppliedJobVacancyList[index].closeDate;
              final jobType = getAllAppliedJobVacancyList[index].jobType;
              final location = getAllAppliedJobVacancyList[index].location;
              final companyRespondStatus =
                  getAllAppliedJobVacancyList[index].companyRespondStatus;
              return Container(
                margin: const EdgeInsets.all(10),
                //height: 190,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.3), // Shadow color
                      spreadRadius: 2, // Spread radius
                      blurRadius: 5, // Blur radius
                      offset: const Offset(0, 3), // Shadow position
                    ),
                  ],
                ),
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            jobType,
                            style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                              fontSize: 15,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 6,
                      ),
                      Text(
                        companyName,
                        style: TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.normal,
                          fontSize: 12,
                        ),
                        maxLines: 10,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(
                        height: 6,
                      ),
                      Text(
                        location,
                        style: TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.normal,
                          fontSize: 12,
                        ),
                        maxLines: 10,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(
                        height: 6,
                      ),
                      Text(
                        'postedDate : ${postedDate.substring(0, 10)}',
                        style: TextStyle(
                          color: Colors.grey.shade500,
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                        ),
                        maxLines: 4,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(
                        height: 6,
                      ),
                      Text(
                        'closeDate : ${closeDate.substring(0, 10)}',
                        style: TextStyle(
                          color: Colors.grey.shade500,
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                        ),
                        maxLines: 4,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(
                        height: 6,
                      ),
                      Text(
                        'Response Status : ${companyRespondStatus}',
                        style: TextStyle(
                          color: Colors.grey.shade500,
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                        ),
                        maxLines: 4,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(
                        height: 6,
                      ),
                      Text(
                        'Response Message: ${message}',
                        style: TextStyle(
                          color: Colors.grey.shade500,
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                        ),
                        maxLines: 4,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(
                        height: 6,
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    ));
  }
}
