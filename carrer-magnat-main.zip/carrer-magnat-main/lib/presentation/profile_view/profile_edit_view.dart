import 'package:carrermagnet/utils/constants/colors.dart';
import 'package:carrermagnet/utils/validators/validators.dart';
import 'package:flutter/material.dart';

class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({super.key});

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  List<String> _selectedItems = [];

  TextEditingController fullNameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController phoneNumberController = TextEditingController();
  TextEditingController birthDayController = TextEditingController();
  TextEditingController addressController = TextEditingController();
  TextEditingController profileInfoController = TextEditingController();
  TextEditingController educationController = TextEditingController();
  TextEditingController universityController = TextEditingController();
  TextEditingController positionController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: const Icon(
          Icons.arrow_back,
          color: Colors.white,
        ),
        title: const Text(
          'Profile Create',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: JColors.splashBackgroundColor,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
          child: Form(
            //key: profileController.profileCreationFormKey,
            child: Column(
              children: [
                // full name -----------

                TextFormField(
                  controller: fullNameController,
                  validator: (value) =>
                      Vvalidator.validateEmptyText('Full Name', value),
                  decoration: InputDecoration(
                      hintText: 'Full Name',
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                      prefixIcon: const Icon(
                        Icons.person,
                        color: Colors.grey,
                      )),
                ),

                const SizedBox(
                  height: 10,
                ),

                TextFormField(
                  controller: emailController,
                  validator: (value) =>
                      Vvalidator.validateEmptyText('Email', value),
                  decoration: InputDecoration(
                      hintText: 'Email',
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                      prefixIcon: const Icon(
                        Icons.person,
                        color: Colors.grey,
                      )),
                ),

                const SizedBox(
                  height: 10,
                ),

                TextFormField(
                  controller: addressController,
                  validator: (value) =>
                      Vvalidator.validateEmptyText('Address', value),
                  decoration: InputDecoration(
                      hintText: 'Address',
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                      prefixIcon: const Icon(
                        Icons.person,
                        color: Colors.grey,
                      )),
                ),

                const SizedBox(
                  height: 10,
                ),

                // position

                TextFormField(
                  controller: positionController,
                  validator: (value) =>
                      Vvalidator.validateEmptyText('Position', value),
                  decoration: InputDecoration(
                      hintText: 'Position',
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                      prefixIcon: const Icon(
                        Icons.work,
                        color: Colors.grey,
                      )),
                ),

                const SizedBox(
                  height: 10,
                ),

                // profile info -----------------

                TextFormField(
                  controller: profileInfoController,
                  validator: (value) =>
                      Vvalidator.validateEmptyText('Profile Info', value),
                  decoration: InputDecoration(
                      hintText: 'Profile Info',
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                      prefixIcon: const Icon(
                        Icons.info,
                        color: Colors.grey,
                      )),
                ),

                const SizedBox(
                  height: 10,
                ),
                // SizedBox(
                //   height: 55,
                //   child: TextFormField(
                //     decoration: InputDecoration(
                //         hintText: 'Skill',
                //         filled: true,
                //         fillColor: Colors.white,
                //         border: OutlineInputBorder(
                //             borderRadius: BorderRadius.circular(10)),
                //         prefixIcon: const Icon(
                //           Icons.tips_and_updates_outlined,
                //           color: Colors.grey,
                //         )),
                //   ),
                // ),

                InkWell(
                  onTap: _showMultiSelect,
                  child: Container(
                    height: 55,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(color: Colors.grey, width: 2),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Row(
                      children: [
                        SizedBox(
                          width: 10,
                        ),
                        Icon(
                          Icons.tips_and_updates,
                          color: Colors.grey,
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Text("SKiLL"),
                      ],
                    ),
                  ),
                ),

                const SizedBox(
                  height: 10,
                ),

                Wrap(
                  children: _selectedItems
                      .map((e) => Container(
                            decoration: BoxDecoration(
                                border:
                                    Border.all(color: Colors.grey, width: 2),
                                borderRadius: BorderRadius.circular(10)),
                            margin: EdgeInsets.only(left: 2),
                            padding: EdgeInsets.symmetric(horizontal: 10),
                            child: Text(e),
                          ))
                      .toList(),
                ),

                const SizedBox(
                  height: 10,
                ),

                // education --------------------

                TextFormField(
                  controller: educationController,
                  validator: (value) =>
                      Vvalidator.validateEmptyText('Education', value),
                  decoration: InputDecoration(
                      hintText: 'Education',
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                      prefixIcon: const Icon(
                        Icons.person,
                        color: Colors.grey,
                      )),
                ),
                const SizedBox(
                  height: 10,
                ),

                // university ---------------

                TextFormField(
                  controller: universityController,
                  validator: (value) =>
                      Vvalidator.validateEmptyText('University', value),
                  decoration: InputDecoration(
                      hintText: 'University',
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                      prefixIcon: const Icon(
                        Icons.cast_for_education,
                        color: Colors.grey,
                      )),
                ),
                const SizedBox(
                  height: 10,
                ),

                // Contact Number --------------------------------------

                TextFormField(
                  controller: phoneNumberController,
                  validator: (value) =>
                      Vvalidator.validateEmptyText('Contact Number', value),
                  decoration: InputDecoration(
                      hintText: 'Contact Number',
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                      prefixIcon: const Icon(
                        Icons.phone,
                        color: Colors.grey,
                      )),
                ),
                const SizedBox(
                  height: 10,
                ),

                // birth day --------------------------------------

                TextFormField(
                  controller: birthDayController,
                  validator: (value) =>
                      Vvalidator.validateEmptyText('Birth Day', value),
                  keyboardType: TextInputType.datetime,
                  decoration: InputDecoration(
                      hintText: 'Birth Day (YYYY-MM-DD)',
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                      prefixIcon: const Icon(
                        Icons.calendar_month,
                        color: Colors.grey,
                      )),
                ),

                const SizedBox(
                  height: 40,
                ),

                InkWell(
                  onTap: () {
                    // if (fullNameController.text.isEmpty) {
                    //   Utils.flutterErrorMessage(
                    //       'Please Enter full Name', context);
                    // } else if (emailController.text.isEmpty) {
                    //   Utils.flutterErrorMessage('Please Enter Email', context);
                    // } else if (phoneNumberController.text.isEmpty) {
                    //   Utils.flutterErrorMessage(
                    //       'Please Enter Phone Number', context);
                    // } else if (birthDayController.text.isEmpty) {
                    //   Utils.flutterErrorMessage(
                    //       'Please Enter Birth Day', context);
                    // } else if (addressController.text.isEmpty) {
                    //   Utils.flutterErrorMessage(
                    //       'Please Enter Address', context);
                    // } else if (profileInfoController.text.isEmpty) {
                    //   Utils.flutterErrorMessage('Please Enter About', context);
                    // } else if (educationController.text.isEmpty) {
                    //   Utils.flutterErrorMessage(
                    //       'Please Enter Education', context);
                    // } else if (universityController.text.isEmpty) {
                    //   Utils.flutterErrorMessage(
                    //       'Please Enter Univercity', context);
                    // } else if (positionController.text.isEmpty) {
                    //   Utils.flutterErrorMessage(
                    //       'Please Enter Position', context);
                    // } else {
                    //   Map data = {
                    //     "email": "pathum@gmail.com",
                    //     "fullName": fullNameController.text,
                    //     "address": addressController.text,
                    //     "birthDay": birthDayController.text,
                    //     "profileInfo": profileInfoController.text,
                    //     "education": educationController.text,
                    //     "university": universityController.text,
                    //     "position": positionController.text,
                    //     "skillList": ["Java", "MySQL", "Springboot", "Angular"]

                    //     // "email": "pathum@gmail.com",
                    //     // "fullName": "Pathum Madhushan Dissnayaka",
                    //     // "address": "No 15, Kandegedara, Hali-Ella",
                    //     // "birthDay": "1998-12-12",
                    //     // "profileInfo": "This is sample profile info",
                    //     // "education": "Bsc in Computer Science",
                    //     // "university": "Eastern university",
                    //     // "position": "Software Engineer",
                    //     // "skillList": ["Java", "MySQL", "Springboot", "Angular"]
                    //   };

                    //   profileViewModel.setLoading(true);

                    //   profileViewModel.addDetail(data, context);
                    //   // profileViewModel.fetchUserData(context);

                    //   print('@@@@@@@@@@ Api Hints');
                    // }

                    // // Close the keyboard ....................
                    // FocusScope.of(context).unfocus();
                  },
                  child: Container(
                    height: 44,
                    width: 200,
                    decoration: const BoxDecoration(
                        color: JColors.splashBackgroundColor,
                        borderRadius: BorderRadius.all(Radius.circular(20))),
                    child: Center(
                      child: const Text(
                        'Create Account',
                        style: TextStyle(color: Colors.white, fontSize: 16),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showMultiSelect() async {
    final List<String> items = [
      'Flutter',
      'React Native',
      'Java',
      'Docker',
    ];

    final List<String>? results = await showDialog(
      context: context,
      builder: (BuildContext context) {
        return MultySelect(
          items: items,
        );
      },
    );

    //update UI

    if (results != null) {
      setState(() {
        _selectedItems = results;
      });
    }
  }
}

class MultySelect extends StatefulWidget {
  final List<String> items;
  const MultySelect({
    Key? key,
    required this.items,
  }) : super(key: key);

  @override
  State<MultySelect> createState() => _MultySelectState();
}

class _MultySelectState extends State<MultySelect> {
  // this varible holds the selected items
  final List<String> _selectItems = [];

  // this function is triggered check ot un checked

  void _itemChange(String itemValue, bool isSelected) {
    setState(() {
      if (isSelected) {
        _selectItems.add(itemValue);
      } else {
        _selectItems.remove(itemValue);
      }
    });
  }

  // this function is calles when the cancel vutton is pressed

  void _cancel() {
    Navigator.pop(context);
  }

  void _submit() {
    Navigator.pop(context, _selectItems);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Select Topics'),
      content: SingleChildScrollView(
          child: ListBody(
        children: widget.items
            .map((items) => CheckboxListTile(
                  value: _selectItems.contains(items),
                  title: Text(items),
                  controlAffinity: ListTileControlAffinity.leading,
                  onChanged: (isChecked) => _itemChange(items, isChecked!),
                ))
            .toList(),
      )),
      actions: [
        TextButton(onPressed: _cancel, child: const Text('Cancel')),
        TextButton(onPressed: _submit, child: const Text('Submit'))
      ],
    );
  }
}
