import 'package:flutter/material.dart';

class MultySelect extends StatefulWidget {
  final List<String> items;
  const MultySelect({
    Key? key,
    required this.items,
  }) : super(key: key);

  @override
  State<MultySelect> createState() => _MultySelectState();
}

class _MultySelectState extends State<MultySelect> {
  // this varible holds the selected items
  final List<String> _selectItems = [];

  // this function is triggered check ot un checked

  void _itemChange(String itemValue, bool isSelected) {
    setState(() {
      if (isSelected) {
        _selectItems.add(itemValue);
      } else {
        _selectItems.remove(itemValue);
      }
    });
  }

  // this function is calles when the cancel Button is pressed

  void _cancel() {
    Navigator.pop(context);
  }

  void _submit() {
    Navigator.pop(context, _selectItems);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Select Topics'),
      content: SingleChildScrollView(
          child: ListBody(
        children: widget.items
            .map((items) => CheckboxListTile(
                  value: _selectItems.contains(items),
                  title: Text(items),
                  controlAffinity: ListTileControlAffinity.leading,
                  onChanged: (isChecked) => _itemChange(items, isChecked!),
                ))
            .toList(),
      )),
      actions: [
        TextButton(onPressed: _cancel, child: const Text('Cancel')),
        TextButton(onPressed: _submit, child: const Text('Submit'))
      ],
    );
  }
}
