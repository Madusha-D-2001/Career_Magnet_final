import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../application/app_state/app_state_notifier_provider.dart';
import '../../routes/routes_name.dart';
import '../../utils/constants/colors.dart';

void logOutBottomSheet(
  BuildContext context,
  WidgetRef ref,
) {
  showModalBottomSheet(
    isScrollControlled: true,
    context: context,
    backgroundColor: Colors.black,
    builder: (context) {
      return Container(
        decoration: const BoxDecoration(
          color: JColors.splashBackgroundColor,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(20),
            topRight: Radius.circular(20),
          ),
        ),
        height: 150,
        width: double.infinity,
        child: Column(
          children: [
            const SizedBox(
              height: 8,
            ),
            Container(
              height: 6,
              width: 70,
              decoration: const BoxDecoration(
                color: JColors.splashBackgroundColor,
                borderRadius: BorderRadius.all(
                  Radius.circular(20),
                ),
              ),
            ),
            const SizedBox(
              height: 28,
            ),
            InkWell(
              onTap: () {
                ref.watch(appStateNotifierProvider.notifier).logout();
                Navigator.pushNamedAndRemoveUntil(
                  context,
                  RoutesName.loginView,
                  (Route<dynamic> route) => false,
                );
              },
              child: const Text(
                "Log out",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(
              height: 15,
            ),

            // remove account --------------------------------------------------
            const Text(
              "if you want log out please click",
              style: TextStyle(
                color: Colors.white,
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      );
    },
  );
}
