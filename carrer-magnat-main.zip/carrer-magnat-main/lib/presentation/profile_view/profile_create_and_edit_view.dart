import 'package:carrermagnet/application/app_state/app_state_notifier_provider.dart';
import 'package:carrermagnet/application/profile_creation/profile_creation_state_notifier_provider.dart';
import 'package:carrermagnet/domain/core/failure.dart';
import 'package:carrermagnet/domain/profile_creation/profile_creation_response.dart';
import 'package:carrermagnet/presentation/alert/alert_utils.dart';
import 'package:carrermagnet/presentation/profile_view/profile_edit_view.dart';
import 'package:carrermagnet/utils/constants/colors.dart';
import 'package:carrermagnet/utils/validators/validators.dart';
import 'package:dartz/dartz.dart';
import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:intl/intl.dart';

import '../../routes/routes_name.dart';

class ProfileCreateAndEditView extends HookConsumerWidget {
  ProfileCreateAndEditView({
    super.key,
    required this.email,
  });

  String email;

  final GlobalKey<FormState> signUpFormKey = GlobalKey<FormState>();

  TextEditingController fullNameController = TextEditingController();
  TextEditingController lastNameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController addressController = TextEditingController();
  TextEditingController universityController = TextEditingController();
  TextEditingController educationController = TextEditingController();
  TextEditingController birthDayController = TextEditingController();
  TextEditingController positionController = TextEditingController();
  TextEditingController profileInfoController = TextEditingController();
  TextEditingController phoneNumberController = TextEditingController();

  List<String> _selectedItems = [];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // Get Login Email ------------------------------------------------------

    ref.listen<Option<Failure>>(
        profileCreationStateNotifierProvider
            .select((value) => value.responseFailure), (_, value) {
      value.fold(() {}, (failure) {
        AlertUtils.showErrorDialog(
            context: context, message: failure.toString());
      });
    });

    // ref.listen<bool>(
    //   profileCreationStateNotifierProvider.select((value) => value.isLoading),
    //   (_, value) {
    //     if (value) {
    //       Loader.show(context,
    //           progressIndicator: const CommonLoadingIndicator());
    //     } else {
    //       Loader.hide();
    //     }
    //   },
    // );

    ref.listen<Option<ProfileCreationResponse>>(
      profileCreationStateNotifierProvider
          .select((value) => value.profileCreationResponse),
      (_, value) {
        value.fold(() {}, (response) {
          // set Email
          ref.read(appStateNotifierProvider.notifier).setEmail(email);

          AlertUtils.showSuccessDialog(
            context: context,
            title: 'Compeleted',
            message: 'Your Profile is Complete',
            onActionPressed: (context) {
              Navigator.pushNamedAndRemoveUntil(
                context,
                RoutesName
                    .navigationView, // The name of the route you want to navigate to
                (Route<dynamic> route) => false, // Remove all previous routes
              );
            },
          );
        });
      },
    );
    DateTime birthDay = DateTime.now();

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Create profile',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: JColors.splashBackgroundColor,
      ),
      body: SingleChildScrollView(
        child: Form(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
            child: Column(
              children: [
                // full name -----------

                TextFormField(
                  controller: fullNameController,
                  validator: (value) =>
                      Vvalidator.validateEmptyText('Full Name', value),
                  decoration: InputDecoration(
                      hintText: 'Full Name',
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                      prefixIcon: const Icon(
                        Icons.person,
                        color: Colors.grey,
                      )),
                ),

                const SizedBox(
                  height: 10,
                ),
                // email ---
                TextFormField(
                  readOnly: true,
                  //controller: emailController,
                  validator: (value) =>
                      Vvalidator.validateEmptyText('Email', value),
                  decoration: InputDecoration(
                      hintText: email,
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                      prefixIcon: const Icon(
                        Icons.person,
                        color: Colors.grey,
                      )),
                ),

                const SizedBox(
                  height: 10,
                ),

                // address -----------------------------------------------------

                TextFormField(
                  controller: addressController,
                  validator: (value) =>
                      Vvalidator.validateEmptyText('Address', value),
                  decoration: InputDecoration(
                      hintText: 'Address',
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                      prefixIcon: const Icon(
                        Icons.person,
                        color: Colors.grey,
                      )),
                ),

                const SizedBox(
                  height: 10,
                ),

                // position

                TextFormField(
                  controller: positionController,
                  validator: (value) =>
                      Vvalidator.validateEmptyText('Position', value),
                  decoration: InputDecoration(
                      hintText: 'Position',
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                      prefixIcon: const Icon(
                        Icons.work,
                        color: Colors.grey,
                      )),
                ),

                const SizedBox(
                  height: 10,
                ),

                // profile info -----------------

                TextFormField(
                  controller: profileInfoController,
                  validator: (value) =>
                      Vvalidator.validateEmptyText('Profile Info', value),
                  decoration: InputDecoration(
                      hintText: 'Profile Info',
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                      prefixIcon: const Icon(
                        Icons.info,
                        color: Colors.grey,
                      )),
                ),

                const SizedBox(
                  height: 10,
                ),

                InkWell(
                  onTap: () async {
                    final List<String> items = [
                      'Flutter',
                      'React Native',
                      'Java',
                      'Docker',
                    ];

                    final List<String> results = await showDialog(
                      context: context,
                      builder: (BuildContext context) {
                        return MultySelect(
                          items: items,
                        );
                      },
                    );

                    ref
                        .read(profileCreationStateNotifierProvider.notifier)
                        .setSkillsToList(results);

                    print('SKill List :::$results');

                    // useState();
                  },
                  child: Container(
                    height: 55,
                    decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey, width: 2),
                        borderRadius: BorderRadius.circular(10)),
                    child: const Row(
                      children: [
                        SizedBox(
                          width: 10,
                        ),
                        Icon(
                          Icons.tips_and_updates,
                          color: Colors.grey,
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Text("SKiLL"),
                      ],
                    ),
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),

                // InkWell(
                //   onTap: () async {
                //     final List<String> items = [
                //       "Java",
                //       "Python",
                //       "JavaScript",
                //       "SQL",
                //       "Spring Boot",
                //     ];

                //     final List<String> results = await showDialog(
                //       context: context,
                //       builder: (BuildContext context) {
                //         return MultySelect(
                //           items: items,
                //         );
                //       },
                //     );

                //     ref
                //         .read(profileCreationStateNotifierProvider.notifier)
                //         .setSkillsToList(results);

                //     print('SKill List :::$results');

                //     // useState();
                //   },
                //   child: Container(
                //     padding: EdgeInsets.all(4),
                //     height: 55,
                //     decoration: BoxDecoration(
                //         border: Border.all(color: Colors.grey, width: 2),
                //         borderRadius: BorderRadius.circular(10)),
                //     child: const Row(
                //       children: [
                //         SizedBox(
                //           width: 10,
                //         ),
                //         Icon(
                //           Icons.tips_and_updates,
                //           color: Colors.grey,
                //         ),
                //         SizedBox(
                //           width: 10,
                //         ),
                //         Text("SKiLL"),
                //       ],
                //     ),
                //   ),
                // ),

                Wrap(
                  children: ref
                      .watch(profileCreationStateNotifierProvider
                          .select((value) => value.results))
                      .map((e) => Container(
                            decoration: BoxDecoration(
                                border:
                                    Border.all(color: Colors.grey, width: 2),
                                borderRadius: BorderRadius.circular(10)),
                            margin: EdgeInsets.only(left: 2),
                            padding: EdgeInsets.symmetric(horizontal: 10),
                            child: Text(e),
                          ))
                      .toList(),
                ),

                const SizedBox(
                  height: 10,
                ),

                // education --------------------

                TextFormField(
                  controller: educationController,
                  validator: (value) =>
                      Vvalidator.validateEmptyText('Education', value),
                  decoration: InputDecoration(
                      hintText: 'Education',
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                      prefixIcon: const Icon(
                        Icons.person,
                        color: Colors.grey,
                      )),
                ),
                const SizedBox(
                  height: 10,
                ),

                // university ---------------

                TextFormField(
                  controller: universityController,
                  validator: (value) =>
                      Vvalidator.validateEmptyText('University', value),
                  decoration: InputDecoration(
                      hintText: 'University',
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                      prefixIcon: const Icon(
                        Icons.cast_for_education,
                        color: Colors.grey,
                      )),
                ),
                const SizedBox(
                  height: 10,
                ),

                // Contact Number --------------------------------------

                TextFormField(
                  controller: phoneNumberController,
                  validator: (value) =>
                      Vvalidator.validateEmptyText('Contact Number', value),
                  decoration: InputDecoration(
                      hintText: 'Contact Number',
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                      prefixIcon: const Icon(
                        Icons.phone,
                        color: Colors.grey,
                      )),
                ),
                const SizedBox(
                  height: 10,
                ),

                // birth day --------------------------------------

                TextFormField(
                  validator: (value) =>
                      Vvalidator.validateEmptyText('Birth Day', value),
                  controller: birthDayController,
                  readOnly: true, // Makes sure the keyboard doesn't open
                  onTap: () async {
                    FocusScope.of(context)
                        .requestFocus(FocusNode()); // Dismiss the keyboard
                    DateTime? pickedDate = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime(1900), // Set a minimum date if needed
                      lastDate: DateTime(2100), // Set a maximum date if needed
                    );

                    if (pickedDate != null) {
                      // Set the time to 09:00:00 and convert to UTC
                      DateTime dateWithTime = DateTime(
                        pickedDate.year,
                        pickedDate.month,
                        pickedDate.day,
                        9, // Hour set to 9
                        0, // Minute set to 0
                        0, // Second set to 0
                      ).toUtc();

                      // Format the date as "yyyy-MM-dd"
                      birthDayController.text =
                          DateFormat("yyyy-MM-dd").format(dateWithTime);

                      final DateTime birthDate = DateTime.utc(
                          pickedDate.year, pickedDate.month, pickedDate.day);

                      birthDay = birthDate;
                    }
                  },
                  decoration: InputDecoration(
                    hintText: 'Birth Date',
                    filled: true,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    prefixIcon: const Icon(
                      Icons.calendar_month,
                      color: Colors.grey,
                    ),
                  ),
                ),

                const SizedBox(
                  height: 40,
                ),

                InkWell(
                  onTap: () {
                    ref
                        .read(profileCreationStateNotifierProvider.notifier)
                        .profileCreation(
                          email,
                          fullNameController.text,
                          addressController.text,
                          birthDay,
                          profileInfoController.text,
                          educationController.text,
                          universityController.text,
                          positionController.text,
                        );

                    // ref
                    //     .read(profileCreationStateNotifierProvider.notifier)
                    //     .profileCreation(
                    //       'pathum@gmail.com',
                    //       'Madhushan Dissnayaka',
                    //       "No 15, Kandegedara, Hali-Ella",
                    //       "1998-12-12",
                    //       "This is sample profile info",
                    //       "Bsc in Computer Science",
                    //       "Estern",
                    //       "Software Engineer",
                    //     );

                    // if (fullNameController.text.isEmpty) {
                    //   Utils.flutterErrorMessage(
                    //       'Please Enter full Name', context);
                    // } else if (emailController.text.isEmpty) {
                    //   Utils.flutterErrorMessage('Please Enter Email', context);
                    // } else if (phoneNumberController.text.isEmpty) {
                    //   Utils.flutterErrorMessage(
                    //       'Please Enter Phone Number', context);
                    // } else if (birthDayController.text.isEmpty) {
                    //   Utils.flutterErrorMessage(
                    //       'Please Enter Birth Day', context);
                    // } else if (addressController.text.isEmpty) {
                    //   Utils.flutterErrorMessage(
                    //       'Please Enter Address', context);
                    // } else if (profileInfoController.text.isEmpty) {
                    //   Utils.flutterErrorMessage('Please Enter About', context);
                    // } else if (educationController.text.isEmpty) {
                    //   Utils.flutterErrorMessage(
                    //       'Please Enter Education', context);
                    // } else if (universityController.text.isEmpty) {
                    //   Utils.flutterErrorMessage(
                    //       'Please Enter Univercity', context);
                    // } else if (positionController.text.isEmpty) {
                    //   Utils.flutterErrorMessage(
                    //       'Please Enter Position', context);
                    // } else {
                    //   Map data = {
                    //     "email": "pathum@gmail.com",
                    //     "fullName": fullNameController.text,
                    //     "address": addressController.text,
                    //     "birthDay": birthDayController.text,
                    //     "profileInfo": profileInfoController.text,
                    //     "education": educationController.text,
                    //     "university": universityController.text,
                    //     "position": positionController.text,
                    //     "skillList": ["Java", "MySQL", "Springboot", "Angular"]

                    //     // "email": "pathum@gmail.com",
                    //     // "fullName": "Pathum Madhushan Dissnayaka",
                    //     // "address": "No 15, Kandegedara, Hali-Ella",
                    //     // "birthDay": "No 15, Kandegedara, Hali-Ella",
                    //     // "profileInfo": "This is sample profile info",
                    //     // "education": "Bsc in Computer Science",
                    //     // "university": "Bsc in Computer Science",
                    //     // "position": "Software Engineer",
                    //     // "skillList": ["Java", "MySQL", "Springboot", "Angular"]
                    //   };

                    //   profileViewModel.setLoading(true);

                    //   profileViewModel.addDetail(data, context);
                    //   // profileViewModel.fetchUserData(context);

                    //   print('@@@@@@@@@@ Api Hints');
                    // }

                    // Close the keyboard ....................
                    FocusScope.of(context).unfocus();
                  },
                  child: Container(
                    height: 54,
                    width: double.infinity,
                    decoration: const BoxDecoration(
                        color: JColors.splashBackgroundColor,
                        borderRadius: BorderRadius.all(Radius.circular(20))),
                    child: const Center(
                      child: Text(
                        'Create Account',
                        style: TextStyle(color: Colors.white, fontSize: 16),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
