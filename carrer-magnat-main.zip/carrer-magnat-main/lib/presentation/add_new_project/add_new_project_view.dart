import 'package:carrermagnet/application/recruiter/recruiter_state_notifier_provider.dart';
import 'package:carrermagnet/presentation/core/widgets/common_loading_indicator.dart';
import 'package:dartz/dartz.dart';
import 'package:flutter/material.dart';
import 'package:flutter_overlay_loader/flutter_overlay_loader.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../application/profile_creation/profile_creation_state_notifier_provider.dart';
import '../../domain/add_hiring_announcement/add_hiring_announcement_response.dart';
import '../../routes/routes_name.dart';
import '../../utils/constants/colors.dart';
import '../../utils/validators/validators.dart';
import '../alert/alert_utils.dart';
import '../profile_view/profile_edit_view.dart';

class AddNewProjectView extends HookConsumerWidget {
  AddNewProjectView({super.key});

  TextEditingController projectNameController = TextEditingController();
  TextEditingController projectDescriptionController = TextEditingController();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    ref.listen<bool>(
      profileCreationStateNotifierProvider
          .select((value) => value.isAddProjectLoading),
      (_, value) {
        if (value) {
          Loader.show(context,
              progressIndicator: const CommonLoadingIndicator());
        } else {
          Loader.hide();
        }
      },
    );

    ref.listen<Option<AddHiringAnnouncementResponse>>(
        profileCreationStateNotifierProvider
            .select((value) => value.addNewProjectResponse), (_, value) {
      value.fold(() {}, (failure) {
        AlertUtils.showSuccessDialog(
          context: context,
          message: 'Project Add sucess',
          onActionPressed: (context) {
            Navigator.pop(context);
            Navigator.pushNamedAndRemoveUntil(
              context,
              RoutesName.navigationView,
              (Route<dynamic> route) => false,
            );
          },
        );
      });
    });

    ref.listen<bool>(
      recruiterStateNotifierProvider
          .select((value) => value.isdeleteHiringAnnouncementLoading),
      (_, value) {
        if (value) {
          Loader.show(context,
              progressIndicator: const CommonLoadingIndicator());
        } else {
          Loader.hide();
        }
      },
    );

    final userProfileId = ref.watch(profileCreationStateNotifierProvider.select(
      (value) => value.userProfileID,
    ));

    return Scaffold(
      appBar: AppBar(
        leading: InkWell(
          onTap: () {
            Navigator.pushNamedAndRemoveUntil(
              context,
              RoutesName
                  .navigationView, // The name of the route you want to navigate to
              (Route<dynamic> route) => false, // Remove all previous routes
            );
          },
          child: const Icon(
            Icons.arrow_back,
            color: Colors.white,
          ),
        ),
        title: const Text(
          'Add Projects',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: JColors.splashBackgroundColor,
      ),
      body: SingleChildScrollView(
        child: Form(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
            child: Column(
              children: [
                // Job Type -----------

                TextFormField(
                  controller: projectNameController,
                  validator: (value) =>
                      Vvalidator.validateEmptyText('Project Name', value),
                  decoration: InputDecoration(
                      hintText: 'Project Name',
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                      prefixIcon: const Icon(
                        Icons.work,
                        color: Colors.grey,
                      )),
                ),

                const SizedBox(
                  height: 10,
                ),
                // Job Description  --------------------------------------
                TextFormField(
                  controller: projectDescriptionController,
                  validator: (value) => Vvalidator.validateEmptyText(
                      'Project Description', value),
                  decoration: InputDecoration(
                      hintText: 'Project Description',
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                      prefixIcon: const Icon(
                        Icons.work_history_rounded,
                        color: Colors.grey,
                      )),
                ),

                const SizedBox(
                  height: 10,
                ),

                InkWell(
                  onTap: () async {
                    final List<String> items = [
                      "Java",
                      "Python",
                      "JavaScript",
                      "SQL",
                      "Spring Boot",
                      "React",
                      "Angular",
                      "Node.js",
                      "RESTful APIs",
                      "Microservices",
                      "Docker",
                      "Kubernetes",
                      "AWS",
                      "Azure",
                      "GCP",
                      "CI/CD",
                      "Jenkins",
                      "Git",
                      "Maven",
                      "Gradle",
                      "Agile Methodologies",
                      "Scrum",
                      "JIRA",
                      "Business Analysis",
                      "Requirement Gathering",
                      "UML",
                      "Wireframing",
                      "Data Modeling",
                      "Stakeholder Management",
                      "Risk Management",
                      "Project Planning",
                      "Team Leadership",
                      "Cross-functional Team Collaboration",
                      "Client Communication",
                      "DevOps",
                      "Unit Testing",
                      "Integration Testing",
                      "System Testing",
                      "Automation Testing",
                      "Selenium",
                      "Appium",
                      "Performance Testing",
                      "JMeter",
                      "Load Testing",
                      "Penetration Testing",
                      "API Testing",
                      "Postman",
                      "Swagger",
                      "Cloud Architecture",
                      "Solution Architecture",
                      "TOGAF",
                      "Enterprise Architecture",
                      "Event-driven Architecture",
                      "Service-oriented Architecture (SOA)",
                      "MVC",
                      "Design Patterns",
                      "Data Structures",
                      "Algorithms",
                      "Object-oriented Programming (OOP)",
                      "Functional Programming",
                      "NoSQL Databases",
                      "MongoDB",
                      "Cassandra",
                      "Redis",
                      "GraphQL",
                      "REST",
                      "JSON",
                      "XML",
                      "HTML5",
                      "CSS3",
                      "Bootstrap",
                      "SASS",
                      "TypeScript",
                      "Version Control",
                      "Linux",
                      "Shell Scripting",
                      "Bash",
                      "Powershell",
                      "Network Security",
                      "OAuth2",
                      "JWT",
                      "SSO",
                      "SSL/TLS",
                      "Encryption",
                      "Data Privacy",
                      "GDPR Compliance",
                      "Data Analysis",
                      "Big Data",
                      "Hadoop",
                      "Spark",
                      "Data Warehousing",
                      "ETL",
                      "Data Visualization",
                      "Tableau",
                      "Power BI",
                      "Machine Learning",
                      "Deep Learning",
                      "TensorFlow",
                      "Keras",
                      "Scikit-Learn",
                      "Natural Language Processing (NLP)",
                      "Computer Vision",
                      "AI/ML Model Deployment",
                      "Data Science",
                      "Time Management",
                      "Problem-solving",
                      "Analytical Thinking",
                      "Critical Thinking",
                      "Collaboration",
                      "Effective Communication",
                      "Negotiation",
                      "Conflict Resolution",
                      "Change Management",
                      "Customer Relationship Management (CRM)",
                      "ERP Systems",
                      "SAP",
                      "Oracle",
                      "SQL Server",
                      "MySQL",
                      "PostgreSQL",
                      "SQLite",
                      "PL/SQL",
                      "Data Governance",
                      "Data Quality Management",
                      "Technical Documentation",
                      "User Training",
                      "Mentoring",
                      "Coaching",
                      "Cybersecurity",
                      "Incident Response",
                      "Disaster Recovery",
                      "Business Continuity Planning",
                      "Service Management",
                      "ITIL",
                      "System Administration",
                      "Network Administration",
                      "Cloud Security",
                      "Azure DevOps",
                      "AWS Lambda",
                      "Serverless Architecture",
                      "Event Sourcing",
                      "Apache Kafka",
                      "RabbitMQ",
                      "Distributed Systems",
                      "Containerization",
                      "Server Management",
                      "Mobile App Development",
                      "Android",
                      "iOS",
                      "Swift",
                      "Kotlin",
                      "React Native",
                      "Flutter",
                      "Progressive Web Apps (PWA)",
                      "Backend Development",
                      "Frontend Development",
                      "Middleware",
                      "Graph Databases",
                      "Neo4j",
                      "ElasticSearch",
                      "Log Management",
                      "Monitoring and Logging",
                      "Grafana",
                      "Prometheus",
                      "Data Security",
                      "API Management",
                      "WebSockets",
                      "Cross-Browser Compatibility",
                      "Responsive Design",
                      "Accessibility (WCAG)",
                      "Code Review",
                      "Refactoring",
                      "Clean Code",
                      "SOLID Principles",
                      "Test-Driven Development (TDD)",
                      "Behavior-Driven Development (BDD)",
                      "Continuous Integration",
                      "Continuous Deployment",
                      "Infrastructure as Code (IaC)",
                      "Terraform",
                      "Ansible",
                      "Chef",
                      "Puppet",
                      "CloudFormation",
                      "Salesforce",
                      "CRM Systems",
                      "Help Desk Management",
                      "IT Support",
                      "Quality Management",
                      "ISO Standards",
                      "System Integration",
                      "API Integration",
                      "Software Architecture",
                      "Scalability",
                      "Load Balancing",
                      "High Availability",
                      "Concurrency",
                      "Multithreading",
                      "Message Queues",
                      "API Design",
                      "Web Development",
                      "MVC Frameworks",
                      "Hybrid Mobile Development",
                      "Agile Coaching",
                      "Business Process Management (BPM)",
                    ];

                    final List<String> results = await showDialog(
                      context: context,
                      builder: (BuildContext context) {
                        return MultySelect(
                          items: items,
                        );
                      },
                    );

                    ref
                        .watch(profileCreationStateNotifierProvider.notifier)
                        .setSkillsToList(results);

                    print('SKill List :::$results');

                    // useState();
                  },
                  child: Container(
                    padding: EdgeInsets.all(4),
                    height: 55,
                    decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey, width: 2),
                        borderRadius: BorderRadius.circular(10)),
                    child: const Row(
                      children: [
                        SizedBox(
                          width: 10,
                        ),
                        Icon(
                          Icons.tips_and_updates,
                          color: Colors.grey,
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Text("SKiLL"),
                      ],
                    ),
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),

                Wrap(
                  children: ref
                      .watch(profileCreationStateNotifierProvider
                          .select((value) => value.results))
                      .map((e) => Container(
                            decoration: BoxDecoration(
                                border:
                                    Border.all(color: Colors.grey, width: 2),
                                borderRadius: BorderRadius.circular(10)),
                            margin: EdgeInsets.symmetric(
                              horizontal: 5,
                              vertical: 3,
                            ),
                            padding: EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 5,
                            ),
                            child: Text(e),
                          ))
                      .toList(),
                ),

                const SizedBox(
                  height: 40,
                ),

                InkWell(
                  onTap: () {
                    FocusScope.of(context).unfocus();

                    ref
                        .read(profileCreationStateNotifierProvider.notifier)
                        .addNewProjects(
                          projectDescription: projectDescriptionController.text,
                          projectName: projectNameController.text,
                          userProfileID: userProfileId,
                        );
                  },
                  child: Container(
                    height: 54,
                    width: 154,
                    decoration: const BoxDecoration(
                        color: JColors.splashBackgroundColor,
                        borderRadius: BorderRadius.all(Radius.circular(10))),
                    child: const Center(
                      child: Text(
                        '+ Add Project',
                        style: TextStyle(color: Colors.white, fontSize: 16),
                      ),
                    ),
                  ),
                ),

                const SizedBox(
                  height: 10,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
