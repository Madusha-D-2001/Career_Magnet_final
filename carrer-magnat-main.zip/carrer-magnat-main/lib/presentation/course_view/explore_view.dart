import 'package:carrermagnet/utils/constants/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_overlay_loader/flutter_overlay_loader.dart';
import 'package:webview_flutter/webview_flutter.dart';

class ExploreCourseWebView extends StatefulWidget {
  ExploreCourseWebView({
    super.key,
    required this.courseLink,
  });

  final String courseLink;

  @override
  State<ExploreCourseWebView> createState() => _ExploreCourseWebViewState();
}

class _ExploreCourseWebViewState extends State<ExploreCourseWebView> {
  late WebViewController controller;

  @override
  void initState() {
    controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0x00000000))
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (int progress) {
            if (progress < 100) {
              Loader.show(context,
                  progressIndicator: CircularProgressIndicator());
            } else {
              Loader.hide();
            }
          },
          onPageStarted: (String url) {},
          onPageFinished: (String url) {},
          onWebResourceError: (WebResourceError error) {},
          onNavigationRequest: (NavigationRequest request) {
            return NavigationDecision.navigate;
          },
          onHttpAuthRequest: (request) {},
          onUrlChange: (change) {},
        ),
      )
      ..loadRequest(Uri.parse(widget.courseLink));
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      appBar: AppBar(
        leading: const Icon(
          Icons.arrow_back,
          color: Colors.white,
        ),
        backgroundColor: JColors.splashBackgroundColor,
        title: const Text(
          'Courses',
          style: TextStyle(color: Colors.white),
        ),
      ),
      body: WebViewWidget(
        controller: controller,
      ),
    ));
  }
}
