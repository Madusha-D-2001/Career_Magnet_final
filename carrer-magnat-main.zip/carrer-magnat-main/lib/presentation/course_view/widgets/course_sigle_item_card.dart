import 'package:carrermagnet/presentation/course_view/explore_view.dart';
import 'package:carrermagnet/utils/constants/colors.dart';
import 'package:flutter/material.dart';

class CourseSingleItemCard extends StatefulWidget {
  const CourseSingleItemCard({
    super.key,
    required this.h,
    required this.link,
    required this.title,
  });

  final double h;
  final String link;
  final String title;

  @override
  State<CourseSingleItemCard> createState() => _CourseSingleItemCardState();
}

class _CourseSingleItemCardState extends State<CourseSingleItemCard> {
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(10),
      height: widget.h * 0.2,
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3), // Shadow color
            spreadRadius: 2, // Spread radius
            blurRadius: 5, // Blur radius
            offset: const Offset(0, 3), // Shadow position
          ),
        ],
      ),
      child: InkWell(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => ExploreCourseWebView(
                      courseLink: widget.link,
                    )),
          );
        },
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          widget.title,
                          style: const TextStyle(
                            color: JColors.splashBackgroundColor,
                            fontWeight: FontWeight.bold,
                            fontSize: 17,
                          ),
                          maxLines: 4,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  const Row(
                    children: [
                      Text(
                        'Time Duration',
                        style: TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                            fontSize: 15),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  const Row(
                    children: [
                      Text(
                        ' 5h',
                        style: TextStyle(
                            color: Colors.grey,
                            fontWeight: FontWeight.bold,
                            fontSize: 13),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Icon(Icons.watch_later_outlined),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void launchWebView(String url) {
    // Navigator.push(
    //   context,
    //   MaterialPageRoute(
    //       builder: (context) => ExploreCourseWebView(
    //             content: url,
    //           )),
    // );
  }
}
