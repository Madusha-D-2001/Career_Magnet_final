import 'package:carrermagnet/presentation/course_view/course.dart';
import 'package:carrermagnet/presentation/course_view/widgets/course_sigle_item_card.dart';
import 'package:carrermagnet/utils/constants/colors.dart';
import 'package:flutter/material.dart';

class CourseView extends StatelessWidget {
  CourseView({super.key});

  final courseList = [
    Courses(
      title: 'Introduction to DevOps by GreatLearning',
      link:
          'https://www.mygreatlearning.com/academy/learn-for-free/courses/introduction-to-devops1',
    ),
    Courses(
      title: 'Free Online DevOps Courses by Alison',
      link: 'https://alison.com/tag/devops',
    ),
    Courses(
      title: 'Android Development Trainings-Mobile App Development Courses',
      link:
          'https://developer.android.com/courses?gad_source=1&gclid=Cj0KCQjw3ZayBhDRARIsAPWzx8oX8uklRapspM8py519N1m8TkBX1_rl8KEocoYqgbjC9oLi0r0PYAsaAljDEALw_wcB&gclsrc=aw.ds',
    ),
    Courses(
      title: 'Mobile app development courses in Coursera',
      link: 'https://www.coursera.org/courses?query=mobile%20app%20development',
    ),
    Courses(
      title: 'Software Development courses in Coursera',
      link:
          'https://www.coursera.org/browse/computer-science/software-development',
    ),
    Courses(
      title: 'Software Development courses in Simplilearn',
      link: 'https://www.simplilearn.com/mobile-and-software-development',
    ),
    Courses(
      title: 'UI/UX Design Specialization in Coursera',
      link: 'https://www.coursera.org/specializations/ui-ux-design',
    ),
    Courses(
      title: 'Google UX Design Certificate',
      link: 'https://grow.google/certificates/ux-design/',
    ),
    Courses(
      title: 'Learn Essential Quality Assurance skills courses in Coursera',
      link: 'https://www.coursera.org/courses?query=quality%20assurance',
    ),
    Courses(
      title: 'Quality Assurance courses in Udemy',
      link: 'https://www.udemy.com/topic/quality-assurance/',
    ),
    Courses(
      title: 'Business Analysis Fundamentals by Alison',
      link:
          'https://alison.com/course/business-analysis-fundamentals?utm_source=google&utm_medium=cpc&utm_campaign=Performance-Max_Tier-4_Resume-Builder&gad_source=1&gclid=Cj0KCQjw3ZayBhDRARIsAPWzx8r8and7IQ6DdT2NsLROM2N394P_bRAiNOsNse0hv0VDNK-ahCyme9UaAve-EALw_wcB',
    ),
    Courses(
      title: 'Postgraduate Program in Business Analysis in Simplilearn',
      link:
          'https://www.simplilearn.com/pgp-business-analysis-certification-training-course',
    ),
    Courses(
      title: 'Free Cyber Security Courses with Alison',
      link:
          'https://alison.com/tag/cyber-security?utm_adgroup=Hub_Cyber-Security&utm_source=google&utm_medium=cpc&utm_campaign=Performance-Max_Tier-4_Wellbeing-Assessment&gad_source=1&gclid=Cj0KCQjw3ZayBhDRARIsAPWzx8oXSk0vmG3C1Ush81K8dqPdKyD3LpxIDlOdDl9ce5TmFWwETEHxtRkaAoutEALw_wcB',
    ),
    Courses(
      title: 'The Complete Cyber Security Course with Udemy',
      link:
          'https://www.udemy.com/course/the-complete-internet-security-privacy-course-volume-1/?utm_source=adwords&utm_medium=udemyads&utm_campaign=CyberSecurity_v.PROF_la.EN_cc.ROW&campaigntype=Search&portfolio=ROW-English&language=EN&product=Course&test=&audience=Keyword&topic=&priority=&utm_content=deal4584&utm_term=_._ag_120822691621_._ad_535699942312_._kw_cyber+security+courses_._de_c_._dm__._pl__._ti_kwd-608870059_._li_9069431_._pd__._&matchtype=b&gad_source=1&gclid=Cj0KCQjw3ZayBhDRARIsAPWzx8ocjYMFwbGkrCr0XuOddILDkfUPwU-cUb9D5YDf109yy7cF-rznT0waAtqMEALw_wcB&couponCode=LEADERSALE24A',
    ),
    Courses(
      title: 'Relational Database Administration Course in Coursera',
      link: 'https://www.coursera.org/learn/relational-database-administration',
    ),
    Courses(
      title: 'Database Administration Courses in Alison',
      link:
          'https://alison.com/careers/it/database-administrator?utm_adgroup=Career-Guide_Database-Administrator&utm_source=google&utm_medium=cpc&utm_campaign=Performance-Max_Tier-4_Wellbeing-Assessment&gad_source=1&gclid=Cj0KCQjw3ZayBhDRARIsAPWzx8r7bcyaSMJslEpQEkSg3DVg4ePFvTcnobIyrlrspaMS47RoRla_rM8aAkZzEALw_wcB#google_vignette',
    ),
    Courses(
      title:
          'Machine Learning A-Z: AI, Python & R + ChatGPT Prize [2024] Course with Udemy',
      link:
          'https://www.udemy.com/course/machinelearning/?utm_source=adwords&utm_medium=udemyads&utm_campaign=MachineLearning_v.PROF_la.EN_cc.ROW_ti.6594&campaigntype=Search&portfolio=ROW-English&language=EN&product=Course&test=&audience=DSA&topic=&priority=&utm_content=deal4584&utm_term=_._ag_85479006634_._ad_535397281335_._kw__._de_c_._dm__._pl__._ti_dsa-774930030129_._li_9069431_._pd__._&matchtype=&gad_source=1&gclid=Cj0KCQjw3ZayBhDRARIsAPWzx8onsFLVSyPhnXjyEENeNB5_VN9PSksOcPY-706a1WBYUxMD2HS3oqAaAuUSEALw_wcB&couponCode=LEADERSALE24A',
    ),
    Courses(
      title: 'AI Courses and Specializations with DeepLearning.AI',
      link: 'https://www.deeplearning.ai/',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    var h = MediaQuery.of(context).size.height;
    var w = MediaQuery.of(context).size.width;

    return Scaffold(
      appBar: AppBar(
        leading: const Icon(
          Icons.arrow_back,
          color: Colors.white,
        ),
        title: const Text(
          'Courses',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: JColors.splashBackgroundColor,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 20),
          child: Column(
            children: [
              CourseSingleItemCard(
                h: h,
                link: courseList[0].link,
                title: courseList[0].title,
              ),
              CourseSingleItemCard(
                h: h,
                link: courseList[1].link,
                title: courseList[1].title,
              ),
              CourseSingleItemCard(
                h: h,
                link: courseList[2].link,
                title: courseList[2].title,
              ),
              CourseSingleItemCard(
                h: h,
                link: courseList[3].link,
                title: courseList[3].title,
              ),
              CourseSingleItemCard(
                h: h,
                link: courseList[4].link,
                title: courseList[4].title,
              ),
              CourseSingleItemCard(
                h: h,
                link: courseList[5].link,
                title: courseList[5].title,
              ),
              CourseSingleItemCard(
                h: h,
                link: courseList[6].link,
                title: courseList[6].title,
              ),
              CourseSingleItemCard(
                h: h,
                link: courseList[7].link,
                title: courseList[7].title,
              ),
              CourseSingleItemCard(
                h: h,
                link: courseList[8].link,
                title: courseList[8].title,
              ),
              CourseSingleItemCard(
                h: h,
                link: courseList[9].link,
                title: courseList[9].title,
              ),
              CourseSingleItemCard(
                h: h,
                link: courseList[10].link,
                title: courseList[10].title,
              ),
              CourseSingleItemCard(
                h: h,
                link: courseList[11].link,
                title: courseList[11].title,
              ),
              CourseSingleItemCard(
                h: h,
                link: courseList[12].link,
                title: courseList[12].title,
              ),
              CourseSingleItemCard(
                h: h,
                link: courseList[13].link,
                title: courseList[13].title,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
