class Courses {
  final String title;
  final String link;
  Courses({
    required this.title,
    required this.link,
  });
}
