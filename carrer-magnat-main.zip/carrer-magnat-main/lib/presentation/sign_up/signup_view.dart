import 'package:carrermagnet/application/app_state/app_state_notifier_provider.dart';
import 'package:carrermagnet/application/sign_up/signup_state_notifier_provider.dart';
import 'package:carrermagnet/domain/core/failure.dart';
import 'package:carrermagnet/domain/sign_up/sign_up_response.dart';
import 'package:carrermagnet/presentation/alert/alert_utils.dart';
import 'package:carrermagnet/presentation/core/widgets/common_loading_indicator.dart';
import 'package:carrermagnet/routes/routes_name.dart';
import 'package:carrermagnet/utils/app_utils.dart';
import 'package:carrermagnet/utils/constants/colors.dart';
import 'package:carrermagnet/utils/validators/validators.dart';
import 'package:dartz/dartz.dart';
import 'package:flutter/material.dart';
import 'package:flutter_overlay_loader/flutter_overlay_loader.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../domain/sign_up/user_sign_up_response.dart';

class SignUpView extends HookConsumerWidget {
  SignUpView({super.key});

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  TextEditingController firstNameController = TextEditingController();
  TextEditingController lastNameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController phoneNumberController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController confirmPasswordController = TextEditingController();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    ref.listen<Option<Failure>>(
        signUpStateNotifierProvider.select((value) => value.responseFailure),
        (_, value) {
      value.fold(() {}, (failure) {
        AlertUtils.showErrorDialog(
            context: context, message: failure.toString());
      });
    });

    ref.listen<bool>(
      signUpStateNotifierProvider.select((value) => value.isLoading),
      (_, value) {
        if (value) {
          Loader.show(context,
              progressIndicator: const CommonLoadingIndicator());
        } else {
          Loader.hide();
        }
      },
    );

    // ref.listen<Option<SignUpResponse>>(
    //     signUpStateNotifierProvider.select((value) => value.signUpResponse),
    //     (_, value) {
    //   value.fold(() {}, (response) {
    //     Get.offAll(() => NavigationView());
    //   });
    // });

    ref.listen<Option<UserSignUpResponse>>(
        signUpStateNotifierProvider.select((value) => value.userSignUpResponse),
        (_, value) {
      value.fold(() {}, (response) {
        ref
            .read(appStateNotifierProvider.notifier)
            .setUserId(response.data.user_id);

        ref
            .read(appStateNotifierProvider.notifier)
            .setAcessToken(response.data.access_token);

        ref
            .read(appStateNotifierProvider.notifier)
            .setRefreshToken(response.data.refresh_token);

        ref
            .read(appStateNotifierProvider.notifier)
            .setUserRole(response.data.role);

        AppUtils.tempToken = response.data.access_token;

        AlertUtils.showSuccessDialog(
          context: context,
          title: 'Your account Created',
          message: 'Please Complete Your Profile',
          onActionPressed: (context) {
            Navigator.of(context).pushNamedAndRemoveUntil(
              RoutesName.profileCreateAndEditView,
              (Route<dynamic> route) => false,
              arguments: {
                'email': emailController.text,
              },
            );
          },
        );

        //Get.offAll(() => NavigationMenu());
      });
    });

    // var h = MediaQuery.of(context).size.height;
    // var w = MediaQuery.of(context).size.width;

    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SingleChildScrollView(
          child: Column(
            children: [
              // header part ------------------------------

              Container(
                width: 1000.w,
                color: Colors.white,
                child: SizedBox(
                  height: 110.h,
                  child: Stack(
                    children: [
                      Positioned(
                        top: -30,
                        right: -60,
                        child: Container(
                          width: 150,
                          height: 150,
                          padding: const EdgeInsets.all(0),
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(100),
                              color: Colors.pink.withOpacity(0.1)),
                          // child: child,
                        ),
                      ),
                      Positioned(
                        top: 130,
                        right: 310,
                        child: Container(
                          width: 150,
                          height: 150,
                          padding: const EdgeInsets.all(0),
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(100),
                              color: Colors.pink.withOpacity(0.1)),
                          // child: child,
                        ),
                      ),
                      Positioned(
                        top: 130,
                        left: 1000.w / 5,
                        child: Container(
                          child: Image.asset(
                            "assets/images/careermagnet_blue_logo.png",
                            scale: 3,
                          ),
                          // child: child,
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              const Text(
                'Create your account',
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.black),
              ),

              const SizedBox(
                height: 20,
              ),

              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 30),
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      // first Name field ---------------------------

                      TextFormField(
                        controller: firstNameController,
                        validator: (value) =>
                            Vvalidator.validateEmptyText('First Name', value),
                        decoration: InputDecoration(
                            hintText: 'First Name',
                            filled: true,
                            fillColor: Colors.white,
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10)),
                            prefixIcon: const Icon(
                              Icons.person,
                              color: Colors.grey,
                            )),
                      ),

                      const SizedBox(
                        height: 20,
                      ),

                      // last Name field -----------------------------

                      TextFormField(
                        controller: lastNameController,
                        validator: (value) =>
                            Vvalidator.validateEmptyText('Last Name', value),
                        decoration: InputDecoration(
                            hintText: 'Last Name',
                            filled: true,
                            fillColor: Colors.white,
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10)),
                            prefixIcon: const Icon(
                              Icons.person,
                              color: Colors.grey,
                            )),
                      ),

                      const SizedBox(
                        height: 20,
                      ),

                      /// -- Email Text Field ----------------------------

                      TextFormField(
                        controller: emailController,
                        validator: (value) => Vvalidator.VvalideEmail(value),
                        decoration: InputDecoration(
                            hintText: 'Email',
                            filled: true,
                            fillColor: Colors.white,
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10)),
                            prefixIcon: const Icon(
                              Icons.email,
                              color: Colors.grey,
                            )),
                      ),

                      const SizedBox(
                        height: 20,
                      ),

                      /// -- phone Number TextField ---------------------

                      TextFormField(
                        controller: phoneNumberController,
                        validator: (value) =>
                            Vvalidator.validatePhoneNumber(value),
                        decoration: InputDecoration(
                            hintText: 'Contact Number',
                            filled: true,
                            fillColor: Colors.white,
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10)),
                            prefixIcon: const Icon(
                              Icons.phone,
                              color: Colors.grey,
                            )),
                      ),

                      const SizedBox(
                        height: 20,
                      ),

                      // password Text field ----------------------------

                      TextFormField(
                        validator: (value) =>
                            Vvalidator.validatePassword(value),
                        controller: passwordController,
                        //   obscureText: controller.hidePassowrd.value,
                        decoration: InputDecoration(
                            hintText: 'Password',
                            filled: true,
                            fillColor: Colors.white,
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10)),
                            prefixIcon: const Icon(
                              Icons.lock,
                              color: Colors.grey,
                            )),
                      ),

                      const SizedBox(
                        height: 20,
                      ),

                      // confirm Text Field -------------------------------

                      TextFormField(
                        validator: (value) =>
                            Vvalidator.validatePassword(value),
                        controller: confirmPasswordController,
                        decoration: InputDecoration(
                            hintText: 'Confirm Password',
                            filled: true,
                            fillColor: Colors.white,
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10)),
                            prefixIcon: const Icon(
                              Icons.lock,
                              color: Colors.grey,
                            )),
                      ),
                      const SizedBox(
                        height: 20,
                      ),

                      // Create Account Button ----------------------

                      InkWell(
                        onTap: () {
                          FocusScope.of(context).unfocus();

                          if (_formKey.currentState!.validate()) {
                            ref
                                .watch(signUpStateNotifierProvider.notifier)
                                .setValues(
                                  contact: phoneNumberController.text,
                                  first_name: firstNameController.text,
                                  last_name: lastNameController.text,
                                  email: emailController.text,
                                  password: passwordController.text,
                                );

                            ref
                                .read(signUpStateNotifierProvider.notifier)
                                .signUp();
                          }
                        },
                        child: Container(
                          height: 44,
                          width: 200,
                          decoration: const BoxDecoration(
                              color: JColors.splashBackgroundColor,
                              borderRadius:
                                  BorderRadius.all(Radius.circular(20))),
                          child: const Center(
                              child: Text(
                            'Create Account',
                            style: TextStyle(color: Colors.white, fontSize: 16),
                          )),
                        ),
                      ),

                      const SizedBox(
                        height: 30,
                      ),

                      InkWell(
                        onTap: () {
                          Navigator.pushNamedAndRemoveUntil(
                            context,
                            RoutesName
                                .loginView, // The name of the route you want to navigate to
                            (Route<dynamic> route) =>
                                false, // Remove all previous routes
                          );
                        },
                        child: const Text(
                          'Alredy  have an account? Sign in',
                          style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.normal,
                              color: Colors.black),
                        ),
                      ),

                      const SizedBox(
                        height: 20,
                      ),
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
