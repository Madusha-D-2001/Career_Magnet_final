import 'package:carrermagnet/application/navigation/navigation_state_notifier_provider.dart';
import 'package:carrermagnet/application/recruiter_navigation/recruiter_navigation_state_notifier_provider.dart';
import 'package:carrermagnet/presentation/recruiter_view/add_hiring_announcement_view.dart';
import 'package:carrermagnet/presentation/recruiter_view/all_add_job_post_view.dart';
import 'package:carrermagnet/utils/constants/colors.dart';
import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:iconsax/iconsax.dart';
import 'package:flutter_hooks/flutter_hooks.dart';

class RecruiterNavigationView extends HookConsumerWidget {
  RecruiterNavigationView({super.key});

  int selectedItem = 0;

  final List<Widget> screens = <Widget>[
    const AllAddJobPostView(),
    Center(
      child: Text('Not Yet'),
    ),
  ];

  void onItemTap(int index) {
    selectedItem = index;
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    useEffect(() {
      // Using Future.microtask to ensure these operations happen after the build
      Future.microtask(() {});

      return null;
    }, []);

    var navIndex = ref.watch(recruiterNavigationStateNotifierProvider);

    return Scaffold(
      backgroundColor: Colors.white,
      bottomNavigationBar: Container(
        margin: EdgeInsets.symmetric(horizontal: 10),
        alignment: Alignment.center,

        height: 65,
        //  margin: EdgeInsets.all(10),
        decoration: const BoxDecoration(
          color: JColors.splashBackgroundColor,
          borderRadius: BorderRadius.all(
            Radius.circular(30),
          ),
        ),
        child: BottomNavigationBar(
          enableFeedback: false,
          onTap: (value) {
            ref
                .watch(recruiterNavigationStateNotifierProvider.notifier)
                .indexChange(value);
          },
          backgroundColor: Colors.transparent,
          elevation: 0,
          currentIndex: navIndex.index,
          type: BottomNavigationBarType.fixed,
          items: const [
            BottomNavigationBarItem(
              icon: Icon(
                Icons.bookmark,
                size: 30,
                color: Colors.white,
              ),
              label: '',
            ),
            BottomNavigationBarItem(
              icon: Icon(
                Iconsax.user,
                color: Colors.white,
              ),
              label: '',
            ),
          ],
        ),
      ),
      body: Center(child: screens[navIndex.index]),
    );
  }
}
