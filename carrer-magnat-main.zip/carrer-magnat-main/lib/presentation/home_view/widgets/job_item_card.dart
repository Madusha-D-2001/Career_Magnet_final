import 'package:carrermagnet/utils/constants/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../domain/get_all_job/get_all_job_data.dart';
import '../../../routes/routes_name.dart';

class JobItemCard extends StatelessWidget {
  JobItemCard({
    super.key,
    required this.getAllJobData,
  });

  GetAllJobData getAllJobData;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        Navigator.popAndPushNamed(
          context,
          RoutesName.jobDetailView,
          arguments: {
            'searchJobsResponseData': getAllJobData,
          },
        );
      },
      child: Container(
        margin: EdgeInsets.all(10),
        height: 190.h,
        width: 260.w,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.3), // Shadow color
              spreadRadius: 2, // Spread radius
              blurRadius: 5, // Blur radius
              offset: const Offset(0, 3), // Shadow position
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
          child: Column(
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        getAllJobData.jobType,
                        style: TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                            fontSize: 15),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      Text(
                        getAllJobData.companyName,
                        style: TextStyle(
                            color: Colors.grey,
                            fontWeight: FontWeight.bold,
                            fontSize: 13),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                  Spacer(
                    flex: 1,
                  ),
                  Icon(
                    Icons.bookmark,
                    color: JColors.splashBackgroundColor,
                  )
                ],
              ),
              const SizedBox(
                height: 10,
              ),
              Row(
                children: [
                  Icon(
                    Icons.location_on,
                    color: JColors.splashBackgroundColor,
                  ),
                  SizedBox(
                    width: 10,
                  ),
                  Text(
                    getAllJobData.location,
                    style: TextStyle(
                        color: Colors.grey,
                        fontWeight: FontWeight.bold,
                        fontSize: 13),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
              // posted Date
              Row(
                children: [
                  Icon(
                    Icons.calendar_month,
                    color: JColors.splashBackgroundColor,
                  ),
                  SizedBox(
                    width: 10,
                  ),
                  Text(
                    getAllJobData.postedDate.substring(0, 10),
                    style: TextStyle(
                        color: Colors.grey,
                        fontWeight: FontWeight.bold,
                        fontSize: 13),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
              const SizedBox(
                height: 16,
              ),
              Row(
                children: [
                  Expanded(
                    child: Container(
                      height: 26,
                      width: 90,
                      decoration: const BoxDecoration(
                          color: Colors.grey,
                          borderRadius: BorderRadius.all(Radius.circular(5))),
                      child: const Center(child: Text('Full-Time')),
                    ),
                  ),
                  const SizedBox(
                    width: 6,
                  ),
                  Expanded(
                    child: Container(
                      height: 26,
                      width: 90,
                      decoration: const BoxDecoration(
                          color: Colors.grey,
                          borderRadius: BorderRadius.all(Radius.circular(5))),
                      child: const Center(child: Text('Remote')),
                    ),
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
