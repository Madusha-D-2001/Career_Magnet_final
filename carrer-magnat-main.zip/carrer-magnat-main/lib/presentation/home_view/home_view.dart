import 'package:carrermagnet/application/app_state/app_state_notifier_provider.dart';
import 'package:carrermagnet/application/profile_creation/profile_creation_state_notifier_provider.dart';
import 'package:carrermagnet/infrastructure/search_jobs/search_jobs_response_data_dto.dart';
import 'package:carrermagnet/presentation/home_view/widgets/job_item_card.dart';
import 'package:carrermagnet/presentation/home_view/widgets/section_heading.dart';
import 'package:carrermagnet/utils/constants/colors.dart';
import 'package:carrermagnet/utils/sizes.dart';
import 'package:carrermagnet/utils/validators/validators.dart';
import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:kt_dart/kt.dart';

import '../../domain/search_jobs/search_jobs_response_data.dart';
import '../../routes/routes_name.dart';
import '../alert/alert_utils.dart';
import 'widgets/SearchResultWidget.dart';

class HomeView extends HookConsumerWidget {
  HomeView({super.key});

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  TextEditingController companyNameController = TextEditingController();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    useEffect(() {
      Future.delayed(Duration.zero, () {
        // Get Login Email ------------------------------------------------------

        final profileEmail =
            ref.watch(appStateNotifierProvider.notifier).getProfileEmail();

        final profileEmail1 = ref.watch(appStateNotifierProvider.select(
          (value) => value.profileEmail,
        ));

        print('loginSignUpEmail ::::: $profileEmail1');

        // Get User Detail -------------------------------------------------------
        // ref
        //     .watch(profileCreationStateNotifierProvider.notifier)
        //     .getProfileDetail(profileEmail);

        // ref.watch(appStateNotifierProvider.notifier).getUserDetails();

        ref.watch(profileCreationStateNotifierProvider.notifier).getAllJobs();
        ref
            .watch(profileCreationStateNotifierProvider.notifier)
            .getAllSuggestedJobs(email: profileEmail1);
      });
      return;
    }, []);

    const List<String> list = <String>[
      'Colombo',
      'Nugegoda',
      'Wattala',
      'kotte'
    ];

    final isCickFilter = ref.watch(profileCreationStateNotifierProvider.select(
      (value) => value.isClickFilter,
    ));

    // get All Jobs Loading ---

    final getAllJobsLoading =
        ref.watch(profileCreationStateNotifierProvider.select(
      (value) => value.isGetAllJobsLoading,
    ));

    final allJobsList = ref.watch(profileCreationStateNotifierProvider.select(
      (value) => value.getAllJobList,
    ));

    // get All Suggested Jobs --------------------------------------------------

    final getAllSuggestedJobList =
        ref.watch(profileCreationStateNotifierProvider.select(
      (value) => value.getAllSuggestedJobList,
    ));

    // search Job List ---

    final searchJobLoading =
        ref.watch(profileCreationStateNotifierProvider.select(
      (value) => value.isSearchJobLoading,
    ));

    final searchJobList = ref.watch(profileCreationStateNotifierProvider.select(
      (value) => value.searchJobList,
    ));

    List<String> jopTypes = [
      "Software Engineer (SE)",
      "Senior Software Engineer (SSE)",
      "Software Developer",
      "Full Stack Developer",
      "Front-end Developer",
      "Back-end Developer",
      "Web Developer",
      "Mobile App Developer",
      "DevOps Engineer",
      "Cloud Engineer",
      "Site Reliability Engineer (SRE)",
      "Database Administrator (DBA)",
      "System Administrator (SysAdmin)",
      "Network Administrator",
      "Quality Assurance (QA) Engineer",
      "Automation Test Engineer",
      "Performance Test Engineer",
      "Security Engineer",
      "Information Security Analyst",
      "Cybersecurity Specialist",
      "IT Support Specialist",
      "Help Desk Technician",
      "Technical Support Engineer",
      "Product Manager",
      "Project Manager (PM)",
      "Technical Project Manager",
      "Program Manager",
      "Business Analyst (BA)",
      "Systems Analyst",
      "Data Analyst",
      "Data Scientist",
      "Data Engineer",
      "Big Data Engineer",
      "Machine Learning Engineer",
      "AI Specialist",
      "NLP Engineer",
      "Computer Vision Engineer",
      "Data Architect",
      "Solutions Architect",
      "Cloud Architect",
      "Enterprise Architect",
      "Software Architect",
      "Application Architect",
      "Infrastructure Architect",
      "IT Manager",
      "IT Director",
      "Chief Technology Officer (CTO)",
      "Chief Information Officer (CIO)",
      "Tech Lead",
      "Engineering Manager",
      "UI/UX Designer",
      "Product Designer",
      "User Experience Researcher",
      "Graphic Designer",
      "Technical Writer",
      "Scrum Master",
      "Agile Coach",
      "Business Intelligence (BI) Developer",
      "BI Analyst",
      "Cloud Consultant",
      "IT Consultant",
      "Software Consultant",
      "Network Engineer",
      "System Engineer",
      "Support Engineer",
      "Release Manager",
      "Build Engineer",
      "Integration Engineer",
      "API Developer",
      "Embedded Software Engineer",
      "Firmware Engineer",
      "Mobile Application Manager",
      "IT Auditor",
      "Compliance Specialist",
      "ERP Consultant",
      "CRM Consultant",
      "IT Operations Manager",
      "IT Service Manager",
      "Technical Account Manager",
      "Customer Success Manager",
      "Digital Transformation Specialist",
      "Robotic Process Automation (RPA) Developer",
      "DevSecOps Engineer",
      "Penetration Tester",
      "Ethical Hacker",
      "Cloud Support Engineer",
      "Cloud Solutions Engineer",
      "Cloud DevOps Engineer",
      "Container Engineer",
      "Kubernetes Engineer",
      "Docker Engineer",
      "Artificial Intelligence Engineer",
      "Deep Learning Engineer",
      "Virtualization Engineer",
      "Augmented Reality (AR) Developer",
      "Virtual Reality (VR) Developer",
      "Blockchain Developer",
      "IoT Developer (Internet of Things)",
      "Smart Contract Developer",
      "Game Developer",
      "Video Game Designer",
      "Game Tester",
      "E-commerce Specialist",
      "Digital Marketing Specialist",
      "SEO Specialist",
      "Content Manager",
      "IT Infrastructure Engineer",
      "IT Operations Analyst",
      "IT Support Manager",
      "Application Support Analyst",
      "ERP Support Specialist",
      "IT Trainer",
      "Software Quality Analyst",
      "Data Visualization Specialist",
      "AI Research Scientist",
      "IT Risk Manager",
      "Cloud Platform Engineer",
      "Network Security Engineer",
      "Network Consultant",
      "Data Privacy Officer",
      "IT Governance Specialist",
      "Chief Data Officer (CDO)",
      "Full Stack Software Engineer",
      "Web Application Developer",
      "Backend Systems Developer",
      "Microservices Developer",
      "API Integration Specialist",
      "Functional Consultant",
      "Technical Consultant",
      "System Integration Specialist",
      "Configuration Manager",
      "Release Coordinator",
      "Version Control Specialist",
      "Embedded Systems Developer",
      "Field Service Engineer",
      "VoIP Engineer",
      "Cloud Migration Specialist",
      "IT Business Partner",
      "AI/ML Product Manager",
      "Platform Engineer",
      "IT Service Delivery Manager",
      "Enterprise Solutions Consultant",
      "Digital Product Manager"
    ];

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            backgroundColor: JColors.splashBackgroundColor,
            expandedHeight: 150.h,
            flexibleSpace: FlexibleSpaceBar(
              background: Stack(
                children: [
                  Positioned(
                    top: -150,
                    right: -250,
                    child: Container(
                      width: 400.w,
                      height: 400.h,
                      padding: const EdgeInsets.all(0),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(400),
                          color: Colors.white.withOpacity(0.1)),
                      // child: child,
                    ),
                  ),
                  Positioned(
                    top: 100,
                    right: -250,
                    child: Container(
                      width: 400.w,
                      height: 400.h,
                      padding: const EdgeInsets.all(0),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(400),
                        color: Colors.white.withOpacity(0.1),
                        // child: child,
                      ),
                    ),
                  ),
                  Form(
                    key: _formKey,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          height: 40.h,
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 10),
                          child: SizedBox(
                              child: Image.asset(
                            'assets/images/careermagnet.png',
                            scale: 2,
                          )),
                        ),
                        const SizedBox(
                          height: TSizes.spaceBtwItems * 1.2,
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 10),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Expanded(
                                flex: 5,
                                child: SizedBox(
                                  //padding: EdgeInsets.symmetric(horizontal: 20),
                                  width: 290,
                                  height: 50,
                                  child: TextFormField(
                                    validator: (value) =>
                                        Vvalidator.validateEmptyText(
                                            value, 'Search Company'),
                                    controller: companyNameController,
                                    decoration: InputDecoration(
                                      hintText: 'Search Company',
                                      filled: true,
                                      fillColor: Colors.white,
                                      border: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      prefixIcon: const Icon(
                                        Icons.search,
                                        color: Colors.grey,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              Expanded(
                                flex: 1,
                                child: InkWell(
                                  onTap: () {
                                    ref
                                        .read(
                                            profileCreationStateNotifierProvider
                                                .notifier)
                                        .isClickSearchButton(isCickFilter);

                                    ref
                                        .read(
                                            profileCreationStateNotifierProvider
                                                .notifier)
                                        .searchJobs();

                                    //      if (_formKey.currentState!.validate()) {

                                    // if (companyNameController.text.isEmpty) {
                                    //   print('enter search Company');
                                    //   AlertUtils.showErrorDialog(
                                    //     context: context,
                                    //     message: "Type Search Company",
                                    //   );
                                    // } else {

                                    //  }
                                  },
                                  child: Container(
                                    height: 45,
                                    width: 45,
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(7),
                                        color: Colors.yellow),
                                    child: Icon(
                                      isCickFilter ? Icons.close : Icons.search,
                                      size: 27,
                                      color: Colors.grey,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(
                          height: TSizes.spaceBtwItems * 1.2,
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),

          // filter part -------------------------------------------------------
          isCickFilter
              ? SliverList.list(children: [])
              : SliverList.list(
                  children: [
                    ExpansionTile(
                      onExpansionChanged: (value) {},
                      iconColor: JColors.splashBackgroundColor,
                      childrenPadding: EdgeInsets.all(10),
                      backgroundColor: Colors.transparent,
                      title: const Text(
                        'Click to Filter',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: JColors.splashBackgroundColor,
                          fontFamily: AutofillHints.addressCityAndState,
                        ),
                      ),
                      children: <Widget>[
                        SizedBox(
                          height: 10,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            // ignore: avoid_unnecessary_containers
                            DropdownButtonHideUnderline(
                              child: DropdownButton2<String>(
                                isExpanded: true,
                                hint: const Row(
                                  children: [
                                    Icon(
                                      Icons.list,
                                      size: 16,
                                      color: Colors.grey,
                                    ),
                                    SizedBox(
                                      width: 4,
                                    ),
                                    Expanded(
                                      child: Text(
                                        'Select Item',
                                        style: TextStyle(
                                          fontSize: 14,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.grey,
                                        ),
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ],
                                ),
                                items: jopTypes
                                    .map((String item) =>
                                        DropdownMenuItem<String>(
                                          value: item,
                                          child: Text(
                                            item,
                                            style: const TextStyle(
                                              fontSize: 14,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.black,
                                            ),
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ))
                                    .toList(),
                                value: ref.watch(
                                    profileCreationStateNotifierProvider.select(
                                  (value) => value.JobType,
                                )),
                                onChanged: (String? value) {
                                  ref
                                      .watch(
                                          profileCreationStateNotifierProvider
                                              .notifier)
                                      .setSearchJobType(JobType: value!);
                                },
                                buttonStyleData: ButtonStyleData(
                                  height: 50,
                                  width: 300.w,
                                  padding: const EdgeInsets.only(
                                      left: 14, right: 14),
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(14),
                                    border: Border.all(
                                      color: Colors.black26,
                                    ),
                                    color: Colors.white,
                                  ),
                                  elevation: 2,
                                ),
                                iconStyleData: const IconStyleData(
                                  icon: Icon(
                                    Icons.arrow_forward_ios_outlined,
                                  ),
                                  iconSize: 14,
                                  iconEnabledColor: Colors.black,
                                  iconDisabledColor: Colors.grey,
                                ),
                                dropdownStyleData: DropdownStyleData(
                                  maxHeight: 200,
                                  padding: EdgeInsets.symmetric(horizontal: 30),
                                  width: 900.w,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(14),
                                    color: Colors.white,
                                  ),
                                  offset: const Offset(-20, 0),
                                  scrollbarTheme: ScrollbarThemeData(
                                    radius: const Radius.circular(40),
                                    thickness:
                                        MaterialStateProperty.all<double>(6),
                                    thumbVisibility:
                                        MaterialStateProperty.all<bool>(true),
                                  ),
                                ),
                                menuItemStyleData: const MenuItemStyleData(
                                  height: 40,
                                  padding: EdgeInsets.only(left: 14, right: 14),
                                ),
                              ),
                            ),

                            const SizedBox(
                              width: TSizes.spaceBtwItems,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),

          !isCickFilter
              ? SliverList.list(children: [
                  const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 20),
                    child: TSectionHeading(
                      title: 'Suggested Jobs',
                      showActionButton: true,
                      textColor: JColors.splashBackgroundColor,
                    ),
                  ),
                ])
              : SliverList.list(children: []),

          // search Result -----------------------------------------------------

          isCickFilter
              ? searchJobList.size == 0
                  ? SearchResultWidget()
                  : SliverList.builder(
                      itemBuilder: (context, index) {
                        final searchJobData = searchJobList[index];
                        return InkWell(
                          onTap: () {
                            Navigator.popAndPushNamed(
                              context,
                              RoutesName.jobDetailView,
                              arguments: {
                                'searchJobsResponseData': searchJobList[index],
                              },
                            );
                          },
                          child: Container(
                            margin: EdgeInsets.all(10),
                            //  height: 190,
                            width: 260.w,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black
                                      .withOpacity(0.3), // Shadow color
                                  spreadRadius: 2, // Spread radius
                                  blurRadius: 5, // Blur radius
                                  offset: const Offset(0, 3), // Shadow position
                                ),
                              ],
                            ),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 10),
                              child: Column(
                                children: [
                                  Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                      Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Text(
                                            searchJobData.jobType,
                                            style: const TextStyle(
                                                color: Colors.black,
                                                fontWeight: FontWeight.bold,
                                                fontSize: 15),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                          Text(
                                            searchJobData.companyName,
                                            style: TextStyle(
                                                color: Colors.grey,
                                                fontWeight: FontWeight.bold,
                                                fontSize: 13),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ],
                                      ),
                                      Spacer(
                                        flex: 1,
                                      ),
                                      Icon(
                                        Icons.bookmark,
                                        color: JColors.splashBackgroundColor,
                                      )
                                    ],
                                  ),
                                  SizedBox(
                                    height: 20.h,
                                  ),
                                  Row(
                                    children: [
                                      Icon(
                                        Icons.location_on,
                                        color: JColors.splashBackgroundColor,
                                      ),
                                      SizedBox(
                                        width: 10,
                                      ),
                                      Text(
                                        searchJobData.location,
                                        style: TextStyle(
                                            color: Colors.grey,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 13),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ],
                                  ),
                                  const SizedBox(
                                    height: 16,
                                  ),
                                  Row(
                                    children: [
                                      Expanded(
                                        child: Container(
                                          height: 26,
                                          width: 90,
                                          decoration: const BoxDecoration(
                                              color: Colors.grey,
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(5))),
                                          child: const Center(
                                              child: Text('Full-Time')),
                                        ),
                                      ),
                                      const SizedBox(
                                        width: 6,
                                      ),
                                      Expanded(
                                        child: Container(
                                          height: 26,
                                          width: 90,
                                          decoration: const BoxDecoration(
                                              color: Colors.grey,
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(5))),
                                          child: const Center(
                                              child: Text('Remote')),
                                        ),
                                      ),
                                    ],
                                  )
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                      itemCount: searchJobList.size,
                    )
              : getAllJobsLoading
                  ? SliverList.list(
                      children: <Widget>[
                        // -------------------
                      ],
                    )
                  : getAllSuggestedJobList.size == 0
                      ? SliverList.list(
                          children: <Widget>[
                            SizedBox(
                              height: 30,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 30),
                                  child: Text(
                                    'No Suggested The Job',
                                    style: TextStyle(
                                      color: Colors.grey,
                                      fontWeight: FontWeight.normal,
                                      fontSize: 18,
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(
                              height: 30,
                            ),
                            // -------------------
                          ],
                        )
                      : SliverList.builder(
                          itemCount: getAllSuggestedJobList.size,
                          itemBuilder: (context, index) {
                            return JobItemCard(
                              getAllJobData: getAllSuggestedJobList[index],
                            );
                          },
                        ),

          // loading All Jobs ----

          !isCickFilter
              ? getAllJobsLoading
                  ? SliverList.list(
                      children: [
                        Container(
                          //color: Colors.amber,
                          height: 200.h,
                          width: 1000.w,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Text(
                                'Please Wait',
                                style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                  color: JColors.splashBackgroundColor,
                                  fontFamily: AutofillHints.addressCityAndState,
                                ),
                              ),
                              Center(
                                child: CircularProgressIndicator(
                                  backgroundColor:
                                      JColors.splashBackgroundColor,
                                ),
                              ),
                            ],
                          ),
                        )
                      ],
                    )
                  : SliverList.list(children: [
                      const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 20),
                        child: TSectionHeading(
                          title: 'Recent Jobs',
                          showActionButton: true,
                          textColor: JColors.splashBackgroundColor,
                        ),
                      ),
                    ])
              : SliverList.list(children: []),

          // All Jobs ---
          !isCickFilter
              ? allJobsList.size == 0
                  ? SliverList.list(children: [
                      const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 20),
                        child: TSectionHeading(
                          title: 'No Jobs',
                          showActionButton: true,
                          textColor: JColors.splashBackgroundColor,
                        ),
                      ),
                    ])
                  : SliverList.builder(
                      itemCount: allJobsList.size,
                      itemBuilder: (context, index) {
                        return JobItemCard(
                          getAllJobData: allJobsList[index],
                        );
                      },
                    )
              : SliverList.list(children: [])
        ],
      ),
    );
  }
}
