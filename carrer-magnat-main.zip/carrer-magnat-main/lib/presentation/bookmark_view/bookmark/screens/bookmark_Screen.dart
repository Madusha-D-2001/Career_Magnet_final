import 'package:carrermagnet/utils/constants/colors.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'widgets/book_mark_card.dart';

class BookMarkScreen extends StatelessWidget {
  const BookMarkScreen({super.key});

  @override
  Widget build(BuildContext context) {
    var h = MediaQuery.of(context).size.height;
    var w = MediaQuery.of(context).size.width;

    return Scaffold(
      appBar: AppBar(
        leading: const Icon(
          Icons.arrow_back,
          color: Colors.white,
        ),
        title: const Text(
          'Bookmarks',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: JColors.splashBackgroundColor,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
          child: Column(
            children: [
              BookMarkCard(h: h),
              BookMarkCard(h: h),
              BookMarkCard(h: h),
              BookMarkCard(h: h),
              BookMarkCard(h: h),
              BookMarkCard(h: h),
              BookMarkCard(h: h),
            ],
          ),
        ),
      ),
    );
  }
}
