import 'package:flutter/material.dart';

class CommonFooterButton extends StatelessWidget {
  const CommonFooterButton({
    Key? key,
    required this.title,
    required this.onPress,
  }) : super(key: key);

  final String title;
  final VoidCallback onPress;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onPress,
      child: Text(
        title,
        style: const TextStyle(
            fontSize: 14, fontWeight: FontWeight.normal, color: Colors.black),
      ),
    );
  }
}
