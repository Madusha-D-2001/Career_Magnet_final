import 'package:carrermagnet/presentation/core/widgets/common_loading_indicator.dart';
import 'package:carrermagnet/routes/routes_name.dart';
import 'package:carrermagnet/utils/constants/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_overlay_loader/flutter_overlay_loader.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:flutter_hooks/flutter_hooks.dart';

import '../../application/app_state/app_state_notifier_provider.dart';
import '../../application/recruiter/recruiter_state_notifier_provider.dart';
import '../alert/alert_utils.dart';
import '../profile_view/log_out_bottopm_sheet.dart';

class AllAddJobPostView extends HookConsumerWidget {
  const AllAddJobPostView({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    useEffect(() {
      Future.delayed(Duration.zero, () {
        final recruID = ref.watch(appStateNotifierProvider.select(
          (value) => value.userId,
        ));

        ref
            .watch(recruiterStateNotifierProvider.notifier)
            .getAllPostedJobsByRecruiterID(recruiterID: recruID);
      });
      return;
    }, [
      ref.watch(recruiterStateNotifierProvider.select(
        (value) => value.isDeleteHiringAnnouncement,
      ))
    ]);

    // ref.listen<Option<AddHiringAnnouncementResponse>>(
    //     recruiterStateNotifierProvider.select(
    //         (value) => value.deleteHiringAnnouncementResponse), (_, value) {
    //   value.fold(() {}, (failure) {
    //     AlertUtils.showErrorDialog(
    //         context: context, message: '');
    //   });
    // });

    ref.listen<bool>(
      recruiterStateNotifierProvider
          .select((value) => value.isLoadingGetPostedJobs),
      (_, value) {
        if (value) {
          Loader.show(context,
              progressIndicator: const CommonLoadingIndicator());
        } else {
          Loader.hide();
        }
      },
    );

    ref.listen<bool>(
      recruiterStateNotifierProvider
          .select((value) => value.isdeleteHiringAnnouncementLoading),
      (_, value) {
        if (value) {
          Loader.show(context,
              progressIndicator: const CommonLoadingIndicator());
        } else {
          Loader.hide();
        }
      },
    );

    final getAllPostedJobsByRecruiterList =
        ref.watch(recruiterStateNotifierProvider.select(
      (value) => value.getAllPostedJobsByRecruiterIDList,
    ));
    var h = MediaQuery.of(context).size.height;
    var w = MediaQuery.of(context).size.width;
    return Scaffold(
        appBar: AppBar(
          // leading: const Icon(
          //   Icons.arrow_back,
          //   color: Colors.white,
          // ),
          title: const Text(
            'All Job Post',
            style: TextStyle(color: Colors.white),
          ),
          actions: [
            InkWell(
              onTap: () {
                Navigator.popAndPushNamed(
                  context,
                  RoutesName.addHiringAnnouncementView,
                );
              },
              child: Text(
                "+ add Job",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                ),
              ),
            ),
            const SizedBox(
              width: 15,
            ),
            InkWell(
              onTap: () {
                logOutBottomSheet(context, ref);
              },
              child: Icon(
                Icons.logout,
                color: Colors.white,
              ),
            ),
            const SizedBox(
              width: 15,
            ),
          ],
          backgroundColor: JColors.splashBackgroundColor,
        ),
        body: getAllPostedJobsByRecruiterList.isEmpty()
            ? Container(
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text(
                        'No Add Job yet',
                        style: TextStyle(
                          color: Colors.grey,
                          fontWeight: FontWeight.w700,
                          fontSize: 17,
                        ),
                      ),
                      Image.asset(
                        'assets/images/careermagnet_blue_logo.png',
                        scale: 4,
                      ),
                    ],
                  ),
                ),
              )
            : ListView.builder(
                itemCount: getAllPostedJobsByRecruiterList.size,
                itemBuilder: (context, index) {
                  final detail = getAllPostedJobsByRecruiterList[index];
                  return Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 10),
                    child: Column(
                      children: [
                        Container(
                          //margin: const EdgeInsets.all(10),
                          // height: h * 0.2,
                          width: double.infinity,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(20),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black
                                    .withOpacity(0.3), // Shadow color
                                spreadRadius: 2, // Spread radius
                                blurRadius: 5, // Blur radius
                                offset: const Offset(0, 3), // Shadow position
                              ),
                            ],
                          ),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 10),
                            child: Column(
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Container(
                                      width: 1000.w,
                                      child: Text(
                                        detail.jobType,
                                        style: TextStyle(
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 15),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                    Container(
                                      width: 1000.w,
                                      child: Text(
                                        detail.companyName,
                                        style: TextStyle(
                                            color: Colors.grey,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 13),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(
                                  height: 10,
                                ),
                                Row(
                                  children: [
                                    Text(
                                      'Location :',
                                      style: TextStyle(
                                          color: Colors.grey,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 15),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                    SizedBox(
                                      width: 10,
                                    ),
                                    Text(
                                      detail.location,
                                      style: TextStyle(
                                          color: Colors.grey,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 13),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ],
                                ),
                                const SizedBox(
                                  height: 16,
                                ),
                                const Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Job description :',
                                      style: TextStyle(
                                          color: Colors.black,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 15),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ],
                                ),
                                const SizedBox(
                                  height: 16,
                                ),
                                Row(
                                  children: [
                                    Expanded(
                                      child: TextField(
                                        readOnly: true,
                                        controller: TextEditingController(
                                            text: detail
                                                .jobDescription), // Pre-fill with data
                                        maxLines:
                                            10, // Allows for multiple lines
                                        style: TextStyle(
                                          color: Colors.grey,
                                          fontWeight: FontWeight.w700,
                                          fontSize: 15,
                                        ),
                                        decoration: InputDecoration(
                                          border:
                                              OutlineInputBorder(), // Adds a border like a textarea
                                          hintText:
                                              "Enter job description", // Optional placeholder
                                          contentPadding: EdgeInsets.all(8.0),
                                        ),
                                        textAlign: TextAlign.justify,
                                        onChanged: (value) {
                                          // Update your job description here if needed
                                        },
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(
                                  height: 16,
                                ),
                                const Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Text(
                                      'skill List :',
                                      style: TextStyle(
                                          color: Colors.black,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 15),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ],
                                ),
                                const SizedBox(
                                  height: 16,
                                ),
                                Row(
                                  children: [
                                    Expanded(
                                      child: Text(
                                        textAlign: TextAlign.justify,
                                        detail.skillList.toString(),
                                        style: TextStyle(
                                          color: Colors.grey,
                                          fontWeight: FontWeight.w700,
                                          fontSize: 15,
                                        ),
                                        maxLines: 4,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(
                                  height: 16,
                                ),
                                Row(
                                  children: [
                                    Expanded(
                                      child: InkWell(
                                        onTap: () {
                                          Navigator.popAndPushNamed(
                                            context,
                                            RoutesName.allApplyUserDetailView,
                                            arguments: {
                                              'hiringId': detail.id,
                                            },
                                          );
                                        },
                                        child: Container(
                                          height: 36,
                                          width: 90,
                                          decoration: const BoxDecoration(
                                              color: Colors.grey,
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(5))),
                                          child: const Center(
                                              child: Text(
                                            'View Detail',
                                            style: TextStyle(
                                              color: Colors.white,
                                            ),
                                          )),
                                        ),
                                      ),
                                    ),
                                    const SizedBox(
                                      width: 6,
                                    ),
                                    Expanded(
                                      child: InkWell(
                                        onTap: () {
                                          AlertUtils.showErrorDialog(
                                            context: context,
                                            message:
                                                'Are You sure To Remove This Job post',
                                            onActionPressed: (context) {
                                              ref
                                                  .watch(
                                                      recruiterStateNotifierProvider
                                                          .notifier)
                                                  .deleteHiringAnnouncement(
                                                      hiringID: detail.id);

                                              Navigator.pop(context);
                                            },
                                            onCancelActionPressed: (context) {
                                              Navigator.pop(context);
                                            },
                                          );
                                        },
                                        child: Container(
                                          height: 36,
                                          width: 90,
                                          decoration: const BoxDecoration(
                                              color: Colors.red,
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(5))),
                                          child: const Center(
                                              child: Text(
                                            'Remove',
                                            style: TextStyle(
                                              color: Colors.white,
                                            ),
                                          )),
                                        ),
                                      ),
                                    ),
                                  ],
                                )
                              ],
                            ),
                          ),
                        )
                      ],
                    ),
                  );
                },
              ));
  }
}
