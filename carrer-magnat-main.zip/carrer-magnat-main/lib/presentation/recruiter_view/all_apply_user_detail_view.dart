import 'package:flutter/material.dart';
import 'package:flutter_overlay_loader/flutter_overlay_loader.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:flutter_hooks/flutter_hooks.dart';

import '../../application/recruiter/recruiter_state_notifier_provider.dart';
import '../../routes/routes_name.dart';
import '../../utils/constants/colors.dart';
import '../core/widgets/common_loading_indicator.dart';

class AllApplyUserDetailView extends HookConsumerWidget {
  AllApplyUserDetailView({
    super.key,
    required this.hiringId,
  });

  String hiringId;
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    useEffect(() {
      Future.delayed(Duration.zero, () {
        ref
            .read(recruiterStateNotifierProvider.notifier)
            .getAllAppliedUserProfilesByHiringID(hiringID: hiringId);
      });
      return null;
    }, []);

    // ref.listen<Option<AddHiringAnnouncementResponse>>(
    //     recruiterStateNotifierProvider.select(
    //         (value) => value.deleteHiringAnnouncementResponse), (_, value) {
    //   value.fold(() {}, (failure) {
    //     AlertUtils.showErrorDialog(
    //         context: context, message: '');
    //   });
    // });

    ref.listen<bool>(
      recruiterStateNotifierProvider
          .select((value) => value.isLoadingGetAllAppliedUser),
      (_, value) {
        if (value) {
          Loader.show(context,
              progressIndicator: const CommonLoadingIndicator());
        } else {
          Loader.hide();
        }
      },
    );

    final getAllAppliedUserProfilesByHiringIDList =
        ref.watch(recruiterStateNotifierProvider.select(
      (value) => value.getAllAppliedUserProfilesByHiringIDList,
    ));

    return Scaffold(
        appBar: AppBar(
          leading: InkWell(
            onTap: () {
              Navigator.pushNamedAndRemoveUntil(
                context,
                RoutesName
                    .recruiterNavigationView, // The name of the route you want to navigate to
                (Route<dynamic> route) => false, // Remove all previous routes
              );
            },
            child: const Icon(
              Icons.arrow_back,
              color: Colors.white,
            ),
          ),
          title: const Text(
            'Detail',
            style: TextStyle(color: Colors.white),
          ),
          backgroundColor: JColors.splashBackgroundColor,
        ),
        body: getAllAppliedUserProfilesByHiringIDList.isEmpty()
            ? Container(
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text(
                        'No Apply Yet',
                        style: TextStyle(
                          color: Colors.grey,
                          fontWeight: FontWeight.w700,
                          fontSize: 17,
                        ),
                      ),
                      Image.asset(
                        'assets/images/careermagnet_blue_logo.png',
                        scale: 4,
                      ),
                    ],
                  ),
                ),
              )
            : ListView.builder(
                itemCount: getAllAppliedUserProfilesByHiringIDList.size,
                itemBuilder: (context, index) {
                  final detail = getAllAppliedUserProfilesByHiringIDList[index];
                  return Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 10),
                    child: Column(
                      children: [
                        Container(
                          //margin: const EdgeInsets.all(10),
                          // height: h * 0.2,
                          width: double.infinity,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(20),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black
                                    .withOpacity(0.3), // Shadow color
                                spreadRadius: 2, // Spread radius
                                blurRadius: 5, // Blur radius
                                offset: const Offset(0, 3), // Shadow position
                              ),
                            ],
                          ),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 10),
                            child: Column(
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    SizedBox(
                                      width: 1000.w,
                                      child: const Text(
                                        'Applier Detail',
                                        style: TextStyle(
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 15),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                    const SizedBox(
                                      height: 10,
                                    ),
                                    SizedBox(
                                      width: 1000.w,
                                      child: Row(
                                        children: [
                                          const Text(
                                            'Full Name : ',
                                            style: TextStyle(
                                              color: Colors.grey,
                                              fontWeight: FontWeight.bold,
                                              fontSize: 15,
                                            ),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                          Text(
                                            detail.first_name,
                                            style: const TextStyle(
                                              color: Colors.grey,
                                              fontWeight: FontWeight.bold,
                                              fontSize: 15,
                                            ),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                          Text(
                                            detail.last_name,
                                            style: const TextStyle(
                                              color: Colors.grey,
                                              fontWeight: FontWeight.normal,
                                              fontSize: 15,
                                            ),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ],
                                      ),
                                    ),
                                    SizedBox(
                                      width: 1000.w,
                                      child: Row(
                                        children: [
                                          const Text(
                                            'Address : ',
                                            style: TextStyle(
                                              color: Colors.grey,
                                              fontWeight: FontWeight.bold,
                                              fontSize: 15,
                                            ),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                          Text(
                                            detail.address,
                                            style: const TextStyle(
                                              color: Colors.grey,
                                              fontWeight: FontWeight.normal,
                                              fontSize: 15,
                                            ),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ],
                                      ),
                                    ),
                                    SizedBox(
                                      width: 1000.w,
                                      child: Row(
                                        children: [
                                          const Text(
                                            'Birth Date : ',
                                            style: TextStyle(
                                              color: Colors.grey,
                                              fontWeight: FontWeight.bold,
                                              fontSize: 15,
                                            ),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                          Text(
                                            detail.birthDay.substring(0, 10),
                                            style: const TextStyle(
                                              color: Colors.grey,
                                              fontWeight: FontWeight.normal,
                                              fontSize: 15,
                                            ),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ],
                                      ),
                                    ),
                                    SizedBox(
                                      width: 1000.w,
                                      child: Row(
                                        children: [
                                          const Text(
                                            'Email : ',
                                            style: TextStyle(
                                              color: Colors.grey,
                                              fontWeight: FontWeight.bold,
                                              fontSize: 15,
                                            ),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                          Text(
                                            detail.email,
                                            style: const TextStyle(
                                              color: Colors.grey,
                                              fontWeight: FontWeight.normal,
                                              fontSize: 15,
                                            ),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ],
                                      ),
                                    ),
                                    SizedBox(
                                      width: 1000.w,
                                      child: Row(
                                        children: [
                                          const Text(
                                            'Contact Number : ',
                                            style: TextStyle(
                                              color: Colors.grey,
                                              fontWeight: FontWeight.bold,
                                              fontSize: 15,
                                            ),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                          Text(
                                            detail.contact,
                                            style: const TextStyle(
                                              color: Colors.grey,
                                              fontWeight: FontWeight.normal,
                                              fontSize: 15,
                                            ),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ],
                                      ),
                                    ),
                                    SizedBox(
                                      width: 1000.w,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          const Text(
                                            'Bio : ',
                                            style: TextStyle(
                                              color: Colors.grey,
                                              fontWeight: FontWeight.bold,
                                              fontSize: 15,
                                            ),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                          Text(
                                            detail.profileInfo,
                                            style: const TextStyle(
                                              color: Colors.grey,
                                              fontWeight: FontWeight.normal,
                                              fontSize: 15,
                                            ),
                                            maxLines: 4,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ],
                                      ),
                                    ),
                                    SizedBox(
                                      width: 1000.w,
                                      child: Row(
                                        children: [
                                          const Text(
                                            'University : ',
                                            style: TextStyle(
                                              color: Colors.grey,
                                              fontWeight: FontWeight.bold,
                                              fontSize: 15,
                                            ),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                          Text(
                                            detail.university,
                                            style: const TextStyle(
                                              color: Colors.grey,
                                              fontWeight: FontWeight.normal,
                                              fontSize: 15,
                                            ),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(
                                  height: 10,
                                ),
                                const Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Text(
                                      'skill List :',
                                      style: TextStyle(
                                          color: Colors.black,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 15),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ],
                                ),
                                const SizedBox(
                                  height: 16,
                                ),
                                Row(
                                  children: [
                                    Expanded(
                                      child: Text(
                                        textAlign: TextAlign.justify,
                                        detail.skillList.toString(),
                                        style: const TextStyle(
                                          color: Colors.grey,
                                          fontWeight: FontWeight.w700,
                                          fontSize: 15,
                                        ),
                                        maxLines: 4,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(
                                  height: 16,
                                ),
                                Row(
                                  children: [
                                    Expanded(
                                      child: InkWell(
                                        onTap: () {
                                          Navigator.popAndPushNamed(
                                            context,
                                            RoutesName.sendResponseView,
                                            arguments: {
                                              'hiringID': hiringId,
                                              'userID': detail.user_id,
                                            },
                                          );

                                          // AlertUtils.showErrorDialog(
                                          //   context: context,
                                          //   message:
                                          //       'Are You sure To Remove This Job post',
                                          //   onActionPressed: (context) {
                                          //     ref
                                          //         .watch(
                                          //             recruiterStateNotifierProvider
                                          //                 .notifier)
                                          //         .deleteHiringAnnouncement(
                                          //             hiringID: detail.id);

                                          //     Navigator.pop(context);
                                          //   },
                                          //   onCancelActionPressed: (context) {
                                          //     Navigator.pop(context);
                                          //   },
                                          // );
                                        },
                                        child: Container(
                                          height: 36,
                                          width: 90,
                                          decoration: const BoxDecoration(
                                              color:
                                                  JColors.splashBackgroundColor,
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(5))),
                                          child: const Center(
                                              child: Text(
                                            'Send Response',
                                            style: TextStyle(
                                              color: Colors.white,
                                            ),
                                          )),
                                        ),
                                      ),
                                    ),
                                  ],
                                )
                              ],
                            ),
                          ),
                        )
                      ],
                    ),
                  );
                },
              ));
  }
}
