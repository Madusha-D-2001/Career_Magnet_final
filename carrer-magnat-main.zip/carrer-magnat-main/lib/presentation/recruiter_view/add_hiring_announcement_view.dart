import 'package:animated_custom_dropdown/custom_dropdown.dart';
import 'package:carrermagnet/application/recruiter/recruiter_state_notifier_provider.dart';
import 'package:carrermagnet/presentation/core/widgets/common_loading_indicator.dart';
import 'package:carrermagnet/utils/constants/colors.dart';
import 'package:dartz/dartz.dart';
import 'package:flutter/material.dart';
import 'package:flutter_overlay_loader/flutter_overlay_loader.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:dropdown_button2/dropdown_button2.dart';
import '../../application/app_state/app_state_notifier_provider.dart';
import '../../application/profile_creation/profile_creation_state_notifier_provider.dart';
import '../../domain/add_hiring_announcement/add_hiring_announcement_response.dart';
import '../../domain/core/failure.dart';
import '../../routes/routes_name.dart';
import '../../utils/validators/validators.dart';
import '../alert/alert_utils.dart';
import '../profile_view/multy_selector.dart';

class AddHiringAnnouncementView extends HookConsumerWidget {
  AddHiringAnnouncementView({super.key});

  TextEditingController jobTypeController = TextEditingController();
  TextEditingController jobDescriptionController = TextEditingController();
  TextEditingController locationController = TextEditingController();
  TextEditingController companyNameController = TextEditingController();

  TextEditingController postedDateController = TextEditingController();
  TextEditingController closeDateController = TextEditingController();
  TextEditingController phoneNumberController = TextEditingController();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    useEffect(() {
      Future.delayed(Duration.zero, () {
        final userID = ref.watch(appStateNotifierProvider.select(
          (value) => value.userId,
        ));
      });
      return;
    }, []);

    ref.listen<Option<Failure>>(
        recruiterStateNotifierProvider.select((value) => value.responseFailure),
        (_, value) {
      value.fold(() {}, (failure) {
        AlertUtils.showErrorDialog(
            context: context, message: failure.toString());
      });
    });

    ref.listen<Option<AddHiringAnnouncementResponse>>(
        recruiterStateNotifierProvider.select(
            (value) => value.addHiringAnnouncementResponse), (_, value) {
      value.fold(() {}, (failure) {
        AlertUtils.showErrorDialog(
          context: context,
          message: 'Job Add Sucess',
          onActionPressed: (context) {
            Navigator.pushNamedAndRemoveUntil(
              context,
              RoutesName
                  .recruiterNavigationView, // The name of the route you want to navigate to
              (Route<dynamic> route) => false, // Remove all previous routes
            );
          },
        );
      });
    });

    ref.listen<bool>(
      recruiterStateNotifierProvider
          .select((value) => value.isLoadingAddHiring),
      (_, value) {
        if (value) {
          Loader.show(context,
              progressIndicator: const CommonLoadingIndicator());
        } else {
          Loader.hide();
        }
      },
    );

    final userID = ref.watch(appStateNotifierProvider.select(
      (value) => value.userId,
    ));

    final List<String> items = [
      "Software Engineer (SE)",
      "Senior Software Engineer (SSE)",
      "Software Developer",
      "Full Stack Developer",
      "Front-end Developer",
      "Back-end Developer",
      "Web Developer",
      "Mobile App Developer",
      "DevOps Engineer",
      "Cloud Engineer",
      "Site Reliability Engineer (SRE)",
      "Database Administrator (DBA)",
      "System Administrator (SysAdmin)",
      "Network Administrator",
      "Quality Assurance (QA) Engineer",
      "Automation Test Engineer",
      "Performance Test Engineer",
      "Security Engineer",
      "Information Security Analyst",
      "Cybersecurity Specialist",
      "IT Support Specialist",
      "Help Desk Technician",
      "Technical Support Engineer",
      "Product Manager",
      "Project Manager (PM)",
      "Technical Project Manager",
      "Program Manager",
      "Business Analyst (BA)",
      "Systems Analyst",
      "Data Analyst",
      "Data Scientist",
      "Data Engineer",
      "Big Data Engineer",
      "Machine Learning Engineer",
      "AI Specialist",
      "NLP Engineer",
      "Computer Vision Engineer",
      "Data Architect",
      "Solutions Architect",
      "Cloud Architect",
      "Enterprise Architect",
      "Software Architect",
      "Application Architect",
      "Infrastructure Architect",
      "IT Manager",
      "IT Director",
      "Chief Technology Officer (CTO)",
      "Chief Information Officer (CIO)",
      "Tech Lead",
      "Engineering Manager",
      "UI/UX Designer",
      "Product Designer",
      "User Experience Researcher",
      "Graphic Designer",
      "Technical Writer",
      "Scrum Master",
      "Agile Coach",
      "Business Intelligence (BI) Developer",
      "BI Analyst",
      "Cloud Consultant",
      "IT Consultant",
      "Software Consultant",
      "Network Engineer",
      "System Engineer",
      "Support Engineer",
      "Release Manager",
      "Build Engineer",
      "Integration Engineer",
      "API Developer",
      "Embedded Software Engineer",
      "Firmware Engineer",
      "Mobile Application Manager",
      "IT Auditor",
      "Compliance Specialist",
      "ERP Consultant",
      "CRM Consultant",
      "IT Operations Manager",
      "IT Service Manager",
      "Technical Account Manager",
      "Customer Success Manager",
      "Digital Transformation Specialist",
      "Robotic Process Automation (RPA) Developer",
      "DevSecOps Engineer",
      "Penetration Tester",
      "Ethical Hacker",
      "Cloud Support Engineer",
      "Cloud Solutions Engineer",
      "Cloud DevOps Engineer",
      "Container Engineer",
      "Kubernetes Engineer",
      "Docker Engineer",
      "Artificial Intelligence Engineer",
      "Deep Learning Engineer",
      "Virtualization Engineer",
      "Augmented Reality (AR) Developer",
      "Virtual Reality (VR) Developer",
      "Blockchain Developer",
      "IoT Developer (Internet of Things)",
      "Smart Contract Developer",
      "Game Developer",
      "Video Game Designer",
      "Game Tester",
      "E-commerce Specialist",
      "Digital Marketing Specialist",
      "SEO Specialist",
      "Content Manager",
      "IT Infrastructure Engineer",
      "IT Operations Analyst",
      "IT Support Manager",
      "Application Support Analyst",
      "ERP Support Specialist",
      "IT Trainer",
      "Software Quality Analyst",
      "Data Visualization Specialist",
      "AI Research Scientist",
      "IT Risk Manager",
      "Cloud Platform Engineer",
      "Network Security Engineer",
      "Network Consultant",
      "Data Privacy Officer",
      "IT Governance Specialist",
      "Chief Data Officer (CDO)",
      "Full Stack Software Engineer",
      "Web Application Developer",
      "Backend Systems Developer",
      "Microservices Developer",
      "API Integration Specialist",
      "Functional Consultant",
      "Technical Consultant",
      "System Integration Specialist",
      "Configuration Manager",
      "Release Coordinator",
      "Version Control Specialist",
      "Embedded Systems Developer",
      "Field Service Engineer",
      "VoIP Engineer",
      "Cloud Migration Specialist",
      "IT Business Partner",
      "AI/ML Product Manager",
      "Platform Engineer",
      "IT Service Delivery Manager",
      "Enterprise Solutions Consultant",
      "Digital Product Manager"
    ];
    String? selectedValue;

    final jobTypeList =
        ref.watch(profileCreationStateNotifierProvider.notifier).getJobType();

    DateTime closeDate = DateTime.now();
    DateTime startDate = DateTime.now();

    return Scaffold(
      appBar: AppBar(
        leading: InkWell(
          onTap: () {
            Navigator.pushNamedAndRemoveUntil(
              context,
              RoutesName
                  .recruiterNavigationView, // The name of the route you want to navigate to
              (Route<dynamic> route) => false, // Remove all previous routes
            );
          },
          child: const Icon(
            Icons.arrow_back,
            color: Colors.white,
          ),
        ),
        title: const Text(
          'Add Job Post',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: JColors.splashBackgroundColor,
      ),
      body: SingleChildScrollView(
        child: Form(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
            child: Column(
              children: [
                // Job Type -----------

                DropdownButtonHideUnderline(
                  child: DropdownButton2<String>(
                    isExpanded: true,
                    hint: const Row(
                      children: [
                        Icon(
                          Icons.list,
                          size: 16,
                          color: Colors.grey,
                        ),
                        SizedBox(
                          width: 4,
                        ),
                        Expanded(
                          child: Text(
                            'Select Item',
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              color: Colors.grey,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                    items: items
                        .map((String item) => DropdownMenuItem<String>(
                              value: item,
                              child: Text(
                                item,
                                style: const TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black,
                                ),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ))
                        .toList(),
                    value: ref.watch(recruiterStateNotifierProvider.select(
                      (value) => value.JobType,
                    )),
                    onChanged: (String? value) {
                      ref
                          .watch(recruiterStateNotifierProvider.notifier)
                          .setJobType(JobType: value!);
                    },
                    buttonStyleData: ButtonStyleData(
                      height: 50,
                      width: 800.w,
                      padding: const EdgeInsets.only(left: 14, right: 14),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: Colors.black26,
                        ),
                        color: Colors.white,
                      ),
                      elevation: 2,
                    ),
                    iconStyleData: const IconStyleData(
                      icon: Icon(
                        Icons.arrow_forward_ios_outlined,
                      ),
                      iconSize: 14,
                      iconEnabledColor: Colors.black,
                      iconDisabledColor: Colors.grey,
                    ),
                    dropdownStyleData: DropdownStyleData(
                      maxHeight: 200,
                      padding: EdgeInsets.symmetric(horizontal: 30),
                      width: 900.w,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(14),
                        color: Colors.white,
                      ),
                      offset: const Offset(-20, 0),
                      scrollbarTheme: ScrollbarThemeData(
                        radius: const Radius.circular(40),
                        thickness: MaterialStateProperty.all<double>(6),
                        thumbVisibility: MaterialStateProperty.all<bool>(true),
                      ),
                    ),
                    menuItemStyleData: const MenuItemStyleData(
                      height: 40,
                      padding: EdgeInsets.only(left: 14, right: 14),
                    ),
                  ),
                ),

                const SizedBox(
                  height: 10,
                ),
                // Job Description  --------------------------------------
                TextFormField(
                  maxLines: 4,
                  controller: jobDescriptionController,
                  validator: (value) =>
                      Vvalidator.validateEmptyText('Job Description', value),
                  decoration: InputDecoration(
                      hintText: 'Job Description',
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                      prefixIcon: const Icon(
                        Icons.work_history_rounded,
                        color: Colors.grey,
                      )),
                ),

                const SizedBox(
                  height: 10,
                ),

                // location ---------------------------------------------------

                TextFormField(
                  controller: locationController,
                  validator: (value) =>
                      Vvalidator.validateEmptyText('location', value),
                  decoration: InputDecoration(
                      hintText: 'Location',
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                      prefixIcon: const Icon(
                        Icons.location_on,
                        color: Colors.grey,
                      )),
                ),

                const SizedBox(
                  height: 10,
                ),

                // position

                TextFormField(
                  controller: companyNameController,
                  validator: (value) =>
                      Vvalidator.validateEmptyText('Company Name', value),
                  decoration: InputDecoration(
                      hintText: 'Company Name',
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                      prefixIcon: const Icon(
                        Icons.work,
                        color: Colors.grey,
                      )),
                ),

                const SizedBox(
                  height: 10,
                ),

                // postedDate info -----------------

                TextFormField(
                  controller: postedDateController,
                  readOnly: true, // Makes sure the keyboard doesn't open
                  onTap: () async {
                    FocusScope.of(context)
                        .requestFocus(FocusNode()); // Dismiss the keyboard
                    DateTime? pickedDate = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime(1900), // Set a minimum date if needed
                      lastDate: DateTime(2100), // Set a maximum date if needed
                    );

                    if (pickedDate != null) {
                      // Set the time to 09:00:00 and convert to UTC
                      DateTime dateWithTime = DateTime(
                        pickedDate.year,
                        pickedDate.month,
                        pickedDate.day,
                        9, // Hour set to 9
                        0, // Minute set to 0
                        0, // Second set to 0
                      ).toUtc();

                      // Format the date as "yyyy-MM-dd'T'HH:mm:ss'Z'"
                      postedDateController.text =
                          DateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'")
                              .format(dateWithTime);

                      final DateTime startDay = DateTime.utc(pickedDate.year,
                          pickedDate.month, pickedDate.day, 9, 0, 0);

                      startDate = startDay;
                    }
                  },
                  validator: (value) =>
                      Vvalidator.validateEmptyText('posted Date', value),
                  decoration: InputDecoration(
                    hintText: 'posted Date',
                    filled: true,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    prefixIcon: const Icon(
                      Icons.calendar_month,
                      color: Colors.grey,
                    ),
                  ),
                ),

                const SizedBox(
                  height: 10,
                ),

                // close Date -----------------

                TextFormField(
                  controller: closeDateController,
                  readOnly: true, // Makes sure the keyboard doesn't open
                  onTap: () async {
                    FocusScope.of(context)
                        .requestFocus(FocusNode()); // Dismiss the keyboard
                    DateTime? pickedDate = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime(1900), // Set a minimum date if needed
                      lastDate: DateTime(2100), // Set a maximum date if needed
                    );

                    if (pickedDate != null) {
                      // Set the time to 09:00:00 and convert to UTC
                      DateTime dateWithTime = DateTime(
                        pickedDate.year,
                        pickedDate.month,
                        pickedDate.day,
                        9, // Hour set to 9
                        0, // Minute set to 0
                        0, // Second set to 0
                      ).toUtc();

                      // Format the date as "yyyy-MM-dd'T'HH:mm:ss'Z'"
                      closeDateController.text =
                          DateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'")
                              .format(dateWithTime);

                      final DateTime closeDay = DateTime.utc(pickedDate.year,
                          pickedDate.month, pickedDate.day, 9, 0, 0);

                      closeDate = closeDay;
                    }
                  },
                  validator: (value) =>
                      Vvalidator.validateEmptyText('close Date', value),
                  decoration: InputDecoration(
                    hintText: 'close Date',
                    filled: true,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    prefixIcon: const Icon(
                      Icons.calendar_month,
                      color: Colors.grey,
                    ),
                  ),
                ),

                const SizedBox(
                  height: 10,
                ),

                InkWell(
                  onTap: () async {
                    final List<String> items = [
                      "Java",
                      "Python",
                      "JavaScript",
                      "SQL",
                      "Spring Boot",
                      "React",
                      "Angular",
                      "Node.js",
                      "RESTful APIs",
                      "Microservices",
                      "Docker",
                      "Kubernetes",
                      "AWS",
                      "Azure",
                      "GCP",
                      "CI/CD",
                      "Jenkins",
                      "Git",
                      "Maven",
                      "Gradle",
                      "Agile Methodologies",
                      "Scrum",
                      "JIRA",
                      "Business Analysis",
                      "Requirement Gathering",
                      "UML",
                      "Wireframing",
                      "Data Modeling",
                      "Stakeholder Management",
                      "Risk Management",
                      "Project Planning",
                      "Team Leadership",
                      "Cross-functional Team Collaboration",
                      "Client Communication",
                      "DevOps",
                      "Unit Testing",
                      "Integration Testing",
                      "System Testing",
                      "Automation Testing",
                      "Selenium",
                      "Appium",
                      "Performance Testing",
                      "JMeter",
                      "Load Testing",
                      "Penetration Testing",
                      "API Testing",
                      "Postman",
                      "Swagger",
                      "Cloud Architecture",
                      "Solution Architecture",
                      "TOGAF",
                      "Enterprise Architecture",
                      "Event-driven Architecture",
                      "Service-oriented Architecture (SOA)",
                      "MVC",
                      "Design Patterns",
                      "Data Structures",
                      "Algorithms",
                      "Object-oriented Programming (OOP)",
                      "Functional Programming",
                      "NoSQL Databases",
                      "MongoDB",
                      "Cassandra",
                      "Redis",
                      "GraphQL",
                      "REST",
                      "JSON",
                      "XML",
                      "HTML5",
                      "CSS3",
                      "Bootstrap",
                      "SASS",
                      "TypeScript",
                      "Version Control",
                      "Linux",
                      "Shell Scripting",
                      "Bash",
                      "Powershell",
                      "Network Security",
                      "OAuth2",
                      "JWT",
                      "SSO",
                      "SSL/TLS",
                      "Encryption",
                      "Data Privacy",
                      "GDPR Compliance",
                      "Data Analysis",
                      "Big Data",
                      "Hadoop",
                      "Spark",
                      "Data Warehousing",
                      "ETL",
                      "Data Visualization",
                      "Tableau",
                      "Power BI",
                      "Machine Learning",
                      "Deep Learning",
                      "TensorFlow",
                      "Keras",
                      "Scikit-Learn",
                      "Natural Language Processing (NLP)",
                      "Computer Vision",
                      "AI/ML Model Deployment",
                      "Data Science",
                      "Time Management",
                      "Problem-solving",
                      "Analytical Thinking",
                      "Critical Thinking",
                      "Collaboration",
                      "Effective Communication",
                      "Negotiation",
                      "Conflict Resolution",
                      "Change Management",
                      "Customer Relationship Management (CRM)",
                      "ERP Systems",
                      "SAP",
                      "Oracle",
                      "SQL Server",
                      "MySQL",
                      "PostgreSQL",
                      "SQLite",
                      "PL/SQL",
                      "Data Governance",
                      "Data Quality Management",
                      "Technical Documentation",
                      "User Training",
                      "Mentoring",
                      "Coaching",
                      "Cybersecurity",
                      "Incident Response",
                      "Disaster Recovery",
                      "Business Continuity Planning",
                      "Service Management",
                      "ITIL",
                      "System Administration",
                      "Network Administration",
                      "Cloud Security",
                      "Azure DevOps",
                      "AWS Lambda",
                      "Serverless Architecture",
                      "Event Sourcing",
                      "Apache Kafka",
                      "RabbitMQ",
                      "Distributed Systems",
                      "Containerization",
                      "Server Management",
                      "Mobile App Development",
                      "Android",
                      "iOS",
                      "Swift",
                      "Kotlin",
                      "React Native",
                      "Flutter",
                      "Progressive Web Apps (PWA)",
                      "Backend Development",
                      "Frontend Development",
                      "Middleware",
                      "Graph Databases",
                      "Neo4j",
                      "ElasticSearch",
                      "Log Management",
                      "Monitoring and Logging",
                      "Grafana",
                      "Prometheus",
                      "Data Security",
                      "API Management",
                      "WebSockets",
                      "Cross-Browser Compatibility",
                      "Responsive Design",
                      "Accessibility (WCAG)",
                      "Code Review",
                      "Refactoring",
                      "Clean Code",
                      "SOLID Principles",
                      "Test-Driven Development (TDD)",
                      "Behavior-Driven Development (BDD)",
                      "Continuous Integration",
                      "Continuous Deployment",
                      "Infrastructure as Code (IaC)",
                      "Terraform",
                      "Ansible",
                      "Chef",
                      "Puppet",
                      "CloudFormation",
                      "Salesforce",
                      "CRM Systems",
                      "Help Desk Management",
                      "IT Support",
                      "Quality Management",
                      "ISO Standards",
                      "System Integration",
                      "API Integration",
                      "Software Architecture",
                      "Scalability",
                      "Load Balancing",
                      "High Availability",
                      "Concurrency",
                      "Multithreading",
                      "Message Queues",
                      "API Design",
                      "Web Development",
                      "MVC Frameworks",
                      "Hybrid Mobile Development",
                      "Agile Coaching",
                      "Business Process Management (BPM)",
                    ];

                    final List<String> results = await showDialog(
                      context: context,
                      builder: (BuildContext context) {
                        return MultySelect(
                          items: items,
                        );
                      },
                    );

                    ref
                        .read(recruiterStateNotifierProvider.notifier)
                        .setSkillsToList(results);

                    print('SKill List :::$results');

                    // useState();
                  },
                  child: Container(
                    padding: EdgeInsets.all(4),
                    height: 55,
                    decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey, width: 2),
                        borderRadius: BorderRadius.circular(10)),
                    child: const Row(
                      children: [
                        SizedBox(
                          width: 10,
                        ),
                        Icon(
                          Icons.tips_and_updates,
                          color: Colors.grey,
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Text("SKiLL"),
                      ],
                    ),
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),

                Wrap(
                  children: ref
                      .watch(recruiterStateNotifierProvider
                          .select((value) => value.skillList))
                      .map((e) => Container(
                            decoration: BoxDecoration(
                                border:
                                    Border.all(color: Colors.grey, width: 2),
                                borderRadius: BorderRadius.circular(10)),
                            margin: EdgeInsets.symmetric(
                              horizontal: 5,
                              vertical: 3,
                            ),
                            padding: EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 5,
                            ),
                            child: Text(e),
                          ))
                      .toList(),
                ),

                const SizedBox(
                  height: 40,
                ),

                InkWell(
                  onTap: () {
                    FocusScope.of(context).unfocus();

                    // Parse and set the time component as needed
                    // final DateTime formattedPostedDate = DateTime.parse(
                    //   "${postedDateController.text.substring(0, 10)}T09:00:00Z",
                    // );
                    // final DateTime formattedCloseDate = DateTime.parse(
                    //   "${closeDateController.text.substring(0, 10)}T17:00:00Z",
                    // );

                    // // Format to remove the milliseconds
                    // String formattedPostedDateString =
                    //     DateFormat("yyyy-MM-dd HH:mm:ss.'00Z'")
                    //         .format(formattedPostedDate);
                    // String formattedCloseDateString =
                    //     DateFormat("yyyy-MM-dd HH:mm:ss.'00Z'")
                    //         .format(formattedCloseDate);

                    // print(
                    //     "Posted Date: $formattedPostedDateString"); // 2024-11-12 09:00:00.00Z
                    // print(
                    //     "Close Date: $formattedCloseDateString"); // 2024-11-12 17:00:00.00Z

                    // final DateTime formattedPostedDate = DateTime.parse(
                    //   "${postedDateController.text.substring(0, 10)}T09:00:00Z",
                    // );
                    // final DateTime formattedCloseDate = DateTime.parse(
                    //   "${closeDateController.text.substring(0, 10)}T17:00:00Z",
                    // );

                    // print(
                    //     '::::::::::::formattedPostedDate::::::$formattedCloseDate');
                    // print(
                    //     '::::::::::::formattedCloseDate::::::$formattedCloseDate');

                    print('Close Date ::::::::::::::::: ${closeDate}');
                    //    print('start Date ::::::::::::::::: ${startDate}');

                    ref
                        .read(recruiterStateNotifierProvider.notifier)
                        .addHiringAnnouncement(
                          recruiterID: userID,
                          jobDescription: jobDescriptionController.text,
                          jobType: jobTypeController.text,
                          location: locationController.text,
                          companyName: companyNameController.text,
                          postedDate: startDate, // formatted as ISO 8601 string
                          closeDate: closeDate, // formatted as ISO 8601 string
                        );
                  },
                  child: Container(
                    height: 54,
                    width: 154,
                    decoration: const BoxDecoration(
                        color: JColors.splashBackgroundColor,
                        borderRadius: BorderRadius.all(Radius.circular(10))),
                    child: const Center(
                      child: Text(
                        '+ Add Job',
                        style: TextStyle(color: Colors.white, fontSize: 16),
                      ),
                    ),
                  ),
                ),

                const SizedBox(
                  height: 10,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
