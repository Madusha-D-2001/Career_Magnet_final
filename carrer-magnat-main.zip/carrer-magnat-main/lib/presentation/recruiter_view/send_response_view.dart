import 'package:carrermagnet/domain/add_hiring_announcement/add_hiring_announcement.dart';
import 'package:carrermagnet/presentation/core/widgets/common_loading_indicator.dart';
import 'package:dartz/dartz.dart';
import 'package:flutter/material.dart';
import 'package:flutter_overlay_loader/flutter_overlay_loader.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../application/recruiter/recruiter_state_notifier_provider.dart';
import '../../domain/add_hiring_announcement/add_hiring_announcement_response.dart';
import '../../routes/routes.dart';
import '../../routes/routes_name.dart';
import '../../utils/constants/colors.dart';
import '../../utils/validators/validators.dart';
import '../alert/alert_utils.dart';

class SendResponseView extends HookConsumerWidget {
  SendResponseView({
    super.key,
    required this.hiringID,
    required this.userID,
  });

  String hiringID;
  String userID;

  TextEditingController companyStatusController = TextEditingController();
  TextEditingController messageController = TextEditingController();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    ref.listen<bool>(
      recruiterStateNotifierProvider.select((value) => value.isLoadingReply),
      (_, value) {
        if (value) {
          Loader.show(context,
              progressIndicator: const CommonLoadingIndicator());
        } else {
          Loader.hide();
        }
      },
    );

    ref.listen<Option<AddHiringAnnouncementResponse>>(
        recruiterStateNotifierProvider
            .select((value) => value.sendReplyResponse), (_, value) {
      value.fold(() {}, (response) {
        AlertUtils.showSuccessDialog(
          context: context,
          title: 'Sucess',
          message: 'Reply Send Sucess',
          onActionPressed: (context) {
            Navigator.pushNamedAndRemoveUntil(
              context,
              RoutesName.allApplyUserDetailView,
              arguments: {
                'hiringId': hiringID,
              },
              (Route<dynamic> route) => false,
            );
          },
        );
      });
    });

    print("user ID : $userID");
    print("hiring ID : $hiringID");
    return Scaffold(
      appBar: AppBar(
        leading: InkWell(
          onTap: () {
            Navigator.pushNamedAndRemoveUntil(
              context,
              RoutesName.allApplyUserDetailView,
              arguments: {
                'hiringId': hiringID,
              },
              (Route<dynamic> route) => false,
            );
          },
          child: const Icon(
            Icons.arrow_back,
            color: Colors.white,
          ),
        ),
        title: const Text(
          'Add Projects',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: JColors.splashBackgroundColor,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              // Job Type -----------

              DropdownButtonFormField<String>(
                value:
                    null, // Set the initial value, or use a variable to manage it
                onChanged: (String? newValue) {
                  // Handle the change here
                  companyStatusController.text = newValue ?? '';
                },
                validator: (value) => value == null || value.isEmpty
                    ? 'Please select a status'
                    : null,
                decoration: InputDecoration(
                  hintText: 'Select Status',
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  prefixIcon: const Icon(
                    Icons.work,
                    color: Colors.grey,
                  ),
                ),
                items: ['VIEWED', 'APPLIED', 'SELECTED', 'REJECTED']
                    .map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
              ),

              const SizedBox(
                height: 10,
              ),
              // Job Description  --------------------------------------
              TextFormField(
                controller: messageController,
                validator: (value) =>
                    Vvalidator.validateEmptyText('message', value),
                decoration: InputDecoration(
                    hintText: 'Response message',
                    filled: true,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10)),
                    prefixIcon: const Icon(
                      Icons.work_history_rounded,
                      color: Colors.grey,
                    )),
              ),

              const SizedBox(
                height: 40,
              ),

              InkWell(
                onTap: () {
                  FocusScope.of(context).unfocus();

                  ref.read(recruiterStateNotifierProvider.notifier).sendReponse(
                        hiringID: hiringID,
                        message: messageController.text,
                        userID: userID,
                        companyRespondStatus: companyStatusController.text,
                      );
                },
                child: Container(
                  height: 54,
                  width: 154,
                  decoration: const BoxDecoration(
                      color: JColors.splashBackgroundColor,
                      borderRadius: BorderRadius.all(Radius.circular(10))),
                  child: const Center(
                    child: Text(
                      'Send Response',
                      style: TextStyle(color: Colors.white, fontSize: 16),
                    ),
                  ),
                ),
              ),

              const SizedBox(
                height: 10,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
