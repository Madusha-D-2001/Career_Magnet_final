import 'package:carrermagnet/domain/core/failure.dart';
import 'package:carrermagnet/domain/get_user_profile/get_user_profile_response.dart';
import 'package:carrermagnet/domain/profile_creation/profile_creation_request.dart';
import 'package:carrermagnet/domain/profile_creation/profile_creation_response.dart';
import 'package:dartz/dartz.dart';

import '../addNewProject/add_new_project_request.dart';
import '../add_hiring_announcement/add_hiring_announcement_response.dart';
import '../apply_to_vacancy/apply_to_vacancy_request.dart';
import '../get_all_applied_vacancies/get_all_applied_vacancies_response.dart';
import '../get_all_job/get_all_job_response.dart';
import '../search_jobs/search_jobs_request.dart';
import '../search_jobs/search_jobs_response.dart';

abstract class IProfileCreationRepository {
  Future<Either<Failure, ProfileCreationResponse>> profileCreation(
      ProfileCreationRequest profileCreationRequest);

  Future<Either<Failure, GetUserProfileResponse>> getUserProfileDetail(
      String email);

  // add project ---------------------------------------------------------------

  Future<Either<Failure, AddHiringAnnouncementResponse>> addNewProject(
      AddNewProjectRequest addNewProjectRequest);

  // Remove project ------------------------------------------------------------

  Future<Either<Failure, AddHiringAnnouncementResponse>> removeProject(
      String projectID);

  // search Job ----------------------------------------------------------------

  Future<Either<Failure, GetAllJobResponse>> searchJob(
      SearchJobsRequest searchJobsRequest);

  // apply Job ----------------------------------------------------------------

  Future<Either<Failure, AddHiringAnnouncementResponse>> applyJob(
      ApplyToVacancyRequest applyToVacancyRequest);

  // get All Job ----------------------------------------------------------------

  Future<Either<Failure, GetAllJobResponse>> getAllJobs();

  // get All Suggested Job ----------------------------------------------------------------

  Future<Either<Failure, GetAllJobResponse>> getAllSuggestedJob(String email);

  // get All Applied Vacancies ----------------------------------------------------------------

  Future<Either<Failure, GetAllAppliedVacanciesResponse>>
      getAllAppliedVacancies(String email);
}
