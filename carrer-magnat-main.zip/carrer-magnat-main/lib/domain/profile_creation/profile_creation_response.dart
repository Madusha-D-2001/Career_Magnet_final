import 'package:carrermagnet/domain/profile_creation/data.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'profile_creation_response.freezed.dart';

@freezed
class ProfileCreationResponse with _$ProfileCreationResponse {
  factory ProfileCreationResponse({
    required int code,
    required String message,
    required Data data,
  }) = _ProfileCreationResponse;

  factory ProfileCreationResponse.empty() {
    return ProfileCreationResponse(
      code: 0,
      message: '',
      data: Data.empty(),
    );
  }
}
