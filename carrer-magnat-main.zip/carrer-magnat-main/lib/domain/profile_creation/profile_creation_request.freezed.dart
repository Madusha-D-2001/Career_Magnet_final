// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'profile_creation_request.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$ProfileCreationRequest {
  String get email => throw _privateConstructorUsedError;
  String get fullName => throw _privateConstructorUsedError;
  String get address => throw _privateConstructorUsedError;
  String get birthDay => throw _privateConstructorUsedError;
  String get profileInfo => throw _privateConstructorUsedError;
  String get education => throw _privateConstructorUsedError;
  String get university => throw _privateConstructorUsedError;
  String get position => throw _privateConstructorUsedError;
  List<dynamic> get skillList => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $ProfileCreationRequestCopyWith<ProfileCreationRequest> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProfileCreationRequestCopyWith<$Res> {
  factory $ProfileCreationRequestCopyWith(ProfileCreationRequest value,
          $Res Function(ProfileCreationRequest) then) =
      _$ProfileCreationRequestCopyWithImpl<$Res, ProfileCreationRequest>;
  @useResult
  $Res call(
      {String email,
      String fullName,
      String address,
      String birthDay,
      String profileInfo,
      String education,
      String university,
      String position,
      List<dynamic> skillList});
}

/// @nodoc
class _$ProfileCreationRequestCopyWithImpl<$Res,
        $Val extends ProfileCreationRequest>
    implements $ProfileCreationRequestCopyWith<$Res> {
  _$ProfileCreationRequestCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? email = null,
    Object? fullName = null,
    Object? address = null,
    Object? birthDay = null,
    Object? profileInfo = null,
    Object? education = null,
    Object? university = null,
    Object? position = null,
    Object? skillList = null,
  }) {
    return _then(_value.copyWith(
      email: null == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String,
      fullName: null == fullName
          ? _value.fullName
          : fullName // ignore: cast_nullable_to_non_nullable
              as String,
      address: null == address
          ? _value.address
          : address // ignore: cast_nullable_to_non_nullable
              as String,
      birthDay: null == birthDay
          ? _value.birthDay
          : birthDay // ignore: cast_nullable_to_non_nullable
              as String,
      profileInfo: null == profileInfo
          ? _value.profileInfo
          : profileInfo // ignore: cast_nullable_to_non_nullable
              as String,
      education: null == education
          ? _value.education
          : education // ignore: cast_nullable_to_non_nullable
              as String,
      university: null == university
          ? _value.university
          : university // ignore: cast_nullable_to_non_nullable
              as String,
      position: null == position
          ? _value.position
          : position // ignore: cast_nullable_to_non_nullable
              as String,
      skillList: null == skillList
          ? _value.skillList
          : skillList // ignore: cast_nullable_to_non_nullable
              as List<dynamic>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ProfileCreationRequestImplCopyWith<$Res>
    implements $ProfileCreationRequestCopyWith<$Res> {
  factory _$$ProfileCreationRequestImplCopyWith(
          _$ProfileCreationRequestImpl value,
          $Res Function(_$ProfileCreationRequestImpl) then) =
      __$$ProfileCreationRequestImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String email,
      String fullName,
      String address,
      String birthDay,
      String profileInfo,
      String education,
      String university,
      String position,
      List<dynamic> skillList});
}

/// @nodoc
class __$$ProfileCreationRequestImplCopyWithImpl<$Res>
    extends _$ProfileCreationRequestCopyWithImpl<$Res,
        _$ProfileCreationRequestImpl>
    implements _$$ProfileCreationRequestImplCopyWith<$Res> {
  __$$ProfileCreationRequestImplCopyWithImpl(
      _$ProfileCreationRequestImpl _value,
      $Res Function(_$ProfileCreationRequestImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? email = null,
    Object? fullName = null,
    Object? address = null,
    Object? birthDay = null,
    Object? profileInfo = null,
    Object? education = null,
    Object? university = null,
    Object? position = null,
    Object? skillList = null,
  }) {
    return _then(_$ProfileCreationRequestImpl(
      email: null == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String,
      fullName: null == fullName
          ? _value.fullName
          : fullName // ignore: cast_nullable_to_non_nullable
              as String,
      address: null == address
          ? _value.address
          : address // ignore: cast_nullable_to_non_nullable
              as String,
      birthDay: null == birthDay
          ? _value.birthDay
          : birthDay // ignore: cast_nullable_to_non_nullable
              as String,
      profileInfo: null == profileInfo
          ? _value.profileInfo
          : profileInfo // ignore: cast_nullable_to_non_nullable
              as String,
      education: null == education
          ? _value.education
          : education // ignore: cast_nullable_to_non_nullable
              as String,
      university: null == university
          ? _value.university
          : university // ignore: cast_nullable_to_non_nullable
              as String,
      position: null == position
          ? _value.position
          : position // ignore: cast_nullable_to_non_nullable
              as String,
      skillList: null == skillList
          ? _value._skillList
          : skillList // ignore: cast_nullable_to_non_nullable
              as List<dynamic>,
    ));
  }
}

/// @nodoc

class _$ProfileCreationRequestImpl implements _ProfileCreationRequest {
  _$ProfileCreationRequestImpl(
      {required this.email,
      required this.fullName,
      required this.address,
      required this.birthDay,
      required this.profileInfo,
      required this.education,
      required this.university,
      required this.position,
      required final List<dynamic> skillList})
      : _skillList = skillList;

  @override
  final String email;
  @override
  final String fullName;
  @override
  final String address;
  @override
  final String birthDay;
  @override
  final String profileInfo;
  @override
  final String education;
  @override
  final String university;
  @override
  final String position;
  final List<dynamic> _skillList;
  @override
  List<dynamic> get skillList {
    if (_skillList is EqualUnmodifiableListView) return _skillList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_skillList);
  }

  @override
  String toString() {
    return 'ProfileCreationRequest(email: $email, fullName: $fullName, address: $address, birthDay: $birthDay, profileInfo: $profileInfo, education: $education, university: $university, position: $position, skillList: $skillList)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ProfileCreationRequestImpl &&
            (identical(other.email, email) || other.email == email) &&
            (identical(other.fullName, fullName) ||
                other.fullName == fullName) &&
            (identical(other.address, address) || other.address == address) &&
            (identical(other.birthDay, birthDay) ||
                other.birthDay == birthDay) &&
            (identical(other.profileInfo, profileInfo) ||
                other.profileInfo == profileInfo) &&
            (identical(other.education, education) ||
                other.education == education) &&
            (identical(other.university, university) ||
                other.university == university) &&
            (identical(other.position, position) ||
                other.position == position) &&
            const DeepCollectionEquality()
                .equals(other._skillList, _skillList));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      email,
      fullName,
      address,
      birthDay,
      profileInfo,
      education,
      university,
      position,
      const DeepCollectionEquality().hash(_skillList));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ProfileCreationRequestImplCopyWith<_$ProfileCreationRequestImpl>
      get copyWith => __$$ProfileCreationRequestImplCopyWithImpl<
          _$ProfileCreationRequestImpl>(this, _$identity);
}

abstract class _ProfileCreationRequest implements ProfileCreationRequest {
  factory _ProfileCreationRequest(
      {required final String email,
      required final String fullName,
      required final String address,
      required final String birthDay,
      required final String profileInfo,
      required final String education,
      required final String university,
      required final String position,
      required final List<dynamic> skillList}) = _$ProfileCreationRequestImpl;

  @override
  String get email;
  @override
  String get fullName;
  @override
  String get address;
  @override
  String get birthDay;
  @override
  String get profileInfo;
  @override
  String get education;
  @override
  String get university;
  @override
  String get position;
  @override
  List<dynamic> get skillList;
  @override
  @JsonKey(ignore: true)
  _$$ProfileCreationRequestImplCopyWith<_$ProfileCreationRequestImpl>
      get copyWith => throw _privateConstructorUsedError;
}
