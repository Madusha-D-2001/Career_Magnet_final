import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kt_dart/kt.dart';

part 'profile_creation_request.freezed.dart';

@freezed
class ProfileCreationRequest with _$ProfileCreationRequest {
  factory ProfileCreationRequest({
    required String email,
    required String fullName,
    required String address,
    required String birthDay,
    required String profileInfo,
    required String education,
    required String university,
    required String position,
    required List skillList,
  }) = _ProfileCreationRequest;

  factory ProfileCreationRequest.empty() {
    return ProfileCreationRequest(
      email: '',
      fullName: '',
      address: '',
      birthDay: '',
      profileInfo: '',
      education: '',
      university: '',
      position: '',
      skillList: [],
    );
  }
}
