import 'package:freezed_annotation/freezed_annotation.dart';

part 'data.freezed.dart';

@freezed
class Data with _$Data {
  factory Data({
    required String user_profile_id,
  }) = _Data;

  factory Data.empty() {
    return Data(
      user_profile_id: '',
    );
  }
}
