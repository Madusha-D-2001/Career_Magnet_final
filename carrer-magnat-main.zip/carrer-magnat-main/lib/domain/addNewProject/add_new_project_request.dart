import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kt_dart/kt.dart';

part 'add_new_project_request.freezed.dart';

@freezed
class AddNewProjectRequest with _$AddNewProjectRequest {
  factory AddNewProjectRequest({
    required String user_profile_id,
    required String project_name,
    required String description,
    required KtList<String> used_skills,
  }) = _AddNewProjectRequest;

  factory AddNewProjectRequest.empty() {
    return AddNewProjectRequest(
      user_profile_id: '',
      project_name: '',
      description: '',
      used_skills: emptyList(),
    );
  }
}
