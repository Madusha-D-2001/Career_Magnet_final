// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'add_new_project_request.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$AddNewProjectRequest {
  String get user_profile_id => throw _privateConstructorUsedError;
  String get project_name => throw _privateConstructorUsedError;
  String get description => throw _privateConstructorUsedError;
  KtList<String> get used_skills => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $AddNewProjectRequestCopyWith<AddNewProjectRequest> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AddNewProjectRequestCopyWith<$Res> {
  factory $AddNewProjectRequestCopyWith(AddNewProjectRequest value,
          $Res Function(AddNewProjectRequest) then) =
      _$AddNewProjectRequestCopyWithImpl<$Res, AddNewProjectRequest>;
  @useResult
  $Res call(
      {String user_profile_id,
      String project_name,
      String description,
      KtList<String> used_skills});
}

/// @nodoc
class _$AddNewProjectRequestCopyWithImpl<$Res,
        $Val extends AddNewProjectRequest>
    implements $AddNewProjectRequestCopyWith<$Res> {
  _$AddNewProjectRequestCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? user_profile_id = null,
    Object? project_name = null,
    Object? description = null,
    Object? used_skills = null,
  }) {
    return _then(_value.copyWith(
      user_profile_id: null == user_profile_id
          ? _value.user_profile_id
          : user_profile_id // ignore: cast_nullable_to_non_nullable
              as String,
      project_name: null == project_name
          ? _value.project_name
          : project_name // ignore: cast_nullable_to_non_nullable
              as String,
      description: null == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String,
      used_skills: null == used_skills
          ? _value.used_skills
          : used_skills // ignore: cast_nullable_to_non_nullable
              as KtList<String>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$AddNewProjectRequestImplCopyWith<$Res>
    implements $AddNewProjectRequestCopyWith<$Res> {
  factory _$$AddNewProjectRequestImplCopyWith(_$AddNewProjectRequestImpl value,
          $Res Function(_$AddNewProjectRequestImpl) then) =
      __$$AddNewProjectRequestImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String user_profile_id,
      String project_name,
      String description,
      KtList<String> used_skills});
}

/// @nodoc
class __$$AddNewProjectRequestImplCopyWithImpl<$Res>
    extends _$AddNewProjectRequestCopyWithImpl<$Res, _$AddNewProjectRequestImpl>
    implements _$$AddNewProjectRequestImplCopyWith<$Res> {
  __$$AddNewProjectRequestImplCopyWithImpl(_$AddNewProjectRequestImpl _value,
      $Res Function(_$AddNewProjectRequestImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? user_profile_id = null,
    Object? project_name = null,
    Object? description = null,
    Object? used_skills = null,
  }) {
    return _then(_$AddNewProjectRequestImpl(
      user_profile_id: null == user_profile_id
          ? _value.user_profile_id
          : user_profile_id // ignore: cast_nullable_to_non_nullable
              as String,
      project_name: null == project_name
          ? _value.project_name
          : project_name // ignore: cast_nullable_to_non_nullable
              as String,
      description: null == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String,
      used_skills: null == used_skills
          ? _value.used_skills
          : used_skills // ignore: cast_nullable_to_non_nullable
              as KtList<String>,
    ));
  }
}

/// @nodoc

class _$AddNewProjectRequestImpl implements _AddNewProjectRequest {
  _$AddNewProjectRequestImpl(
      {required this.user_profile_id,
      required this.project_name,
      required this.description,
      required this.used_skills});

  @override
  final String user_profile_id;
  @override
  final String project_name;
  @override
  final String description;
  @override
  final KtList<String> used_skills;

  @override
  String toString() {
    return 'AddNewProjectRequest(user_profile_id: $user_profile_id, project_name: $project_name, description: $description, used_skills: $used_skills)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$AddNewProjectRequestImpl &&
            (identical(other.user_profile_id, user_profile_id) ||
                other.user_profile_id == user_profile_id) &&
            (identical(other.project_name, project_name) ||
                other.project_name == project_name) &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.used_skills, used_skills) ||
                other.used_skills == used_skills));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, user_profile_id, project_name, description, used_skills);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$AddNewProjectRequestImplCopyWith<_$AddNewProjectRequestImpl>
      get copyWith =>
          __$$AddNewProjectRequestImplCopyWithImpl<_$AddNewProjectRequestImpl>(
              this, _$identity);
}

abstract class _AddNewProjectRequest implements AddNewProjectRequest {
  factory _AddNewProjectRequest(
      {required final String user_profile_id,
      required final String project_name,
      required final String description,
      required final KtList<String> used_skills}) = _$AddNewProjectRequestImpl;

  @override
  String get user_profile_id;
  @override
  String get project_name;
  @override
  String get description;
  @override
  KtList<String> get used_skills;
  @override
  @JsonKey(ignore: true)
  _$$AddNewProjectRequestImplCopyWith<_$AddNewProjectRequestImpl>
      get copyWith => throw _privateConstructorUsedError;
}
