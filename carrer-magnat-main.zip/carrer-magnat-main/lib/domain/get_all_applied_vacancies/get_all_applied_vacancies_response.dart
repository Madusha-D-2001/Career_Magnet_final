import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kt_dart/kt.dart';

import 'get_all_applied_vacancies_data.dart';

part 'get_all_applied_vacancies_response.freezed.dart';

@freezed
class GetAllAppliedVacanciesResponse with _$GetAllAppliedVacanciesResponse {
  factory GetAllAppliedVacanciesResponse({
    required int code,
    required String message,
    required KtList<GetAllAppliedVacanciesData> data,
  }) = _GetAllAppliedVacanciesResponse;

  factory GetAllAppliedVacanciesResponse.empty() {
    return GetAllAppliedVacanciesResponse(
      code: 0,
      message: '',
      data: emptyList(),
    );
  }
}
