import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kt_dart/kt.dart';

part 'get_all_applied_vacancies_data.freezed.dart';

@freezed
class GetAllAppliedVacanciesData with _$GetAllAppliedVacanciesData {
  factory GetAllAppliedVacanciesData({
    required String hiringId,
    required String companyRespondStatus,
    required String message,
    required String recruiterID,
    required String jobDescription,
    required String jobType,
    required String location,
    required String companyName,
    required String postedDate,
    required String closeDate,
    required KtList<String> skillList,
  }) = _GetAllAppliedVacanciesData;

  factory GetAllAppliedVacanciesData.empty() {
    return GetAllAppliedVacanciesData(
      hiringId: '',
      companyRespondStatus: '',
      message: '',
      recruiterID: '',
      jobDescription: '',
      jobType: '',
      location: '',
      companyName: '',
      postedDate: '',
      closeDate: '',
      skillList: emptyList(),
    );
  }
}
