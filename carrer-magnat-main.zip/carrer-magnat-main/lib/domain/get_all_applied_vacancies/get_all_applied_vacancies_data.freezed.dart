// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'get_all_applied_vacancies_data.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$GetAllAppliedVacanciesData {
  String get hiringId => throw _privateConstructorUsedError;
  String get companyRespondStatus => throw _privateConstructorUsedError;
  String get message => throw _privateConstructorUsedError;
  String get recruiterID => throw _privateConstructorUsedError;
  String get jobDescription => throw _privateConstructorUsedError;
  String get jobType => throw _privateConstructorUsedError;
  String get location => throw _privateConstructorUsedError;
  String get companyName => throw _privateConstructorUsedError;
  String get postedDate => throw _privateConstructorUsedError;
  String get closeDate => throw _privateConstructorUsedError;
  KtList<String> get skillList => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $GetAllAppliedVacanciesDataCopyWith<GetAllAppliedVacanciesData>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GetAllAppliedVacanciesDataCopyWith<$Res> {
  factory $GetAllAppliedVacanciesDataCopyWith(GetAllAppliedVacanciesData value,
          $Res Function(GetAllAppliedVacanciesData) then) =
      _$GetAllAppliedVacanciesDataCopyWithImpl<$Res,
          GetAllAppliedVacanciesData>;
  @useResult
  $Res call(
      {String hiringId,
      String companyRespondStatus,
      String message,
      String recruiterID,
      String jobDescription,
      String jobType,
      String location,
      String companyName,
      String postedDate,
      String closeDate,
      KtList<String> skillList});
}

/// @nodoc
class _$GetAllAppliedVacanciesDataCopyWithImpl<$Res,
        $Val extends GetAllAppliedVacanciesData>
    implements $GetAllAppliedVacanciesDataCopyWith<$Res> {
  _$GetAllAppliedVacanciesDataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? hiringId = null,
    Object? companyRespondStatus = null,
    Object? message = null,
    Object? recruiterID = null,
    Object? jobDescription = null,
    Object? jobType = null,
    Object? location = null,
    Object? companyName = null,
    Object? postedDate = null,
    Object? closeDate = null,
    Object? skillList = null,
  }) {
    return _then(_value.copyWith(
      hiringId: null == hiringId
          ? _value.hiringId
          : hiringId // ignore: cast_nullable_to_non_nullable
              as String,
      companyRespondStatus: null == companyRespondStatus
          ? _value.companyRespondStatus
          : companyRespondStatus // ignore: cast_nullable_to_non_nullable
              as String,
      message: null == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String,
      recruiterID: null == recruiterID
          ? _value.recruiterID
          : recruiterID // ignore: cast_nullable_to_non_nullable
              as String,
      jobDescription: null == jobDescription
          ? _value.jobDescription
          : jobDescription // ignore: cast_nullable_to_non_nullable
              as String,
      jobType: null == jobType
          ? _value.jobType
          : jobType // ignore: cast_nullable_to_non_nullable
              as String,
      location: null == location
          ? _value.location
          : location // ignore: cast_nullable_to_non_nullable
              as String,
      companyName: null == companyName
          ? _value.companyName
          : companyName // ignore: cast_nullable_to_non_nullable
              as String,
      postedDate: null == postedDate
          ? _value.postedDate
          : postedDate // ignore: cast_nullable_to_non_nullable
              as String,
      closeDate: null == closeDate
          ? _value.closeDate
          : closeDate // ignore: cast_nullable_to_non_nullable
              as String,
      skillList: null == skillList
          ? _value.skillList
          : skillList // ignore: cast_nullable_to_non_nullable
              as KtList<String>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$GetAllAppliedVacanciesDataImplCopyWith<$Res>
    implements $GetAllAppliedVacanciesDataCopyWith<$Res> {
  factory _$$GetAllAppliedVacanciesDataImplCopyWith(
          _$GetAllAppliedVacanciesDataImpl value,
          $Res Function(_$GetAllAppliedVacanciesDataImpl) then) =
      __$$GetAllAppliedVacanciesDataImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String hiringId,
      String companyRespondStatus,
      String message,
      String recruiterID,
      String jobDescription,
      String jobType,
      String location,
      String companyName,
      String postedDate,
      String closeDate,
      KtList<String> skillList});
}

/// @nodoc
class __$$GetAllAppliedVacanciesDataImplCopyWithImpl<$Res>
    extends _$GetAllAppliedVacanciesDataCopyWithImpl<$Res,
        _$GetAllAppliedVacanciesDataImpl>
    implements _$$GetAllAppliedVacanciesDataImplCopyWith<$Res> {
  __$$GetAllAppliedVacanciesDataImplCopyWithImpl(
      _$GetAllAppliedVacanciesDataImpl _value,
      $Res Function(_$GetAllAppliedVacanciesDataImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? hiringId = null,
    Object? companyRespondStatus = null,
    Object? message = null,
    Object? recruiterID = null,
    Object? jobDescription = null,
    Object? jobType = null,
    Object? location = null,
    Object? companyName = null,
    Object? postedDate = null,
    Object? closeDate = null,
    Object? skillList = null,
  }) {
    return _then(_$GetAllAppliedVacanciesDataImpl(
      hiringId: null == hiringId
          ? _value.hiringId
          : hiringId // ignore: cast_nullable_to_non_nullable
              as String,
      companyRespondStatus: null == companyRespondStatus
          ? _value.companyRespondStatus
          : companyRespondStatus // ignore: cast_nullable_to_non_nullable
              as String,
      message: null == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String,
      recruiterID: null == recruiterID
          ? _value.recruiterID
          : recruiterID // ignore: cast_nullable_to_non_nullable
              as String,
      jobDescription: null == jobDescription
          ? _value.jobDescription
          : jobDescription // ignore: cast_nullable_to_non_nullable
              as String,
      jobType: null == jobType
          ? _value.jobType
          : jobType // ignore: cast_nullable_to_non_nullable
              as String,
      location: null == location
          ? _value.location
          : location // ignore: cast_nullable_to_non_nullable
              as String,
      companyName: null == companyName
          ? _value.companyName
          : companyName // ignore: cast_nullable_to_non_nullable
              as String,
      postedDate: null == postedDate
          ? _value.postedDate
          : postedDate // ignore: cast_nullable_to_non_nullable
              as String,
      closeDate: null == closeDate
          ? _value.closeDate
          : closeDate // ignore: cast_nullable_to_non_nullable
              as String,
      skillList: null == skillList
          ? _value.skillList
          : skillList // ignore: cast_nullable_to_non_nullable
              as KtList<String>,
    ));
  }
}

/// @nodoc

class _$GetAllAppliedVacanciesDataImpl implements _GetAllAppliedVacanciesData {
  _$GetAllAppliedVacanciesDataImpl(
      {required this.hiringId,
      required this.companyRespondStatus,
      required this.message,
      required this.recruiterID,
      required this.jobDescription,
      required this.jobType,
      required this.location,
      required this.companyName,
      required this.postedDate,
      required this.closeDate,
      required this.skillList});

  @override
  final String hiringId;
  @override
  final String companyRespondStatus;
  @override
  final String message;
  @override
  final String recruiterID;
  @override
  final String jobDescription;
  @override
  final String jobType;
  @override
  final String location;
  @override
  final String companyName;
  @override
  final String postedDate;
  @override
  final String closeDate;
  @override
  final KtList<String> skillList;

  @override
  String toString() {
    return 'GetAllAppliedVacanciesData(hiringId: $hiringId, companyRespondStatus: $companyRespondStatus, message: $message, recruiterID: $recruiterID, jobDescription: $jobDescription, jobType: $jobType, location: $location, companyName: $companyName, postedDate: $postedDate, closeDate: $closeDate, skillList: $skillList)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetAllAppliedVacanciesDataImpl &&
            (identical(other.hiringId, hiringId) ||
                other.hiringId == hiringId) &&
            (identical(other.companyRespondStatus, companyRespondStatus) ||
                other.companyRespondStatus == companyRespondStatus) &&
            (identical(other.message, message) || other.message == message) &&
            (identical(other.recruiterID, recruiterID) ||
                other.recruiterID == recruiterID) &&
            (identical(other.jobDescription, jobDescription) ||
                other.jobDescription == jobDescription) &&
            (identical(other.jobType, jobType) || other.jobType == jobType) &&
            (identical(other.location, location) ||
                other.location == location) &&
            (identical(other.companyName, companyName) ||
                other.companyName == companyName) &&
            (identical(other.postedDate, postedDate) ||
                other.postedDate == postedDate) &&
            (identical(other.closeDate, closeDate) ||
                other.closeDate == closeDate) &&
            (identical(other.skillList, skillList) ||
                other.skillList == skillList));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      hiringId,
      companyRespondStatus,
      message,
      recruiterID,
      jobDescription,
      jobType,
      location,
      companyName,
      postedDate,
      closeDate,
      skillList);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetAllAppliedVacanciesDataImplCopyWith<_$GetAllAppliedVacanciesDataImpl>
      get copyWith => __$$GetAllAppliedVacanciesDataImplCopyWithImpl<
          _$GetAllAppliedVacanciesDataImpl>(this, _$identity);
}

abstract class _GetAllAppliedVacanciesData
    implements GetAllAppliedVacanciesData {
  factory _GetAllAppliedVacanciesData(
          {required final String hiringId,
          required final String companyRespondStatus,
          required final String message,
          required final String recruiterID,
          required final String jobDescription,
          required final String jobType,
          required final String location,
          required final String companyName,
          required final String postedDate,
          required final String closeDate,
          required final KtList<String> skillList}) =
      _$GetAllAppliedVacanciesDataImpl;

  @override
  String get hiringId;
  @override
  String get companyRespondStatus;
  @override
  String get message;
  @override
  String get recruiterID;
  @override
  String get jobDescription;
  @override
  String get jobType;
  @override
  String get location;
  @override
  String get companyName;
  @override
  String get postedDate;
  @override
  String get closeDate;
  @override
  KtList<String> get skillList;
  @override
  @JsonKey(ignore: true)
  _$$GetAllAppliedVacanciesDataImplCopyWith<_$GetAllAppliedVacanciesDataImpl>
      get copyWith => throw _privateConstructorUsedError;
}
