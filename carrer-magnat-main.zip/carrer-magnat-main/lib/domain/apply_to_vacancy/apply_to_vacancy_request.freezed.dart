// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'apply_to_vacancy_request.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$ApplyToVacancyRequest {
  String get userID => throw _privateConstructorUsedError;
  String get hiringAnnouncementID => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $ApplyToVacancyRequestCopyWith<ApplyToVacancyRequest> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ApplyToVacancyRequestCopyWith<$Res> {
  factory $ApplyToVacancyRequestCopyWith(ApplyToVacancyRequest value,
          $Res Function(ApplyToVacancyRequest) then) =
      _$ApplyToVacancyRequestCopyWithImpl<$Res, ApplyToVacancyRequest>;
  @useResult
  $Res call({String userID, String hiringAnnouncementID});
}

/// @nodoc
class _$ApplyToVacancyRequestCopyWithImpl<$Res,
        $Val extends ApplyToVacancyRequest>
    implements $ApplyToVacancyRequestCopyWith<$Res> {
  _$ApplyToVacancyRequestCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? userID = null,
    Object? hiringAnnouncementID = null,
  }) {
    return _then(_value.copyWith(
      userID: null == userID
          ? _value.userID
          : userID // ignore: cast_nullable_to_non_nullable
              as String,
      hiringAnnouncementID: null == hiringAnnouncementID
          ? _value.hiringAnnouncementID
          : hiringAnnouncementID // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ApplyToVacancyRequestImplCopyWith<$Res>
    implements $ApplyToVacancyRequestCopyWith<$Res> {
  factory _$$ApplyToVacancyRequestImplCopyWith(
          _$ApplyToVacancyRequestImpl value,
          $Res Function(_$ApplyToVacancyRequestImpl) then) =
      __$$ApplyToVacancyRequestImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String userID, String hiringAnnouncementID});
}

/// @nodoc
class __$$ApplyToVacancyRequestImplCopyWithImpl<$Res>
    extends _$ApplyToVacancyRequestCopyWithImpl<$Res,
        _$ApplyToVacancyRequestImpl>
    implements _$$ApplyToVacancyRequestImplCopyWith<$Res> {
  __$$ApplyToVacancyRequestImplCopyWithImpl(_$ApplyToVacancyRequestImpl _value,
      $Res Function(_$ApplyToVacancyRequestImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? userID = null,
    Object? hiringAnnouncementID = null,
  }) {
    return _then(_$ApplyToVacancyRequestImpl(
      userID: null == userID
          ? _value.userID
          : userID // ignore: cast_nullable_to_non_nullable
              as String,
      hiringAnnouncementID: null == hiringAnnouncementID
          ? _value.hiringAnnouncementID
          : hiringAnnouncementID // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$ApplyToVacancyRequestImpl implements _ApplyToVacancyRequest {
  _$ApplyToVacancyRequestImpl(
      {required this.userID, required this.hiringAnnouncementID});

  @override
  final String userID;
  @override
  final String hiringAnnouncementID;

  @override
  String toString() {
    return 'ApplyToVacancyRequest(userID: $userID, hiringAnnouncementID: $hiringAnnouncementID)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ApplyToVacancyRequestImpl &&
            (identical(other.userID, userID) || other.userID == userID) &&
            (identical(other.hiringAnnouncementID, hiringAnnouncementID) ||
                other.hiringAnnouncementID == hiringAnnouncementID));
  }

  @override
  int get hashCode => Object.hash(runtimeType, userID, hiringAnnouncementID);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ApplyToVacancyRequestImplCopyWith<_$ApplyToVacancyRequestImpl>
      get copyWith => __$$ApplyToVacancyRequestImplCopyWithImpl<
          _$ApplyToVacancyRequestImpl>(this, _$identity);
}

abstract class _ApplyToVacancyRequest implements ApplyToVacancyRequest {
  factory _ApplyToVacancyRequest(
          {required final String userID,
          required final String hiringAnnouncementID}) =
      _$ApplyToVacancyRequestImpl;

  @override
  String get userID;
  @override
  String get hiringAnnouncementID;
  @override
  @JsonKey(ignore: true)
  _$$ApplyToVacancyRequestImplCopyWith<_$ApplyToVacancyRequestImpl>
      get copyWith => throw _privateConstructorUsedError;
}
