import 'package:freezed_annotation/freezed_annotation.dart';

part 'apply_to_vacancy_request.freezed.dart';

@freezed
class ApplyToVacancyRequest with _$ApplyToVacancyRequest {
  factory ApplyToVacancyRequest({
    required String userID,
    required String hiringAnnouncementID,
  }) = _ApplyToVacancyRequest;

  factory ApplyToVacancyRequest.empty() {
    return ApplyToVacancyRequest(
      userID: '',
      hiringAnnouncementID: '',
    );
  }
}
