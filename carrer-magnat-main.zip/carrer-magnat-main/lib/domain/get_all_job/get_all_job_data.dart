import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kt_dart/kt.dart';

part 'get_all_job_data.freezed.dart';

@freezed
class GetAllJobData with _$GetAllJobData {
  factory GetAllJobData({
    required String id,
    required String recruiterID,
    required String jobDescription,
    required String jobType,
    required String location,
    required String companyName,
    required String postedDate,
    required String closeDate,
    required KtList<String> skillList,
  }) = _GetAllJobData;

  factory GetAllJobData.empty() {
    return GetAllJobData(
      id: '',
      recruiterID: '',
      jobDescription: '',
      jobType: '',
      location: '',
      companyName: '',
      postedDate: '',
      closeDate: '',
      skillList: emptyList(),
    );
  }
}
