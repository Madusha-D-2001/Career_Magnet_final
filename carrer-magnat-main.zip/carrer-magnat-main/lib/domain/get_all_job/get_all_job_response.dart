import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kt_dart/kt.dart';

import 'get_all_job_data.dart';

part 'get_all_job_response.freezed.dart';

@freezed
class GetAllJobResponse with _$GetAllJobResponse {
  factory GetAllJobResponse({
    required int code,
    required String message,
    required KtList<GetAllJobData> data,
  }) = _GetAllJobResponse;

  factory GetAllJobResponse.empty() {
    return GetAllJobResponse(
      code: 0,
      message: '',
      data: emptyList(),
    );
  }
}
