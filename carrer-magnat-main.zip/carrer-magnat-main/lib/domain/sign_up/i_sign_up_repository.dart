import 'package:carrermagnet/domain/core/failure.dart';
import 'package:carrermagnet/domain/sign_up/sign_up_response.dart';
import 'package:carrermagnet/domain/sign_up/sign_up_resquest.dart';
import 'package:dartz/dartz.dart';

import 'reqruiter_sign_up_resquest.dart';
import 'user_sign_up_response.dart';

abstract class ISignUpRepository {
  // user signUp---------------------------
  Future<Either<Failure, UserSignUpResponse>> signUp(
      SignUpRequest signUpRequest);

  // recruiterSignUp -----------------------------
  Future<Either<Failure, SignUpResponse>> recruiterSignUp(
      ReqruiterSignUpResquest reqruiterSignUpResquest);
}
