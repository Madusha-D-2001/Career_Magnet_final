import 'package:freezed_annotation/freezed_annotation.dart';

part 'user_data.freezed.dart';

@freezed
class UserData with _$UserData {
  factory UserData({
    required String user_id,
    required String role,
    required String access_token,
    required String refresh_token,
  }) = _UserData;

  factory UserData.empty() {
    return UserData(
      user_id: '',
      role: '',
      access_token: '',
      refresh_token: '',
    );
  }
}
