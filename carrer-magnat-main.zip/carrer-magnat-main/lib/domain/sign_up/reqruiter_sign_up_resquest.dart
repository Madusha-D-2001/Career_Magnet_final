import 'package:freezed_annotation/freezed_annotation.dart';

part 'reqruiter_sign_up_resquest.freezed.dart';

@freezed
class ReqruiterSignUpResquest with _$ReqruiterSignUpResquest {
  factory ReqruiterSignUpResquest({
    required String first_name,
    required String last_name,
    required String email,
    required String contact,
    required String password,
    required String company,
  }) = _ReqruiterSignUpResquest;

  factory ReqruiterSignUpResquest.empty() {
    return ReqruiterSignUpResquest(
      first_name: '',
      last_name: '',
      email: '',
      contact: '',
      password: '',
      company: '',
    );
  }
}
