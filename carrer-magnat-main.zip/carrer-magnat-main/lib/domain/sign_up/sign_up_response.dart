import 'package:carrermagnet/domain/sign_up/data.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'sign_up_response.freezed.dart';

@freezed
class SignUpResponse with _$SignUpResponse {
  factory SignUpResponse({
    required int code,
    required String message,
    required Data data,
  }) = _SignUpResponse;

  factory SignUpResponse.empty() {
    return SignUpResponse(
      code: 0,
      message: '',
      data: Data.empty(),
    );
  }
}
