import 'package:freezed_annotation/freezed_annotation.dart';

part 'sign_up_resquest.freezed.dart';

@freezed
class SignUpRequest with _$SignUpRequest {
  factory SignUpRequest({
    required String first_name,
    required String last_name,
    required String email,
    required String contact,
    required String password,
  }) = _SignUpRequest;

  factory SignUpRequest.empty() {
    return SignUpRequest(
      first_name: '',
      last_name: '',
      email: '',
      contact: '',
      password: '',
    );
  }
}
