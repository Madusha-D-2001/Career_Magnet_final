// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'reqruiter_sign_up_resquest.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$ReqruiterSignUpResquest {
  String get first_name => throw _privateConstructorUsedError;
  String get last_name => throw _privateConstructorUsedError;
  String get email => throw _privateConstructorUsedError;
  String get contact => throw _privateConstructorUsedError;
  String get password => throw _privateConstructorUsedError;
  String get company => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $ReqruiterSignUpResquestCopyWith<ReqruiterSignUpResquest> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ReqruiterSignUpResquestCopyWith<$Res> {
  factory $ReqruiterSignUpResquestCopyWith(ReqruiterSignUpResquest value,
          $Res Function(ReqruiterSignUpResquest) then) =
      _$ReqruiterSignUpResquestCopyWithImpl<$Res, ReqruiterSignUpResquest>;
  @useResult
  $Res call(
      {String first_name,
      String last_name,
      String email,
      String contact,
      String password,
      String company});
}

/// @nodoc
class _$ReqruiterSignUpResquestCopyWithImpl<$Res,
        $Val extends ReqruiterSignUpResquest>
    implements $ReqruiterSignUpResquestCopyWith<$Res> {
  _$ReqruiterSignUpResquestCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? first_name = null,
    Object? last_name = null,
    Object? email = null,
    Object? contact = null,
    Object? password = null,
    Object? company = null,
  }) {
    return _then(_value.copyWith(
      first_name: null == first_name
          ? _value.first_name
          : first_name // ignore: cast_nullable_to_non_nullable
              as String,
      last_name: null == last_name
          ? _value.last_name
          : last_name // ignore: cast_nullable_to_non_nullable
              as String,
      email: null == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String,
      contact: null == contact
          ? _value.contact
          : contact // ignore: cast_nullable_to_non_nullable
              as String,
      password: null == password
          ? _value.password
          : password // ignore: cast_nullable_to_non_nullable
              as String,
      company: null == company
          ? _value.company
          : company // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ReqruiterSignUpResquestImplCopyWith<$Res>
    implements $ReqruiterSignUpResquestCopyWith<$Res> {
  factory _$$ReqruiterSignUpResquestImplCopyWith(
          _$ReqruiterSignUpResquestImpl value,
          $Res Function(_$ReqruiterSignUpResquestImpl) then) =
      __$$ReqruiterSignUpResquestImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String first_name,
      String last_name,
      String email,
      String contact,
      String password,
      String company});
}

/// @nodoc
class __$$ReqruiterSignUpResquestImplCopyWithImpl<$Res>
    extends _$ReqruiterSignUpResquestCopyWithImpl<$Res,
        _$ReqruiterSignUpResquestImpl>
    implements _$$ReqruiterSignUpResquestImplCopyWith<$Res> {
  __$$ReqruiterSignUpResquestImplCopyWithImpl(
      _$ReqruiterSignUpResquestImpl _value,
      $Res Function(_$ReqruiterSignUpResquestImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? first_name = null,
    Object? last_name = null,
    Object? email = null,
    Object? contact = null,
    Object? password = null,
    Object? company = null,
  }) {
    return _then(_$ReqruiterSignUpResquestImpl(
      first_name: null == first_name
          ? _value.first_name
          : first_name // ignore: cast_nullable_to_non_nullable
              as String,
      last_name: null == last_name
          ? _value.last_name
          : last_name // ignore: cast_nullable_to_non_nullable
              as String,
      email: null == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String,
      contact: null == contact
          ? _value.contact
          : contact // ignore: cast_nullable_to_non_nullable
              as String,
      password: null == password
          ? _value.password
          : password // ignore: cast_nullable_to_non_nullable
              as String,
      company: null == company
          ? _value.company
          : company // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$ReqruiterSignUpResquestImpl implements _ReqruiterSignUpResquest {
  _$ReqruiterSignUpResquestImpl(
      {required this.first_name,
      required this.last_name,
      required this.email,
      required this.contact,
      required this.password,
      required this.company});

  @override
  final String first_name;
  @override
  final String last_name;
  @override
  final String email;
  @override
  final String contact;
  @override
  final String password;
  @override
  final String company;

  @override
  String toString() {
    return 'ReqruiterSignUpResquest(first_name: $first_name, last_name: $last_name, email: $email, contact: $contact, password: $password, company: $company)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ReqruiterSignUpResquestImpl &&
            (identical(other.first_name, first_name) ||
                other.first_name == first_name) &&
            (identical(other.last_name, last_name) ||
                other.last_name == last_name) &&
            (identical(other.email, email) || other.email == email) &&
            (identical(other.contact, contact) || other.contact == contact) &&
            (identical(other.password, password) ||
                other.password == password) &&
            (identical(other.company, company) || other.company == company));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, first_name, last_name, email, contact, password, company);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ReqruiterSignUpResquestImplCopyWith<_$ReqruiterSignUpResquestImpl>
      get copyWith => __$$ReqruiterSignUpResquestImplCopyWithImpl<
          _$ReqruiterSignUpResquestImpl>(this, _$identity);
}

abstract class _ReqruiterSignUpResquest implements ReqruiterSignUpResquest {
  factory _ReqruiterSignUpResquest(
      {required final String first_name,
      required final String last_name,
      required final String email,
      required final String contact,
      required final String password,
      required final String company}) = _$ReqruiterSignUpResquestImpl;

  @override
  String get first_name;
  @override
  String get last_name;
  @override
  String get email;
  @override
  String get contact;
  @override
  String get password;
  @override
  String get company;
  @override
  @JsonKey(ignore: true)
  _$$ReqruiterSignUpResquestImplCopyWith<_$ReqruiterSignUpResquestImpl>
      get copyWith => throw _privateConstructorUsedError;
}
