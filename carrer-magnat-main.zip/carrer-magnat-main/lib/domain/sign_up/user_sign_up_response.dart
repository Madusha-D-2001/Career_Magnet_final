import 'package:freezed_annotation/freezed_annotation.dart';

import 'user_data.dart';

part 'user_sign_up_response.freezed.dart';

@freezed
class UserSignUpResponse with _$UserSignUpResponse {
  factory UserSignUpResponse({
    required int code,
    required String message,
    required UserData data,
  }) = _UserSignUpResponse;

  factory UserSignUpResponse.empty() {
    return UserSignUpResponse(
      code: 0,
      message: '',
      data: UserData.empty(),
    );
  }
}
