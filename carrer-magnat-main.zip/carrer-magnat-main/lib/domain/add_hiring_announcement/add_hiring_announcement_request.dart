import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kt_dart/kt.dart';

part 'add_hiring_announcement_request.freezed.dart';

@freezed
class AddHiringAnnouncementRequest with _$AddHiringAnnouncementRequest {
  factory AddHiringAnnouncementRequest({
    required String recruiterID,
    required String jobDescription,
    required String jobType,
    required String location,
    required String companyName,
    required DateTime postedDate,
    required DateTime closeDate,
    required KtList<String> skillList,
  }) = _AddHiringAnnouncementRequest;

  factory AddHiringAnnouncementRequest.empty() {
    return AddHiringAnnouncementRequest(
      recruiterID: '',
      jobDescription: '',
      jobType: '',
      location: '',
      companyName: '',
      postedDate: DateTime.now(),
      closeDate: DateTime.now(),
      skillList: emptyList(),
    );
  }
}
