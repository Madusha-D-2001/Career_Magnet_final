// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'add_hiring_announcement.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$AddHiringAnnouncement {
  String get recruiterID => throw _privateConstructorUsedError;
  String get jobDescription => throw _privateConstructorUsedError;
  String get jobType => throw _privateConstructorUsedError;
  String get location => throw _privateConstructorUsedError;
  String get companyName => throw _privateConstructorUsedError;
  String get postedDate => throw _privateConstructorUsedError;
  String get closeDate => throw _privateConstructorUsedError;
  List<dynamic> get skillList => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $AddHiringAnnouncementCopyWith<AddHiringAnnouncement> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AddHiringAnnouncementCopyWith<$Res> {
  factory $AddHiringAnnouncementCopyWith(AddHiringAnnouncement value,
          $Res Function(AddHiringAnnouncement) then) =
      _$AddHiringAnnouncementCopyWithImpl<$Res, AddHiringAnnouncement>;
  @useResult
  $Res call(
      {String recruiterID,
      String jobDescription,
      String jobType,
      String location,
      String companyName,
      String postedDate,
      String closeDate,
      List<dynamic> skillList});
}

/// @nodoc
class _$AddHiringAnnouncementCopyWithImpl<$Res,
        $Val extends AddHiringAnnouncement>
    implements $AddHiringAnnouncementCopyWith<$Res> {
  _$AddHiringAnnouncementCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? recruiterID = null,
    Object? jobDescription = null,
    Object? jobType = null,
    Object? location = null,
    Object? companyName = null,
    Object? postedDate = null,
    Object? closeDate = null,
    Object? skillList = null,
  }) {
    return _then(_value.copyWith(
      recruiterID: null == recruiterID
          ? _value.recruiterID
          : recruiterID // ignore: cast_nullable_to_non_nullable
              as String,
      jobDescription: null == jobDescription
          ? _value.jobDescription
          : jobDescription // ignore: cast_nullable_to_non_nullable
              as String,
      jobType: null == jobType
          ? _value.jobType
          : jobType // ignore: cast_nullable_to_non_nullable
              as String,
      location: null == location
          ? _value.location
          : location // ignore: cast_nullable_to_non_nullable
              as String,
      companyName: null == companyName
          ? _value.companyName
          : companyName // ignore: cast_nullable_to_non_nullable
              as String,
      postedDate: null == postedDate
          ? _value.postedDate
          : postedDate // ignore: cast_nullable_to_non_nullable
              as String,
      closeDate: null == closeDate
          ? _value.closeDate
          : closeDate // ignore: cast_nullable_to_non_nullable
              as String,
      skillList: null == skillList
          ? _value.skillList
          : skillList // ignore: cast_nullable_to_non_nullable
              as List<dynamic>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$AddHiringAnnouncementImplCopyWith<$Res>
    implements $AddHiringAnnouncementCopyWith<$Res> {
  factory _$$AddHiringAnnouncementImplCopyWith(
          _$AddHiringAnnouncementImpl value,
          $Res Function(_$AddHiringAnnouncementImpl) then) =
      __$$AddHiringAnnouncementImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String recruiterID,
      String jobDescription,
      String jobType,
      String location,
      String companyName,
      String postedDate,
      String closeDate,
      List<dynamic> skillList});
}

/// @nodoc
class __$$AddHiringAnnouncementImplCopyWithImpl<$Res>
    extends _$AddHiringAnnouncementCopyWithImpl<$Res,
        _$AddHiringAnnouncementImpl>
    implements _$$AddHiringAnnouncementImplCopyWith<$Res> {
  __$$AddHiringAnnouncementImplCopyWithImpl(_$AddHiringAnnouncementImpl _value,
      $Res Function(_$AddHiringAnnouncementImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? recruiterID = null,
    Object? jobDescription = null,
    Object? jobType = null,
    Object? location = null,
    Object? companyName = null,
    Object? postedDate = null,
    Object? closeDate = null,
    Object? skillList = null,
  }) {
    return _then(_$AddHiringAnnouncementImpl(
      recruiterID: null == recruiterID
          ? _value.recruiterID
          : recruiterID // ignore: cast_nullable_to_non_nullable
              as String,
      jobDescription: null == jobDescription
          ? _value.jobDescription
          : jobDescription // ignore: cast_nullable_to_non_nullable
              as String,
      jobType: null == jobType
          ? _value.jobType
          : jobType // ignore: cast_nullable_to_non_nullable
              as String,
      location: null == location
          ? _value.location
          : location // ignore: cast_nullable_to_non_nullable
              as String,
      companyName: null == companyName
          ? _value.companyName
          : companyName // ignore: cast_nullable_to_non_nullable
              as String,
      postedDate: null == postedDate
          ? _value.postedDate
          : postedDate // ignore: cast_nullable_to_non_nullable
              as String,
      closeDate: null == closeDate
          ? _value.closeDate
          : closeDate // ignore: cast_nullable_to_non_nullable
              as String,
      skillList: null == skillList
          ? _value._skillList
          : skillList // ignore: cast_nullable_to_non_nullable
              as List<dynamic>,
    ));
  }
}

/// @nodoc

class _$AddHiringAnnouncementImpl implements _AddHiringAnnouncement {
  _$AddHiringAnnouncementImpl(
      {required this.recruiterID,
      required this.jobDescription,
      required this.jobType,
      required this.location,
      required this.companyName,
      required this.postedDate,
      required this.closeDate,
      required final List<dynamic> skillList})
      : _skillList = skillList;

  @override
  final String recruiterID;
  @override
  final String jobDescription;
  @override
  final String jobType;
  @override
  final String location;
  @override
  final String companyName;
  @override
  final String postedDate;
  @override
  final String closeDate;
  final List<dynamic> _skillList;
  @override
  List<dynamic> get skillList {
    if (_skillList is EqualUnmodifiableListView) return _skillList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_skillList);
  }

  @override
  String toString() {
    return 'AddHiringAnnouncement(recruiterID: $recruiterID, jobDescription: $jobDescription, jobType: $jobType, location: $location, companyName: $companyName, postedDate: $postedDate, closeDate: $closeDate, skillList: $skillList)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$AddHiringAnnouncementImpl &&
            (identical(other.recruiterID, recruiterID) ||
                other.recruiterID == recruiterID) &&
            (identical(other.jobDescription, jobDescription) ||
                other.jobDescription == jobDescription) &&
            (identical(other.jobType, jobType) || other.jobType == jobType) &&
            (identical(other.location, location) ||
                other.location == location) &&
            (identical(other.companyName, companyName) ||
                other.companyName == companyName) &&
            (identical(other.postedDate, postedDate) ||
                other.postedDate == postedDate) &&
            (identical(other.closeDate, closeDate) ||
                other.closeDate == closeDate) &&
            const DeepCollectionEquality()
                .equals(other._skillList, _skillList));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      recruiterID,
      jobDescription,
      jobType,
      location,
      companyName,
      postedDate,
      closeDate,
      const DeepCollectionEquality().hash(_skillList));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$AddHiringAnnouncementImplCopyWith<_$AddHiringAnnouncementImpl>
      get copyWith => __$$AddHiringAnnouncementImplCopyWithImpl<
          _$AddHiringAnnouncementImpl>(this, _$identity);
}

abstract class _AddHiringAnnouncement implements AddHiringAnnouncement {
  factory _AddHiringAnnouncement(
      {required final String recruiterID,
      required final String jobDescription,
      required final String jobType,
      required final String location,
      required final String companyName,
      required final String postedDate,
      required final String closeDate,
      required final List<dynamic> skillList}) = _$AddHiringAnnouncementImpl;

  @override
  String get recruiterID;
  @override
  String get jobDescription;
  @override
  String get jobType;
  @override
  String get location;
  @override
  String get companyName;
  @override
  String get postedDate;
  @override
  String get closeDate;
  @override
  List<dynamic> get skillList;
  @override
  @JsonKey(ignore: true)
  _$$AddHiringAnnouncementImplCopyWith<_$AddHiringAnnouncementImpl>
      get copyWith => throw _privateConstructorUsedError;
}
