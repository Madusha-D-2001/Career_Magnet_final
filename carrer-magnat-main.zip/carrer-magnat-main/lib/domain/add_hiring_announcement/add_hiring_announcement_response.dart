import 'package:freezed_annotation/freezed_annotation.dart';

part 'add_hiring_announcement_response.freezed.dart';

@freezed
class AddHiringAnnouncementResponse with _$AddHiringAnnouncementResponse {
  factory AddHiringAnnouncementResponse({
    required int code,
    required String message,
    required bool data,
  }) = _AddHiringAnnouncementResponse;

  factory AddHiringAnnouncementResponse.empty() {
    return AddHiringAnnouncementResponse(
      code: 0,
      message: '',
      data: false,
    );
  }
}
