import 'package:freezed_annotation/freezed_annotation.dart';

part 'add_hiring_announcement.freezed.dart';

@freezed
class AddHiringAnnouncement with _$AddHiringAnnouncement {
  factory AddHiringAnnouncement({
    required String recruiterID,
    required String jobDescription,
    required String jobType,
    required String location,
    required String companyName,
    required String postedDate,
    required String closeDate,
    required List skillList,
  }) = _AddHiringAnnouncement;

  factory AddHiringAnnouncement.empty() {
    return AddHiringAnnouncement(
      recruiterID: '',
      jobDescription: '',
      jobType: '',
      location: '',
      companyName: '',
      postedDate: '',
      closeDate: '',
      skillList: [],
    );
  }
}
