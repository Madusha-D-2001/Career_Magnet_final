import 'package:carrermagnet/domain/core/failure.dart';
import 'package:carrermagnet/domain/login/login_request.dart';
import 'package:carrermagnet/domain/login/login_response.dart';
import 'package:dartz/dartz.dart';

abstract class ILoginRepository {
  Future<Either<Failure, LoginResponse>> login(LoginRequest loginRequest);
}
