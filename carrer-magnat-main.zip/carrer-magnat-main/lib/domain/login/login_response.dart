import 'package:carrermagnet/domain/login/data.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'login_response.freezed.dart';

@freezed
class LoginResponse with _$LoginResponse {
  factory LoginResponse({
    required int code,
    required String message,
    required Data data,
  }) = _LoginResponse;

  factory LoginResponse.empty() {
    return LoginResponse(
      code: 0,
      message: '',
      data: Data.empty(),
    );
  }
}
