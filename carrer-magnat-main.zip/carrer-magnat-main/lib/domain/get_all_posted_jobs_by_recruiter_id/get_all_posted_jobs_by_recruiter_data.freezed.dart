// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'get_all_posted_jobs_by_recruiter_data.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$GetAllPostedJobsByRecruiterData {
  String get id => throw _privateConstructorUsedError;
  String get recruiterID => throw _privateConstructorUsedError;
  String get jobDescription => throw _privateConstructorUsedError;
  String get jobType => throw _privateConstructorUsedError;
  String get location => throw _privateConstructorUsedError;
  String get companyName => throw _privateConstructorUsedError;
  String get postedDate => throw _privateConstructorUsedError;
  String get closeDate => throw _privateConstructorUsedError;
  KtList<String> get skillList => throw _privateConstructorUsedError;
  bool get selectedStatus => throw _privateConstructorUsedError;
  String get selectedUserProfile => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $GetAllPostedJobsByRecruiterDataCopyWith<GetAllPostedJobsByRecruiterData>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GetAllPostedJobsByRecruiterDataCopyWith<$Res> {
  factory $GetAllPostedJobsByRecruiterDataCopyWith(
          GetAllPostedJobsByRecruiterData value,
          $Res Function(GetAllPostedJobsByRecruiterData) then) =
      _$GetAllPostedJobsByRecruiterDataCopyWithImpl<$Res,
          GetAllPostedJobsByRecruiterData>;
  @useResult
  $Res call(
      {String id,
      String recruiterID,
      String jobDescription,
      String jobType,
      String location,
      String companyName,
      String postedDate,
      String closeDate,
      KtList<String> skillList,
      bool selectedStatus,
      String selectedUserProfile});
}

/// @nodoc
class _$GetAllPostedJobsByRecruiterDataCopyWithImpl<$Res,
        $Val extends GetAllPostedJobsByRecruiterData>
    implements $GetAllPostedJobsByRecruiterDataCopyWith<$Res> {
  _$GetAllPostedJobsByRecruiterDataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? recruiterID = null,
    Object? jobDescription = null,
    Object? jobType = null,
    Object? location = null,
    Object? companyName = null,
    Object? postedDate = null,
    Object? closeDate = null,
    Object? skillList = null,
    Object? selectedStatus = null,
    Object? selectedUserProfile = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      recruiterID: null == recruiterID
          ? _value.recruiterID
          : recruiterID // ignore: cast_nullable_to_non_nullable
              as String,
      jobDescription: null == jobDescription
          ? _value.jobDescription
          : jobDescription // ignore: cast_nullable_to_non_nullable
              as String,
      jobType: null == jobType
          ? _value.jobType
          : jobType // ignore: cast_nullable_to_non_nullable
              as String,
      location: null == location
          ? _value.location
          : location // ignore: cast_nullable_to_non_nullable
              as String,
      companyName: null == companyName
          ? _value.companyName
          : companyName // ignore: cast_nullable_to_non_nullable
              as String,
      postedDate: null == postedDate
          ? _value.postedDate
          : postedDate // ignore: cast_nullable_to_non_nullable
              as String,
      closeDate: null == closeDate
          ? _value.closeDate
          : closeDate // ignore: cast_nullable_to_non_nullable
              as String,
      skillList: null == skillList
          ? _value.skillList
          : skillList // ignore: cast_nullable_to_non_nullable
              as KtList<String>,
      selectedStatus: null == selectedStatus
          ? _value.selectedStatus
          : selectedStatus // ignore: cast_nullable_to_non_nullable
              as bool,
      selectedUserProfile: null == selectedUserProfile
          ? _value.selectedUserProfile
          : selectedUserProfile // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$GetAllPostedJobsByRecruiterDataImplCopyWith<$Res>
    implements $GetAllPostedJobsByRecruiterDataCopyWith<$Res> {
  factory _$$GetAllPostedJobsByRecruiterDataImplCopyWith(
          _$GetAllPostedJobsByRecruiterDataImpl value,
          $Res Function(_$GetAllPostedJobsByRecruiterDataImpl) then) =
      __$$GetAllPostedJobsByRecruiterDataImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String recruiterID,
      String jobDescription,
      String jobType,
      String location,
      String companyName,
      String postedDate,
      String closeDate,
      KtList<String> skillList,
      bool selectedStatus,
      String selectedUserProfile});
}

/// @nodoc
class __$$GetAllPostedJobsByRecruiterDataImplCopyWithImpl<$Res>
    extends _$GetAllPostedJobsByRecruiterDataCopyWithImpl<$Res,
        _$GetAllPostedJobsByRecruiterDataImpl>
    implements _$$GetAllPostedJobsByRecruiterDataImplCopyWith<$Res> {
  __$$GetAllPostedJobsByRecruiterDataImplCopyWithImpl(
      _$GetAllPostedJobsByRecruiterDataImpl _value,
      $Res Function(_$GetAllPostedJobsByRecruiterDataImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? recruiterID = null,
    Object? jobDescription = null,
    Object? jobType = null,
    Object? location = null,
    Object? companyName = null,
    Object? postedDate = null,
    Object? closeDate = null,
    Object? skillList = null,
    Object? selectedStatus = null,
    Object? selectedUserProfile = null,
  }) {
    return _then(_$GetAllPostedJobsByRecruiterDataImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      recruiterID: null == recruiterID
          ? _value.recruiterID
          : recruiterID // ignore: cast_nullable_to_non_nullable
              as String,
      jobDescription: null == jobDescription
          ? _value.jobDescription
          : jobDescription // ignore: cast_nullable_to_non_nullable
              as String,
      jobType: null == jobType
          ? _value.jobType
          : jobType // ignore: cast_nullable_to_non_nullable
              as String,
      location: null == location
          ? _value.location
          : location // ignore: cast_nullable_to_non_nullable
              as String,
      companyName: null == companyName
          ? _value.companyName
          : companyName // ignore: cast_nullable_to_non_nullable
              as String,
      postedDate: null == postedDate
          ? _value.postedDate
          : postedDate // ignore: cast_nullable_to_non_nullable
              as String,
      closeDate: null == closeDate
          ? _value.closeDate
          : closeDate // ignore: cast_nullable_to_non_nullable
              as String,
      skillList: null == skillList
          ? _value.skillList
          : skillList // ignore: cast_nullable_to_non_nullable
              as KtList<String>,
      selectedStatus: null == selectedStatus
          ? _value.selectedStatus
          : selectedStatus // ignore: cast_nullable_to_non_nullable
              as bool,
      selectedUserProfile: null == selectedUserProfile
          ? _value.selectedUserProfile
          : selectedUserProfile // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$GetAllPostedJobsByRecruiterDataImpl
    implements _GetAllPostedJobsByRecruiterData {
  _$GetAllPostedJobsByRecruiterDataImpl(
      {required this.id,
      required this.recruiterID,
      required this.jobDescription,
      required this.jobType,
      required this.location,
      required this.companyName,
      required this.postedDate,
      required this.closeDate,
      required this.skillList,
      required this.selectedStatus,
      required this.selectedUserProfile});

  @override
  final String id;
  @override
  final String recruiterID;
  @override
  final String jobDescription;
  @override
  final String jobType;
  @override
  final String location;
  @override
  final String companyName;
  @override
  final String postedDate;
  @override
  final String closeDate;
  @override
  final KtList<String> skillList;
  @override
  final bool selectedStatus;
  @override
  final String selectedUserProfile;

  @override
  String toString() {
    return 'GetAllPostedJobsByRecruiterData(id: $id, recruiterID: $recruiterID, jobDescription: $jobDescription, jobType: $jobType, location: $location, companyName: $companyName, postedDate: $postedDate, closeDate: $closeDate, skillList: $skillList, selectedStatus: $selectedStatus, selectedUserProfile: $selectedUserProfile)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetAllPostedJobsByRecruiterDataImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.recruiterID, recruiterID) ||
                other.recruiterID == recruiterID) &&
            (identical(other.jobDescription, jobDescription) ||
                other.jobDescription == jobDescription) &&
            (identical(other.jobType, jobType) || other.jobType == jobType) &&
            (identical(other.location, location) ||
                other.location == location) &&
            (identical(other.companyName, companyName) ||
                other.companyName == companyName) &&
            (identical(other.postedDate, postedDate) ||
                other.postedDate == postedDate) &&
            (identical(other.closeDate, closeDate) ||
                other.closeDate == closeDate) &&
            (identical(other.skillList, skillList) ||
                other.skillList == skillList) &&
            (identical(other.selectedStatus, selectedStatus) ||
                other.selectedStatus == selectedStatus) &&
            (identical(other.selectedUserProfile, selectedUserProfile) ||
                other.selectedUserProfile == selectedUserProfile));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      recruiterID,
      jobDescription,
      jobType,
      location,
      companyName,
      postedDate,
      closeDate,
      skillList,
      selectedStatus,
      selectedUserProfile);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetAllPostedJobsByRecruiterDataImplCopyWith<
          _$GetAllPostedJobsByRecruiterDataImpl>
      get copyWith => __$$GetAllPostedJobsByRecruiterDataImplCopyWithImpl<
          _$GetAllPostedJobsByRecruiterDataImpl>(this, _$identity);
}

abstract class _GetAllPostedJobsByRecruiterData
    implements GetAllPostedJobsByRecruiterData {
  factory _GetAllPostedJobsByRecruiterData(
          {required final String id,
          required final String recruiterID,
          required final String jobDescription,
          required final String jobType,
          required final String location,
          required final String companyName,
          required final String postedDate,
          required final String closeDate,
          required final KtList<String> skillList,
          required final bool selectedStatus,
          required final String selectedUserProfile}) =
      _$GetAllPostedJobsByRecruiterDataImpl;

  @override
  String get id;
  @override
  String get recruiterID;
  @override
  String get jobDescription;
  @override
  String get jobType;
  @override
  String get location;
  @override
  String get companyName;
  @override
  String get postedDate;
  @override
  String get closeDate;
  @override
  KtList<String> get skillList;
  @override
  bool get selectedStatus;
  @override
  String get selectedUserProfile;
  @override
  @JsonKey(ignore: true)
  _$$GetAllPostedJobsByRecruiterDataImplCopyWith<
          _$GetAllPostedJobsByRecruiterDataImpl>
      get copyWith => throw _privateConstructorUsedError;
}
