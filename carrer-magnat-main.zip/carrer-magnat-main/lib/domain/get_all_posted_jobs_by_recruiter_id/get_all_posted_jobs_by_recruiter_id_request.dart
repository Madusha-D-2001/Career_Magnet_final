import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kt_dart/kt.dart';

import 'get_all_posted_jobs_by_recruiter_data.dart';

part 'get_all_posted_jobs_by_recruiter_id_request.freezed.dart';

@freezed
class GetAllPostedJobsByRecruiterIdRequest
    with _$GetAllPostedJobsByRecruiterIdRequest {
  factory GetAllPostedJobsByRecruiterIdRequest({
    required int code,
    required String message,
    required KtList<GetAllPostedJobsByRecruiterData> data,
  }) = _GetAllPostedJobsByRecruiterIdRequest;

  factory GetAllPostedJobsByRecruiterIdRequest.empty() {
    return GetAllPostedJobsByRecruiterIdRequest(
      code: 0,
      message: '',
      data: emptyList(),
    );
  }
}
