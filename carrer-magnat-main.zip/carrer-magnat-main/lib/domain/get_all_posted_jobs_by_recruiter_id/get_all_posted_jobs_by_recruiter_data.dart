import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kt_dart/kt.dart';

part 'get_all_posted_jobs_by_recruiter_data.freezed.dart';

@freezed
class GetAllPostedJobsByRecruiterData with _$GetAllPostedJobsByRecruiterData {
  factory GetAllPostedJobsByRecruiterData({
    required String id,
    required String recruiterID,
    required String jobDescription,
    required String jobType,
    required String location,
    required String companyName,
    required String postedDate,
    required String closeDate,
    required KtList<String> skillList,
    required bool selectedStatus,
    required String selectedUserProfile,
  }) = _GetAllPostedJobsByRecruiterData;

  factory GetAllPostedJobsByRecruiterData.empty() {
    return GetAllPostedJobsByRecruiterData(
      id: '',
      recruiterID: '',
      jobDescription: '',
      jobType: '',
      location: '',
      companyName: '',
      postedDate: '',
      closeDate: '',
      skillList: emptyList(),
      selectedStatus: false,
      selectedUserProfile: '',
    );
  }
}
