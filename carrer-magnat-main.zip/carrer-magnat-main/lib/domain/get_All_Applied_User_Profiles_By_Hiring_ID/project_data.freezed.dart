// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'project_data.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$ProjectData {
  String get project_id => throw _privateConstructorUsedError;
  String get project_name => throw _privateConstructorUsedError;
  String get description => throw _privateConstructorUsedError;
  KtList<String> get used_skills => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $ProjectDataCopyWith<ProjectData> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProjectDataCopyWith<$Res> {
  factory $ProjectDataCopyWith(
          ProjectData value, $Res Function(ProjectData) then) =
      _$ProjectDataCopyWithImpl<$Res, ProjectData>;
  @useResult
  $Res call(
      {String project_id,
      String project_name,
      String description,
      KtList<String> used_skills});
}

/// @nodoc
class _$ProjectDataCopyWithImpl<$Res, $Val extends ProjectData>
    implements $ProjectDataCopyWith<$Res> {
  _$ProjectDataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? project_id = null,
    Object? project_name = null,
    Object? description = null,
    Object? used_skills = null,
  }) {
    return _then(_value.copyWith(
      project_id: null == project_id
          ? _value.project_id
          : project_id // ignore: cast_nullable_to_non_nullable
              as String,
      project_name: null == project_name
          ? _value.project_name
          : project_name // ignore: cast_nullable_to_non_nullable
              as String,
      description: null == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String,
      used_skills: null == used_skills
          ? _value.used_skills
          : used_skills // ignore: cast_nullable_to_non_nullable
              as KtList<String>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ProjectDataImplCopyWith<$Res>
    implements $ProjectDataCopyWith<$Res> {
  factory _$$ProjectDataImplCopyWith(
          _$ProjectDataImpl value, $Res Function(_$ProjectDataImpl) then) =
      __$$ProjectDataImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String project_id,
      String project_name,
      String description,
      KtList<String> used_skills});
}

/// @nodoc
class __$$ProjectDataImplCopyWithImpl<$Res>
    extends _$ProjectDataCopyWithImpl<$Res, _$ProjectDataImpl>
    implements _$$ProjectDataImplCopyWith<$Res> {
  __$$ProjectDataImplCopyWithImpl(
      _$ProjectDataImpl _value, $Res Function(_$ProjectDataImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? project_id = null,
    Object? project_name = null,
    Object? description = null,
    Object? used_skills = null,
  }) {
    return _then(_$ProjectDataImpl(
      project_id: null == project_id
          ? _value.project_id
          : project_id // ignore: cast_nullable_to_non_nullable
              as String,
      project_name: null == project_name
          ? _value.project_name
          : project_name // ignore: cast_nullable_to_non_nullable
              as String,
      description: null == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String,
      used_skills: null == used_skills
          ? _value.used_skills
          : used_skills // ignore: cast_nullable_to_non_nullable
              as KtList<String>,
    ));
  }
}

/// @nodoc

class _$ProjectDataImpl implements _ProjectData {
  _$ProjectDataImpl(
      {required this.project_id,
      required this.project_name,
      required this.description,
      required this.used_skills});

  @override
  final String project_id;
  @override
  final String project_name;
  @override
  final String description;
  @override
  final KtList<String> used_skills;

  @override
  String toString() {
    return 'ProjectData(project_id: $project_id, project_name: $project_name, description: $description, used_skills: $used_skills)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ProjectDataImpl &&
            (identical(other.project_id, project_id) ||
                other.project_id == project_id) &&
            (identical(other.project_name, project_name) ||
                other.project_name == project_name) &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.used_skills, used_skills) ||
                other.used_skills == used_skills));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, project_id, project_name, description, used_skills);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ProjectDataImplCopyWith<_$ProjectDataImpl> get copyWith =>
      __$$ProjectDataImplCopyWithImpl<_$ProjectDataImpl>(this, _$identity);
}

abstract class _ProjectData implements ProjectData {
  factory _ProjectData(
      {required final String project_id,
      required final String project_name,
      required final String description,
      required final KtList<String> used_skills}) = _$ProjectDataImpl;

  @override
  String get project_id;
  @override
  String get project_name;
  @override
  String get description;
  @override
  KtList<String> get used_skills;
  @override
  @JsonKey(ignore: true)
  _$$ProjectDataImplCopyWith<_$ProjectDataImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
