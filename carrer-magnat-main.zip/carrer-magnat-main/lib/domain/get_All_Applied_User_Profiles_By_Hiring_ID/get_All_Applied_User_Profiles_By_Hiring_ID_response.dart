import 'package:carrermagnet/domain/get_All_Applied_User_Profiles_By_Hiring_ID/get_All_Applied_User_Profiles_By_Hiring_ID_data.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kt_dart/kt.dart';

part 'get_All_Applied_User_Profiles_By_Hiring_ID_response.freezed.dart';

@freezed
class GetAllAppliedUserProfilesByHiringIdResponse
    with _$GetAllAppliedUserProfilesByHiringIdResponse {
  factory GetAllAppliedUserProfilesByHiringIdResponse({
    required int code,
    required String message,
    required KtList<GetAllAppliedUserProfilesByHiringIdData> data,
  }) = _GetAllAppliedUserProfilesByHiringIdResponse;

  factory GetAllAppliedUserProfilesByHiringIdResponse.empty() {
    return GetAllAppliedUserProfilesByHiringIdResponse(
      code: 0,
      message: '',
      data: emptyList(),
    );
  }
}
