import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kt_dart/kt.dart';

part 'project_data.freezed.dart';

@freezed
class ProjectData with _$ProjectData {
  factory ProjectData({
    required String project_id,
    required String project_name,
    required String description,
    required KtList<String> used_skills,
  }) = _ProjectData;

  factory ProjectData.empty() {
    return ProjectData(
      project_id: '',
      project_name: '',
      description: '',
      used_skills: emptyList(),
    );
  }
}
