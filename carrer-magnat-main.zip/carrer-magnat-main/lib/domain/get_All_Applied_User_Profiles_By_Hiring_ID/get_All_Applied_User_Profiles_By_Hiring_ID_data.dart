import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kt_dart/kt.dart';

import 'project_data.dart';

part 'get_All_Applied_User_Profiles_By_Hiring_ID_data.freezed.dart';

@freezed
class GetAllAppliedUserProfilesByHiringIdData
    with _$GetAllAppliedUserProfilesByHiringIdData {
  factory GetAllAppliedUserProfilesByHiringIdData({
    required String user_id,
    required String userProfileID,
    required String first_name,
    required String last_name,
    required String fullName,
    required String address,
    required String birthDay,
    required String email,
    required String contact,
    required String profileInfo,
    required String education,
    required String university,
    required String position,
    required KtList<String> skillList,
    required KtList<ProjectData> projectDTOS,
  }) = _GetAllAppliedUserProfilesByHiringIdData;

  factory GetAllAppliedUserProfilesByHiringIdData.empty() {
    return GetAllAppliedUserProfilesByHiringIdData(
      user_id: '',
      userProfileID: '',
      first_name: '',
      last_name: '',
      fullName: '',
      address: '',
      birthDay: '',
      email: '',
      contact: '',
      profileInfo: '',
      education: '',
      university: '',
      position: '',
      skillList: emptyList(),
      projectDTOS: emptyList(),
    );
  }
}
