import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kt_dart/kt.dart';

import 'user_projects_data.dart';

part 'get_user_profile_data.freezed.dart';

@freezed
class GetUserProfileData with _$GetUserProfileData {
  factory GetUserProfileData({
    required String user_id,
    required String userProfileID,
    required String first_name,
    required String last_name,
    required String fullName,
    required String address,
    required DateTime birthDay,
    required String email,
    required String contact,
    required String profileInfo,
    required String education,
    required String university,
    required String position,
    required KtList skillList,
    required KtList<UserProjectsData> projectDTOS,
  }) = _GetUserProfileData;

  factory GetUserProfileData.empty() {
    return GetUserProfileData(
      user_id: '',
      userProfileID: '',
      first_name: '',
      last_name: '',
      fullName: '',
      address: '',
      birthDay: DateTime(2, 2, 3),
      email: '',
      contact: '',
      profileInfo: '',
      education: '',
      university: '',
      position: '',
      skillList: emptyList(),
      projectDTOS: emptyList(),
    );
  }
}
