// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'user_projects_data.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$UserProjectsData {
  String get project_id => throw _privateConstructorUsedError;
  String get project_name => throw _privateConstructorUsedError;
  String get description => throw _privateConstructorUsedError;
  KtList<String> get used_skills => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $UserProjectsDataCopyWith<UserProjectsData> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $UserProjectsDataCopyWith<$Res> {
  factory $UserProjectsDataCopyWith(
          UserProjectsData value, $Res Function(UserProjectsData) then) =
      _$UserProjectsDataCopyWithImpl<$Res, UserProjectsData>;
  @useResult
  $Res call(
      {String project_id,
      String project_name,
      String description,
      KtList<String> used_skills});
}

/// @nodoc
class _$UserProjectsDataCopyWithImpl<$Res, $Val extends UserProjectsData>
    implements $UserProjectsDataCopyWith<$Res> {
  _$UserProjectsDataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? project_id = null,
    Object? project_name = null,
    Object? description = null,
    Object? used_skills = null,
  }) {
    return _then(_value.copyWith(
      project_id: null == project_id
          ? _value.project_id
          : project_id // ignore: cast_nullable_to_non_nullable
              as String,
      project_name: null == project_name
          ? _value.project_name
          : project_name // ignore: cast_nullable_to_non_nullable
              as String,
      description: null == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String,
      used_skills: null == used_skills
          ? _value.used_skills
          : used_skills // ignore: cast_nullable_to_non_nullable
              as KtList<String>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$UserProjectsDataImplCopyWith<$Res>
    implements $UserProjectsDataCopyWith<$Res> {
  factory _$$UserProjectsDataImplCopyWith(_$UserProjectsDataImpl value,
          $Res Function(_$UserProjectsDataImpl) then) =
      __$$UserProjectsDataImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String project_id,
      String project_name,
      String description,
      KtList<String> used_skills});
}

/// @nodoc
class __$$UserProjectsDataImplCopyWithImpl<$Res>
    extends _$UserProjectsDataCopyWithImpl<$Res, _$UserProjectsDataImpl>
    implements _$$UserProjectsDataImplCopyWith<$Res> {
  __$$UserProjectsDataImplCopyWithImpl(_$UserProjectsDataImpl _value,
      $Res Function(_$UserProjectsDataImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? project_id = null,
    Object? project_name = null,
    Object? description = null,
    Object? used_skills = null,
  }) {
    return _then(_$UserProjectsDataImpl(
      project_id: null == project_id
          ? _value.project_id
          : project_id // ignore: cast_nullable_to_non_nullable
              as String,
      project_name: null == project_name
          ? _value.project_name
          : project_name // ignore: cast_nullable_to_non_nullable
              as String,
      description: null == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String,
      used_skills: null == used_skills
          ? _value.used_skills
          : used_skills // ignore: cast_nullable_to_non_nullable
              as KtList<String>,
    ));
  }
}

/// @nodoc

class _$UserProjectsDataImpl implements _UserProjectsData {
  _$UserProjectsDataImpl(
      {required this.project_id,
      required this.project_name,
      required this.description,
      required this.used_skills});

  @override
  final String project_id;
  @override
  final String project_name;
  @override
  final String description;
  @override
  final KtList<String> used_skills;

  @override
  String toString() {
    return 'UserProjectsData(project_id: $project_id, project_name: $project_name, description: $description, used_skills: $used_skills)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$UserProjectsDataImpl &&
            (identical(other.project_id, project_id) ||
                other.project_id == project_id) &&
            (identical(other.project_name, project_name) ||
                other.project_name == project_name) &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.used_skills, used_skills) ||
                other.used_skills == used_skills));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, project_id, project_name, description, used_skills);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$UserProjectsDataImplCopyWith<_$UserProjectsDataImpl> get copyWith =>
      __$$UserProjectsDataImplCopyWithImpl<_$UserProjectsDataImpl>(
          this, _$identity);
}

abstract class _UserProjectsData implements UserProjectsData {
  factory _UserProjectsData(
      {required final String project_id,
      required final String project_name,
      required final String description,
      required final KtList<String> used_skills}) = _$UserProjectsDataImpl;

  @override
  String get project_id;
  @override
  String get project_name;
  @override
  String get description;
  @override
  KtList<String> get used_skills;
  @override
  @JsonKey(ignore: true)
  _$$UserProjectsDataImplCopyWith<_$UserProjectsDataImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
