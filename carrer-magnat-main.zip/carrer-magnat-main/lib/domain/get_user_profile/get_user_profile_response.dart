import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kt_dart/kt.dart';

import 'get_user_profile_data.dart';

part 'get_user_profile_response.freezed.dart';

@freezed
class GetUserProfileResponse with _$GetUserProfileResponse {
  factory GetUserProfileResponse({
    required int code,
    required String message,
    required GetUserProfileData data,
  }) = _GetUserProfileResponse;

  factory GetUserProfileResponse.empty() {
    return GetUserProfileResponse(
      code: 0,
      message: '',
      data: GetUserProfileData.empty(),
    );
  }
}
