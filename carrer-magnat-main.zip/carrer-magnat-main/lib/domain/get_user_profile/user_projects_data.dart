import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kt_dart/kt.dart';

part 'user_projects_data.freezed.dart';

@freezed
class UserProjectsData with _$UserProjectsData {
  factory UserProjectsData({
    required String project_id,
    required String project_name,
    required String description,
    required KtList<String> used_skills,
  }) = _UserProjectsData;

  factory UserProjectsData.empty() {
    return UserProjectsData(
      project_id: '',
      project_name: '',
      description: '',
      used_skills: emptyList(),
    );
  }
}
