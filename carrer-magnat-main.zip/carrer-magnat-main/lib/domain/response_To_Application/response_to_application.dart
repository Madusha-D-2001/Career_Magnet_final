import 'package:freezed_annotation/freezed_annotation.dart';

part 'response_to_application.freezed.dart';

@freezed
class ResponseToApplication with _$ResponseToApplication {
  factory ResponseToApplication({
    required String hiringID,
    required String userID,
    required String companyRespondStatus,
    required String message,
  }) = _ResponseToApplication;

  factory ResponseToApplication.empty() {
    return ResponseToApplication(
      hiringID: '',
      userID: '',
      companyRespondStatus: '',
      message: '',
    );
  }
}
