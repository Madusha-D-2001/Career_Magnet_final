import 'package:carrermagnet/domain/add_hiring_announcement/add_hiring_announcement_response.dart';
import 'package:dartz/dartz.dart';

import '../add_hiring_announcement/add_hiring_announcement_request.dart';
import '../core/failure.dart';
import '../get_All_Applied_User_Profiles_By_Hiring_ID/get_All_Applied_User_Profiles_By_Hiring_ID_response.dart';
import '../get_all_posted_jobs_by_recruiter_id/get_all_posted_jobs_by_recruiter_id_request.dart';
import '../response_To_Application/response_to_application.dart';

abstract class IRecruiterRepository {
  // addHiringAnnouncement -----------------------------------------------------
  Future<Either<Failure, AddHiringAnnouncementResponse>> addHiringAnnouncement(
      AddHiringAnnouncementRequest addHiringAnnouncementRequest);

  // get All PostedJobs By Recruiter ID ----------------------------------------

  Future<Either<Failure, GetAllPostedJobsByRecruiterIdRequest>>
      getAllPostedJobsByRecruiterID(String recruiterID);

  // delete  Hiring Announcement -----------------------------------------------

  Future<Either<Failure, AddHiringAnnouncementResponse>>
      deleteHiringAnnouncement(String hiringID);

  // get All Applied User Profiles By Hiring ID -----------------------------------------------

  Future<Either<Failure, GetAllAppliedUserProfilesByHiringIdResponse>>
      getAllAppliedUserProfilesByHiringID(String hiringID);

  //send Response  -------------------------------------------------------------

  Future<Either<Failure, AddHiringAnnouncementResponse>> sendReponse(
      ResponseToApplication responseToApplication);
}
