import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kt_dart/kt.dart';

import 'search_jobs_response_data.dart';

part 'search_jobs_response.freezed.dart';

@freezed
class SearchJobsResponse with _$SearchJobsResponse {
  factory SearchJobsResponse({
    required int code,
    required String message,
    required KtList<SearchJobsResponseData> data,
  }) = _SearchJobsResponse;

  factory SearchJobsResponse.empty() {
    return SearchJobsResponse(
      code: 0,
      message: '',
      data: emptyList(),
    );
  }
}
