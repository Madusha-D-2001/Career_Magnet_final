// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'search_jobs_request.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$SearchJobsRequest {
  String get jobType => throw _privateConstructorUsedError;
  String get location => throw _privateConstructorUsedError;
  String get companyName => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $SearchJobsRequestCopyWith<SearchJobsRequest> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SearchJobsRequestCopyWith<$Res> {
  factory $SearchJobsRequestCopyWith(
          SearchJobsRequest value, $Res Function(SearchJobsRequest) then) =
      _$SearchJobsRequestCopyWithImpl<$Res, SearchJobsRequest>;
  @useResult
  $Res call({String jobType, String location, String companyName});
}

/// @nodoc
class _$SearchJobsRequestCopyWithImpl<$Res, $Val extends SearchJobsRequest>
    implements $SearchJobsRequestCopyWith<$Res> {
  _$SearchJobsRequestCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? jobType = null,
    Object? location = null,
    Object? companyName = null,
  }) {
    return _then(_value.copyWith(
      jobType: null == jobType
          ? _value.jobType
          : jobType // ignore: cast_nullable_to_non_nullable
              as String,
      location: null == location
          ? _value.location
          : location // ignore: cast_nullable_to_non_nullable
              as String,
      companyName: null == companyName
          ? _value.companyName
          : companyName // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$SearchJobsRequestImplCopyWith<$Res>
    implements $SearchJobsRequestCopyWith<$Res> {
  factory _$$SearchJobsRequestImplCopyWith(_$SearchJobsRequestImpl value,
          $Res Function(_$SearchJobsRequestImpl) then) =
      __$$SearchJobsRequestImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String jobType, String location, String companyName});
}

/// @nodoc
class __$$SearchJobsRequestImplCopyWithImpl<$Res>
    extends _$SearchJobsRequestCopyWithImpl<$Res, _$SearchJobsRequestImpl>
    implements _$$SearchJobsRequestImplCopyWith<$Res> {
  __$$SearchJobsRequestImplCopyWithImpl(_$SearchJobsRequestImpl _value,
      $Res Function(_$SearchJobsRequestImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? jobType = null,
    Object? location = null,
    Object? companyName = null,
  }) {
    return _then(_$SearchJobsRequestImpl(
      jobType: null == jobType
          ? _value.jobType
          : jobType // ignore: cast_nullable_to_non_nullable
              as String,
      location: null == location
          ? _value.location
          : location // ignore: cast_nullable_to_non_nullable
              as String,
      companyName: null == companyName
          ? _value.companyName
          : companyName // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$SearchJobsRequestImpl implements _SearchJobsRequest {
  _$SearchJobsRequestImpl(
      {required this.jobType,
      required this.location,
      required this.companyName});

  @override
  final String jobType;
  @override
  final String location;
  @override
  final String companyName;

  @override
  String toString() {
    return 'SearchJobsRequest(jobType: $jobType, location: $location, companyName: $companyName)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SearchJobsRequestImpl &&
            (identical(other.jobType, jobType) || other.jobType == jobType) &&
            (identical(other.location, location) ||
                other.location == location) &&
            (identical(other.companyName, companyName) ||
                other.companyName == companyName));
  }

  @override
  int get hashCode => Object.hash(runtimeType, jobType, location, companyName);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SearchJobsRequestImplCopyWith<_$SearchJobsRequestImpl> get copyWith =>
      __$$SearchJobsRequestImplCopyWithImpl<_$SearchJobsRequestImpl>(
          this, _$identity);
}

abstract class _SearchJobsRequest implements SearchJobsRequest {
  factory _SearchJobsRequest(
      {required final String jobType,
      required final String location,
      required final String companyName}) = _$SearchJobsRequestImpl;

  @override
  String get jobType;
  @override
  String get location;
  @override
  String get companyName;
  @override
  @JsonKey(ignore: true)
  _$$SearchJobsRequestImplCopyWith<_$SearchJobsRequestImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
