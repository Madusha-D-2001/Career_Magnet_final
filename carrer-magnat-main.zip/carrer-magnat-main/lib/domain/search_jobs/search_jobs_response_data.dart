import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kt_dart/kt.dart';

part 'search_jobs_response_data.freezed.dart';

@freezed
class SearchJobsResponseData with _$SearchJobsResponseData {
  factory SearchJobsResponseData({
    required String id,
    required String recruiterID,
    required String jobDescription,
    required String jobType,
    required String location,
    required String companyName,
    required String postedDate,
    required String closeDate,
    required KtList<String> skillList,
  }) = _SearchJobsResponseData;

  factory SearchJobsResponseData.empty() {
    return SearchJobsResponseData(
      id: '',
      recruiterID: '',
      jobDescription: '',
      jobType: '',
      location: '',
      companyName: '',
      postedDate: '',
      closeDate: '',
      skillList: emptyList(),
    );
  }
}
