import 'package:freezed_annotation/freezed_annotation.dart';

part 'search_jobs_request.freezed.dart';

@freezed
class SearchJobsRequest with _$SearchJobsRequest {
  factory SearchJobsRequest({
    required String jobType,
    required String location,
    required String companyName,
  }) = _SearchJobsRequest;

  factory SearchJobsRequest.empty() {
    return SearchJobsRequest(
      jobType: '',
      location: '',
      companyName: '',
    );
  }
}
