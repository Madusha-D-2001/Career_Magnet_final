import 'package:carrermagnet/domain/add_hiring_announcement/add_hiring_announcement.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'add_hiring_announcement_dto.freezed.dart';
part 'add_hiring_announcement_dto.g.dart';

@freezed
class AddHiringAnnouncementDto with _$AddHiringAnnouncementDto {
  factory AddHiringAnnouncementDto({
    required String recruiterID,
    required String jobDescription,
    required String jobType,
    required String location,
    required String companyName,
    required String postedDate,
    required String closeDate,
    required List skillList,
  }) = _AddHiringAnnouncementDto;

  factory AddHiringAnnouncementDto.fromJson(Map<String, dynamic> json) =>
      _$AddHiringAnnouncementDtoFromJson(json);

  factory AddHiringAnnouncementDto.fromDomain(AddHiringAnnouncement domain) {
    return AddHiringAnnouncementDto(
      recruiterID: domain.recruiterID,
      jobDescription: domain.jobDescription,
      jobType: domain.jobType,
      location: domain.location,
      companyName: domain.companyName,
      postedDate: domain.postedDate,
      closeDate: domain.closeDate,
      skillList: domain.skillList,
    );
  }

  const AddHiringAnnouncementDto._();

  AddHiringAnnouncement toDomain() {
    return AddHiringAnnouncement(
      recruiterID: recruiterID,
      jobDescription: jobDescription,
      jobType: jobType,
      location: location,
      companyName: companyName,
      postedDate: postedDate,
      closeDate: closeDate,
      skillList: skillList,
    );
  }
}
