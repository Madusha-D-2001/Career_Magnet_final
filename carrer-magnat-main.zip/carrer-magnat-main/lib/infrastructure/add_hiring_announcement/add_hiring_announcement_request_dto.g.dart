// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'add_hiring_announcement_request_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$AddHiringAnnouncementRequestDtoImpl
    _$$AddHiringAnnouncementRequestDtoImplFromJson(Map<String, dynamic> json) =>
        _$AddHiringAnnouncementRequestDtoImpl(
          recruiterID: json['recruiterID'] as String,
          jobDescription: json['jobDescription'] as String,
          jobType: json['jobType'] as String,
          location: json['location'] as String,
          companyName: json['companyName'] as String,
          postedDate: DateTime.parse(json['postedDate'] as String),
          closeDate: DateTime.parse(json['closeDate'] as String),
          skillList: (json['skillList'] as List<dynamic>)
              .map((e) => e as String)
              .toList(),
        );

Map<String, dynamic> _$$AddHiringAnnouncementRequestDtoImplToJson(
        _$AddHiringAnnouncementRequestDtoImpl instance) =>
    <String, dynamic>{
      'recruiterID': instance.recruiterID,
      'jobDescription': instance.jobDescription,
      'jobType': instance.jobType,
      'location': instance.location,
      'companyName': instance.companyName,
      'postedDate': instance.postedDate.toIso8601String(),
      'closeDate': instance.closeDate.toIso8601String(),
      'skillList': instance.skillList,
    };
