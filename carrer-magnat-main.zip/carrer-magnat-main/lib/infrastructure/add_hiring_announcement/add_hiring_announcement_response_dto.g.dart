// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'add_hiring_announcement_response_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$AddHiringAnnouncementResponseDtoImpl
    _$$AddHiringAnnouncementResponseDtoImplFromJson(
            Map<String, dynamic> json) =>
        _$AddHiringAnnouncementResponseDtoImpl(
          code: (json['code'] as num).toInt(),
          message: json['message'] as String,
          data: json['data'] as bool,
        );

Map<String, dynamic> _$$AddHiringAnnouncementResponseDtoImplToJson(
        _$AddHiringAnnouncementResponseDtoImpl instance) =>
    <String, dynamic>{
      'code': instance.code,
      'message': instance.message,
      'data': instance.data,
    };
