// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'add_hiring_announcement_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$AddHiringAnnouncementDtoImpl _$$AddHiringAnnouncementDtoImplFromJson(
        Map<String, dynamic> json) =>
    _$AddHiringAnnouncementDtoImpl(
      recruiterID: json['recruiterID'] as String,
      jobDescription: json['jobDescription'] as String,
      jobType: json['jobType'] as String,
      location: json['location'] as String,
      companyName: json['companyName'] as String,
      postedDate: json['postedDate'] as String,
      closeDate: json['closeDate'] as String,
      skillList: json['skillList'] as List<dynamic>,
    );

Map<String, dynamic> _$$AddHiringAnnouncementDtoImplToJson(
        _$AddHiringAnnouncementDtoImpl instance) =>
    <String, dynamic>{
      'recruiterID': instance.recruiterID,
      'jobDescription': instance.jobDescription,
      'jobType': instance.jobType,
      'location': instance.location,
      'companyName': instance.companyName,
      'postedDate': instance.postedDate,
      'closeDate': instance.closeDate,
      'skillList': instance.skillList,
    };
