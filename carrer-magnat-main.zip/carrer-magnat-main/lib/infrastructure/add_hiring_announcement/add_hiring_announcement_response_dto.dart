import 'package:carrermagnet/domain/add_hiring_announcement/add_hiring_announcement_response.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'add_hiring_announcement_response_dto.freezed.dart';
part 'add_hiring_announcement_response_dto.g.dart';

@freezed
class AddHiringAnnouncementResponseDto with _$AddHiringAnnouncementResponseDto {
  factory AddHiringAnnouncementResponseDto({
    required int code,
    required String message,
    required bool data,
  }) = _AddHiringAnnouncementResponseDto;

  factory AddHiringAnnouncementResponseDto.fromJson(
          Map<String, dynamic> json) =>
      _$AddHiringAnnouncementResponseDtoFromJson(json);

  factory AddHiringAnnouncementResponseDto.fromDomain(
      AddHiringAnnouncementResponse domain) {
    return AddHiringAnnouncementResponseDto(
      code: domain.code,
      message: domain.message,
      data: domain.data,
    );
  }

  const AddHiringAnnouncementResponseDto._();

  AddHiringAnnouncementResponse toDomain() {
    return AddHiringAnnouncementResponse(
      code: code,
      message: message,
      data: data,
    );
  }
}
