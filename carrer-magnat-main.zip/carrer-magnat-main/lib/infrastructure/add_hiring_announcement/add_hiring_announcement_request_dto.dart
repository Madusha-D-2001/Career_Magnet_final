import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kt_dart/kt.dart';

import '../../domain/add_hiring_announcement/add_hiring_announcement_request.dart';

part 'add_hiring_announcement_request_dto.freezed.dart';
part 'add_hiring_announcement_request_dto.g.dart';

@freezed
class AddHiringAnnouncementRequestDto with _$AddHiringAnnouncementRequestDto {
  factory AddHiringAnnouncementRequestDto({
    required String recruiterID,
    required String jobDescription,
    required String jobType,
    required String location,
    required String companyName,
    required DateTime postedDate,
    required DateTime closeDate,
    required List<String> skillList,
  }) = _AddHiringAnnouncementRequestDto;

  factory AddHiringAnnouncementRequestDto.fromJson(Map<String, dynamic> json) =>
      _$AddHiringAnnouncementRequestDtoFromJson(json);

  factory AddHiringAnnouncementRequestDto.fromDomain(
      AddHiringAnnouncementRequest domain) {
    return AddHiringAnnouncementRequestDto(
      recruiterID: domain.recruiterID,
      jobDescription: domain.jobDescription,
      jobType: domain.jobType,
      location: domain.location,
      companyName: domain.companyName,
      postedDate: domain.postedDate,
      closeDate: domain.closeDate,
      skillList: domain.skillList.asList(),
    );
  }

  const AddHiringAnnouncementRequestDto._();

  AddHiringAnnouncementRequest toDomain() {
    return AddHiringAnnouncementRequest(
      recruiterID: recruiterID,
      jobDescription: jobDescription,
      jobType: jobType,
      location: location,
      companyName: companyName,
      postedDate: postedDate,
      closeDate: closeDate,
      skillList: skillList.toImmutableList(),
    );
  }
}
