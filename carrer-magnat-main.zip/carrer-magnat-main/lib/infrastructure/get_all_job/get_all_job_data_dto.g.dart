// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'get_all_job_data_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$GetAllJobDataDtoImpl _$$GetAllJobDataDtoImplFromJson(
        Map<String, dynamic> json) =>
    _$GetAllJobDataDtoImpl(
      id: json['id'] as String,
      recruiterID: json['recruiterID'] as String,
      jobDescription: json['jobDescription'] as String,
      jobType: json['jobType'] as String,
      location: json['location'] as String,
      companyName: json['companyName'] as String,
      postedDate: json['postedDate'] as String,
      closeDate: json['closeDate'] as String,
      skillList:
          (json['skillList'] as List<dynamic>).map((e) => e as String).toList(),
    );

Map<String, dynamic> _$$GetAllJobDataDtoImplToJson(
        _$GetAllJobDataDtoImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'recruiterID': instance.recruiterID,
      'jobDescription': instance.jobDescription,
      'jobType': instance.jobType,
      'location': instance.location,
      'companyName': instance.companyName,
      'postedDate': instance.postedDate,
      'closeDate': instance.closeDate,
      'skillList': instance.skillList,
    };
