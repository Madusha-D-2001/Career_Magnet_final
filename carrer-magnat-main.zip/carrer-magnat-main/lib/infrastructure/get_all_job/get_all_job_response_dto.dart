import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kt_dart/kt.dart';

import '../../domain/get_all_job/get_all_job_response.dart';
import 'get_all_job_data_dto.dart';

part 'get_all_job_response_dto.freezed.dart';
part 'get_all_job_response_dto.g.dart';

@freezed
class GetAllJobResponseDto with _$GetAllJobResponseDto {
  factory GetAllJobResponseDto({
    required int code,
    required String message,
    required List<GetAllJobDataDto> data,
  }) = _GetAllJobResponseDto;

  factory GetAllJobResponseDto.fromJson(Map<String, dynamic> json) =>
      _$GetAllJobResponseDtoFromJson(json);

  factory GetAllJobResponseDto.fromDomain(GetAllJobResponse domain) {
    return GetAllJobResponseDto(
      code: domain.code,
      message: domain.message,
      data: domain.data.map((p) => GetAllJobDataDto.fromDomain(p)).asList(),
    );
  }

  const GetAllJobResponseDto._();

  GetAllJobResponse toDomain() {
    return GetAllJobResponse(
      code: code,
      message: message,
      data: data.map((p) => p.toDomain()).toImmutableList(),
    );
  }
}
