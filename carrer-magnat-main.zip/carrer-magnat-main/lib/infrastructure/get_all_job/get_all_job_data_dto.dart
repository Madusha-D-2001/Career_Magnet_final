import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kt_dart/kt.dart';

import '../../domain/get_all_job/get_all_job_data.dart';

part 'get_all_job_data_dto.freezed.dart';
part 'get_all_job_data_dto.g.dart';

@freezed
class GetAllJobDataDto with _$GetAllJobDataDto {
  factory GetAllJobDataDto({
    required String id,
    required String recruiterID,
    required String jobDescription,
    required String jobType,
    required String location,
    required String companyName,
    required String postedDate,
    required String closeDate,
    required List<String> skillList,
  }) = _GetAllJobDataDto;

  factory GetAllJobDataDto.fromJson(Map<String, dynamic> json) =>
      _$GetAllJobDataDtoFromJson(json);

  const GetAllJobDataDto._();

  factory GetAllJobDataDto.fromDomain(GetAllJobData domain) {
    return GetAllJobDataDto(
      id: domain.id,
      recruiterID: domain.recruiterID,
      jobDescription: domain.jobDescription,
      jobType: domain.jobType,
      location: domain.location,
      companyName: domain.companyName,
      postedDate: domain.postedDate,
      closeDate: domain.closeDate,
      skillList: domain.skillList.asList(),
    );
  }

  GetAllJobData toDomain() {
    return GetAllJobData(
      id: id,
      recruiterID: recruiterID,
      jobDescription: jobDescription,
      jobType: jobType,
      location: location,
      companyName: companyName,
      postedDate: postedDate,
      closeDate: closeDate,
      skillList: skillList.toImmutableList(),
    );
  }
}
