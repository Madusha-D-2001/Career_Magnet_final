// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'get_all_job_response_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$GetAllJobResponseDtoImpl _$$GetAllJobResponseDtoImplFromJson(
        Map<String, dynamic> json) =>
    _$GetAllJobResponseDtoImpl(
      code: (json['code'] as num).toInt(),
      message: json['message'] as String,
      data: (json['data'] as List<dynamic>)
          .map((e) => GetAllJobDataDto.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$GetAllJobResponseDtoImplToJson(
        _$GetAllJobResponseDtoImpl instance) =>
    <String, dynamic>{
      'code': instance.code,
      'message': instance.message,
      'data': instance.data,
    };
