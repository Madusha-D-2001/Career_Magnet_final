// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'get_user_profile_response_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$GetUserPrfileResponseDtoImpl _$$GetUserPrfileResponseDtoImplFromJson(
        Map<String, dynamic> json) =>
    _$GetUserPrfileResponseDtoImpl(
      code: (json['code'] as num).toInt(),
      message: json['message'] as String,
      data:
          GetUserProfileDataDto.fromJson(json['data'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$$GetUserPrfileResponseDtoImplToJson(
        _$GetUserPrfileResponseDtoImpl instance) =>
    <String, dynamic>{
      'code': instance.code,
      'message': instance.message,
      'data': instance.data,
    };
