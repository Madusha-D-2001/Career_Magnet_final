import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kt_dart/kt.dart';

import '../../domain/get_user_profile/get_user_profile_data.dart';
import 'user_projects_data_dto.dart';

part 'get_user_profile_data_dto.freezed.dart';
part 'get_user_profile_data_dto.g.dart';

@freezed
class GetUserProfileDataDto with _$GetUserProfileDataDto {
  factory GetUserProfileDataDto({
    required String user_id,
    required String userProfileID,
    required String first_name,
    required String last_name,
    required String fullName,
    required String address,
    required DateTime birthDay,
    required String email,
    required String contact,
    required String profileInfo,
    required String education,
    required String university,
    required String position,
    required List skillList,
    required List<UserProjectsDataDto> projectDTOS,
  }) = _GetUserProfileDataDto;

  factory GetUserProfileDataDto.fromJson(Map<String, dynamic> json) =>
      _$GetUserProfileDataDtoFromJson(json);

  const GetUserProfileDataDto._();

  factory GetUserProfileDataDto.fromDomain(GetUserProfileData domain) {
    return GetUserProfileDataDto(
      user_id: domain.user_id,
      userProfileID: domain.userProfileID,
      first_name: domain.first_name,
      last_name: domain.last_name,
      fullName: domain.fullName,
      address: domain.address,
      birthDay: domain.birthDay,
      email: domain.email,
      contact: domain.contact,
      profileInfo: domain.profileInfo,
      education: domain.education,
      university: domain.university,
      position: domain.position,
      skillList: domain.skillList.asList(),
      projectDTOS: domain.projectDTOS
          .map((p) => UserProjectsDataDto.fromDomain(p))
          .asList(),
    );
  }

  GetUserProfileData toDomain() {
    return GetUserProfileData(
      user_id: user_id,
      userProfileID: userProfileID,
      first_name: first_name,
      last_name: last_name,
      fullName: fullName,
      address: address,
      birthDay: birthDay,
      email: email,
      contact: contact,
      profileInfo: profileInfo,
      education: education,
      university: university,
      position: position,
      skillList: skillList.toImmutableList(),
      projectDTOS: projectDTOS.map((p) => p.toDomain()).toImmutableList(),
    );
  }
}
