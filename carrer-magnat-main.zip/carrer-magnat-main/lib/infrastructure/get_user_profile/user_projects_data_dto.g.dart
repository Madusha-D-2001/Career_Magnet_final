// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'user_projects_data_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$UserProjectsDataDtoImpl _$$UserProjectsDataDtoImplFromJson(
        Map<String, dynamic> json) =>
    _$UserProjectsDataDtoImpl(
      project_id: json['project_id'] as String,
      project_name: json['project_name'] as String,
      description: json['description'] as String,
      used_skills: (json['used_skills'] as List<dynamic>)
          .map((e) => e as String)
          .toList(),
    );

Map<String, dynamic> _$$UserProjectsDataDtoImplToJson(
        _$UserProjectsDataDtoImpl instance) =>
    <String, dynamic>{
      'project_id': instance.project_id,
      'project_name': instance.project_name,
      'description': instance.description,
      'used_skills': instance.used_skills,
    };
