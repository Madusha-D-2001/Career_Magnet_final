import 'package:carrermagnet/domain/get_user_profile/get_user_profile_response.dart';

import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kt_dart/kt.dart';

import 'get_user_profile_data_dto.dart';

part 'get_user_profile_response_dto.freezed.dart';
part 'get_user_profile_response_dto.g.dart';

@freezed
class GetUserPrfileResponseDto with _$GetUserPrfileResponseDto {
  factory GetUserPrfileResponseDto({
    required int code,
    required String message,
    required GetUserProfileDataDto data,
  }) = _GetUserPrfileResponseDto;

  factory GetUserPrfileResponseDto.fromJson(Map<String, dynamic> json) =>
      _$GetUserPrfileResponseDtoFromJson(json);

  const GetUserPrfileResponseDto._();

  factory GetUserPrfileResponseDto.fromDomain(GetUserProfileResponse domain) {
    return GetUserPrfileResponseDto(
      code: domain.code,
      message: domain.message,
      data: GetUserProfileDataDto.fromDomain(domain.data),
    );
  }

  GetUserProfileResponse toDomain() {
    return GetUserProfileResponse(
      code: code,
      message: message,
      data: data.toDomain(),
    );
  }
}
