// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'get_user_profile_data_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$GetUserProfileDataDtoImpl _$$GetUserProfileDataDtoImplFromJson(
        Map<String, dynamic> json) =>
    _$GetUserProfileDataDtoImpl(
      user_id: json['user_id'] as String,
      userProfileID: json['userProfileID'] as String,
      first_name: json['first_name'] as String,
      last_name: json['last_name'] as String,
      fullName: json['fullName'] as String,
      address: json['address'] as String,
      birthDay: DateTime.parse(json['birthDay'] as String),
      email: json['email'] as String,
      contact: json['contact'] as String,
      profileInfo: json['profileInfo'] as String,
      education: json['education'] as String,
      university: json['university'] as String,
      position: json['position'] as String,
      skillList: json['skillList'] as List<dynamic>,
      projectDTOS: (json['projectDTOS'] as List<dynamic>)
          .map((e) => UserProjectsDataDto.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$GetUserProfileDataDtoImplToJson(
        _$GetUserProfileDataDtoImpl instance) =>
    <String, dynamic>{
      'user_id': instance.user_id,
      'userProfileID': instance.userProfileID,
      'first_name': instance.first_name,
      'last_name': instance.last_name,
      'fullName': instance.fullName,
      'address': instance.address,
      'birthDay': instance.birthDay.toIso8601String(),
      'email': instance.email,
      'contact': instance.contact,
      'profileInfo': instance.profileInfo,
      'education': instance.education,
      'university': instance.university,
      'position': instance.position,
      'skillList': instance.skillList,
      'projectDTOS': instance.projectDTOS,
    };
