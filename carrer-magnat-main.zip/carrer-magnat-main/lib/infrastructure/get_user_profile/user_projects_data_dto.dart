import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kt_dart/kt.dart';

import '../../domain/get_user_profile/user_projects_data.dart';

part 'user_projects_data_dto.freezed.dart';
part 'user_projects_data_dto.g.dart';

@freezed
class UserProjectsDataDto with _$UserProjectsDataDto {
  factory UserProjectsDataDto({
    required String project_id,
    required String project_name,
    required String description,
    required List<String> used_skills,
  }) = _UserProjectsDataDto;

  factory UserProjectsDataDto.fromJson(Map<String, dynamic> json) =>
      _$UserProjectsDataDtoFromJson(json);

  factory UserProjectsDataDto.fromDomain(UserProjectsData domain) {
    return UserProjectsDataDto(
      project_id: domain.project_id,
      project_name: domain.project_name,
      description: domain.description,
      used_skills: domain.used_skills.asList(),
    );
  }

  const UserProjectsDataDto._();

  UserProjectsData toDomain() {
    return UserProjectsData(
      project_id: project_id,
      project_name: project_name,
      description: description,
      used_skills: used_skills.toImmutableList(),
    );
  }
}
