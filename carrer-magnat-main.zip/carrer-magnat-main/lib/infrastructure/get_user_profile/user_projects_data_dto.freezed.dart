// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'user_projects_data_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

UserProjectsDataDto _$UserProjectsDataDtoFromJson(Map<String, dynamic> json) {
  return _UserProjectsDataDto.fromJson(json);
}

/// @nodoc
mixin _$UserProjectsDataDto {
  String get project_id => throw _privateConstructorUsedError;
  String get project_name => throw _privateConstructorUsedError;
  String get description => throw _privateConstructorUsedError;
  List<String> get used_skills => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $UserProjectsDataDtoCopyWith<UserProjectsDataDto> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $UserProjectsDataDtoCopyWith<$Res> {
  factory $UserProjectsDataDtoCopyWith(
          UserProjectsDataDto value, $Res Function(UserProjectsDataDto) then) =
      _$UserProjectsDataDtoCopyWithImpl<$Res, UserProjectsDataDto>;
  @useResult
  $Res call(
      {String project_id,
      String project_name,
      String description,
      List<String> used_skills});
}

/// @nodoc
class _$UserProjectsDataDtoCopyWithImpl<$Res, $Val extends UserProjectsDataDto>
    implements $UserProjectsDataDtoCopyWith<$Res> {
  _$UserProjectsDataDtoCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? project_id = null,
    Object? project_name = null,
    Object? description = null,
    Object? used_skills = null,
  }) {
    return _then(_value.copyWith(
      project_id: null == project_id
          ? _value.project_id
          : project_id // ignore: cast_nullable_to_non_nullable
              as String,
      project_name: null == project_name
          ? _value.project_name
          : project_name // ignore: cast_nullable_to_non_nullable
              as String,
      description: null == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String,
      used_skills: null == used_skills
          ? _value.used_skills
          : used_skills // ignore: cast_nullable_to_non_nullable
              as List<String>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$UserProjectsDataDtoImplCopyWith<$Res>
    implements $UserProjectsDataDtoCopyWith<$Res> {
  factory _$$UserProjectsDataDtoImplCopyWith(_$UserProjectsDataDtoImpl value,
          $Res Function(_$UserProjectsDataDtoImpl) then) =
      __$$UserProjectsDataDtoImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String project_id,
      String project_name,
      String description,
      List<String> used_skills});
}

/// @nodoc
class __$$UserProjectsDataDtoImplCopyWithImpl<$Res>
    extends _$UserProjectsDataDtoCopyWithImpl<$Res, _$UserProjectsDataDtoImpl>
    implements _$$UserProjectsDataDtoImplCopyWith<$Res> {
  __$$UserProjectsDataDtoImplCopyWithImpl(_$UserProjectsDataDtoImpl _value,
      $Res Function(_$UserProjectsDataDtoImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? project_id = null,
    Object? project_name = null,
    Object? description = null,
    Object? used_skills = null,
  }) {
    return _then(_$UserProjectsDataDtoImpl(
      project_id: null == project_id
          ? _value.project_id
          : project_id // ignore: cast_nullable_to_non_nullable
              as String,
      project_name: null == project_name
          ? _value.project_name
          : project_name // ignore: cast_nullable_to_non_nullable
              as String,
      description: null == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String,
      used_skills: null == used_skills
          ? _value._used_skills
          : used_skills // ignore: cast_nullable_to_non_nullable
              as List<String>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$UserProjectsDataDtoImpl extends _UserProjectsDataDto {
  _$UserProjectsDataDtoImpl(
      {required this.project_id,
      required this.project_name,
      required this.description,
      required final List<String> used_skills})
      : _used_skills = used_skills,
        super._();

  factory _$UserProjectsDataDtoImpl.fromJson(Map<String, dynamic> json) =>
      _$$UserProjectsDataDtoImplFromJson(json);

  @override
  final String project_id;
  @override
  final String project_name;
  @override
  final String description;
  final List<String> _used_skills;
  @override
  List<String> get used_skills {
    if (_used_skills is EqualUnmodifiableListView) return _used_skills;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_used_skills);
  }

  @override
  String toString() {
    return 'UserProjectsDataDto(project_id: $project_id, project_name: $project_name, description: $description, used_skills: $used_skills)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$UserProjectsDataDtoImpl &&
            (identical(other.project_id, project_id) ||
                other.project_id == project_id) &&
            (identical(other.project_name, project_name) ||
                other.project_name == project_name) &&
            (identical(other.description, description) ||
                other.description == description) &&
            const DeepCollectionEquality()
                .equals(other._used_skills, _used_skills));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, project_id, project_name,
      description, const DeepCollectionEquality().hash(_used_skills));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$UserProjectsDataDtoImplCopyWith<_$UserProjectsDataDtoImpl> get copyWith =>
      __$$UserProjectsDataDtoImplCopyWithImpl<_$UserProjectsDataDtoImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$UserProjectsDataDtoImplToJson(
      this,
    );
  }
}

abstract class _UserProjectsDataDto extends UserProjectsDataDto {
  factory _UserProjectsDataDto(
      {required final String project_id,
      required final String project_name,
      required final String description,
      required final List<String> used_skills}) = _$UserProjectsDataDtoImpl;
  _UserProjectsDataDto._() : super._();

  factory _UserProjectsDataDto.fromJson(Map<String, dynamic> json) =
      _$UserProjectsDataDtoImpl.fromJson;

  @override
  String get project_id;
  @override
  String get project_name;
  @override
  String get description;
  @override
  List<String> get used_skills;
  @override
  @JsonKey(ignore: true)
  _$$UserProjectsDataDtoImplCopyWith<_$UserProjectsDataDtoImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
