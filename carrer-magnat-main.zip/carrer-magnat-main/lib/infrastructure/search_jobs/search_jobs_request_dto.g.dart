// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'search_jobs_request_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$SearchJobsRequestDtoImpl _$$SearchJobsRequestDtoImplFromJson(
        Map<String, dynamic> json) =>
    _$SearchJobsRequestDtoImpl(
      jobType: json['jobType'] as String,
      location: json['location'] as String,
      companyName: json['companyName'] as String,
    );

Map<String, dynamic> _$$SearchJobsRequestDtoImplToJson(
        _$SearchJobsRequestDtoImpl instance) =>
    <String, dynamic>{
      'jobType': instance.jobType,
      'location': instance.location,
      'companyName': instance.companyName,
    };
