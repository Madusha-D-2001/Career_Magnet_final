import 'package:freezed_annotation/freezed_annotation.dart';

import '../../domain/search_jobs/search_jobs_request.dart';

part 'search_jobs_request_dto.freezed.dart';
part 'search_jobs_request_dto.g.dart';

@freezed
class SearchJobsRequestDto with _$SearchJobsRequestDto {
  factory SearchJobsRequestDto({
    required String jobType,
    required String location,
    required String companyName,
  }) = _SearchJobsRequestDto;

  factory SearchJobsRequestDto.fromJson(Map<String, dynamic> json) =>
      _$SearchJobsRequestDtoFromJson(json);

  factory SearchJobsRequestDto.fromDomain(SearchJobsRequest domain) {
    return SearchJobsRequestDto(
      jobType: domain.jobType,
      location: domain.location,
      companyName: domain.companyName,
    );
  }

  const SearchJobsRequestDto._();

  SearchJobsRequest toDomain() {
    return SearchJobsRequest(
      jobType: jobType,
      location: location,
      companyName: companyName,
    );
  }
}
