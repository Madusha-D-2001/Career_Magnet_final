// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'search_jobs_response_data_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$SearchJobsResponseDataDtoImpl _$$SearchJobsResponseDataDtoImplFromJson(
        Map<String, dynamic> json) =>
    _$SearchJobsResponseDataDtoImpl(
      id: json['id'] as String,
      recruiterID: json['recruiterID'] as String,
      jobDescription: json['jobDescription'] as String,
      jobType: json['jobType'] as String,
      location: json['location'] as String,
      companyName: json['companyName'] as String,
      postedDate: json['postedDate'] as String,
      closeDate: json['closeDate'] as String,
      skillList:
          (json['skillList'] as List<dynamic>).map((e) => e as String).toList(),
    );

Map<String, dynamic> _$$SearchJobsResponseDataDtoImplToJson(
        _$SearchJobsResponseDataDtoImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'recruiterID': instance.recruiterID,
      'jobDescription': instance.jobDescription,
      'jobType': instance.jobType,
      'location': instance.location,
      'companyName': instance.companyName,
      'postedDate': instance.postedDate,
      'closeDate': instance.closeDate,
      'skillList': instance.skillList,
    };
