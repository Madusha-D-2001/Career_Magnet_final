import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kt_dart/kt.dart';

import '../../domain/search_jobs/search_jobs_response.dart';
import 'search_jobs_response_data_dto.dart';

part 'search_jobs_response_dto.freezed.dart';
part 'search_jobs_response_dto.g.dart';

@freezed
class SearchJobsResponseDto with _$SearchJobsResponseDto {
  factory SearchJobsResponseDto({
    required int code,
    required String message,
    required List<SearchJobsResponseDataDto> data,
  }) = _SearchJobsResponseDto;

  factory SearchJobsResponseDto.fromJson(Map<String, dynamic> json) =>
      _$SearchJobsResponseDtoFromJson(json);

  factory SearchJobsResponseDto.fromDomain(SearchJobsResponse domain) {
    return SearchJobsResponseDto(
      code: domain.code,
      message: domain.message,
      data: domain.data
          .map((p) => SearchJobsResponseDataDto.fromDomain(p))
          .asList(),
    );
  }

  const SearchJobsResponseDto._();

  SearchJobsResponse toDomain() {
    return SearchJobsResponse(
      code: code,
      message: message,
      data: data.map((p) => p.toDomain()).toImmutableList(),
    );
  }
}
