// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'search_jobs_response_data_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

SearchJobsResponseDataDto _$SearchJobsResponseDataDtoFromJson(
    Map<String, dynamic> json) {
  return _SearchJobsResponseDataDto.fromJson(json);
}

/// @nodoc
mixin _$SearchJobsResponseDataDto {
  String get id => throw _privateConstructorUsedError;
  String get recruiterID => throw _privateConstructorUsedError;
  String get jobDescription => throw _privateConstructorUsedError;
  String get jobType => throw _privateConstructorUsedError;
  String get location => throw _privateConstructorUsedError;
  String get companyName => throw _privateConstructorUsedError;
  String get postedDate => throw _privateConstructorUsedError;
  String get closeDate => throw _privateConstructorUsedError;
  List<String> get skillList => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $SearchJobsResponseDataDtoCopyWith<SearchJobsResponseDataDto> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SearchJobsResponseDataDtoCopyWith<$Res> {
  factory $SearchJobsResponseDataDtoCopyWith(SearchJobsResponseDataDto value,
          $Res Function(SearchJobsResponseDataDto) then) =
      _$SearchJobsResponseDataDtoCopyWithImpl<$Res, SearchJobsResponseDataDto>;
  @useResult
  $Res call(
      {String id,
      String recruiterID,
      String jobDescription,
      String jobType,
      String location,
      String companyName,
      String postedDate,
      String closeDate,
      List<String> skillList});
}

/// @nodoc
class _$SearchJobsResponseDataDtoCopyWithImpl<$Res,
        $Val extends SearchJobsResponseDataDto>
    implements $SearchJobsResponseDataDtoCopyWith<$Res> {
  _$SearchJobsResponseDataDtoCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? recruiterID = null,
    Object? jobDescription = null,
    Object? jobType = null,
    Object? location = null,
    Object? companyName = null,
    Object? postedDate = null,
    Object? closeDate = null,
    Object? skillList = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      recruiterID: null == recruiterID
          ? _value.recruiterID
          : recruiterID // ignore: cast_nullable_to_non_nullable
              as String,
      jobDescription: null == jobDescription
          ? _value.jobDescription
          : jobDescription // ignore: cast_nullable_to_non_nullable
              as String,
      jobType: null == jobType
          ? _value.jobType
          : jobType // ignore: cast_nullable_to_non_nullable
              as String,
      location: null == location
          ? _value.location
          : location // ignore: cast_nullable_to_non_nullable
              as String,
      companyName: null == companyName
          ? _value.companyName
          : companyName // ignore: cast_nullable_to_non_nullable
              as String,
      postedDate: null == postedDate
          ? _value.postedDate
          : postedDate // ignore: cast_nullable_to_non_nullable
              as String,
      closeDate: null == closeDate
          ? _value.closeDate
          : closeDate // ignore: cast_nullable_to_non_nullable
              as String,
      skillList: null == skillList
          ? _value.skillList
          : skillList // ignore: cast_nullable_to_non_nullable
              as List<String>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$SearchJobsResponseDataDtoImplCopyWith<$Res>
    implements $SearchJobsResponseDataDtoCopyWith<$Res> {
  factory _$$SearchJobsResponseDataDtoImplCopyWith(
          _$SearchJobsResponseDataDtoImpl value,
          $Res Function(_$SearchJobsResponseDataDtoImpl) then) =
      __$$SearchJobsResponseDataDtoImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String recruiterID,
      String jobDescription,
      String jobType,
      String location,
      String companyName,
      String postedDate,
      String closeDate,
      List<String> skillList});
}

/// @nodoc
class __$$SearchJobsResponseDataDtoImplCopyWithImpl<$Res>
    extends _$SearchJobsResponseDataDtoCopyWithImpl<$Res,
        _$SearchJobsResponseDataDtoImpl>
    implements _$$SearchJobsResponseDataDtoImplCopyWith<$Res> {
  __$$SearchJobsResponseDataDtoImplCopyWithImpl(
      _$SearchJobsResponseDataDtoImpl _value,
      $Res Function(_$SearchJobsResponseDataDtoImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? recruiterID = null,
    Object? jobDescription = null,
    Object? jobType = null,
    Object? location = null,
    Object? companyName = null,
    Object? postedDate = null,
    Object? closeDate = null,
    Object? skillList = null,
  }) {
    return _then(_$SearchJobsResponseDataDtoImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      recruiterID: null == recruiterID
          ? _value.recruiterID
          : recruiterID // ignore: cast_nullable_to_non_nullable
              as String,
      jobDescription: null == jobDescription
          ? _value.jobDescription
          : jobDescription // ignore: cast_nullable_to_non_nullable
              as String,
      jobType: null == jobType
          ? _value.jobType
          : jobType // ignore: cast_nullable_to_non_nullable
              as String,
      location: null == location
          ? _value.location
          : location // ignore: cast_nullable_to_non_nullable
              as String,
      companyName: null == companyName
          ? _value.companyName
          : companyName // ignore: cast_nullable_to_non_nullable
              as String,
      postedDate: null == postedDate
          ? _value.postedDate
          : postedDate // ignore: cast_nullable_to_non_nullable
              as String,
      closeDate: null == closeDate
          ? _value.closeDate
          : closeDate // ignore: cast_nullable_to_non_nullable
              as String,
      skillList: null == skillList
          ? _value._skillList
          : skillList // ignore: cast_nullable_to_non_nullable
              as List<String>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$SearchJobsResponseDataDtoImpl extends _SearchJobsResponseDataDto {
  _$SearchJobsResponseDataDtoImpl(
      {required this.id,
      required this.recruiterID,
      required this.jobDescription,
      required this.jobType,
      required this.location,
      required this.companyName,
      required this.postedDate,
      required this.closeDate,
      required final List<String> skillList})
      : _skillList = skillList,
        super._();

  factory _$SearchJobsResponseDataDtoImpl.fromJson(Map<String, dynamic> json) =>
      _$$SearchJobsResponseDataDtoImplFromJson(json);

  @override
  final String id;
  @override
  final String recruiterID;
  @override
  final String jobDescription;
  @override
  final String jobType;
  @override
  final String location;
  @override
  final String companyName;
  @override
  final String postedDate;
  @override
  final String closeDate;
  final List<String> _skillList;
  @override
  List<String> get skillList {
    if (_skillList is EqualUnmodifiableListView) return _skillList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_skillList);
  }

  @override
  String toString() {
    return 'SearchJobsResponseDataDto(id: $id, recruiterID: $recruiterID, jobDescription: $jobDescription, jobType: $jobType, location: $location, companyName: $companyName, postedDate: $postedDate, closeDate: $closeDate, skillList: $skillList)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SearchJobsResponseDataDtoImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.recruiterID, recruiterID) ||
                other.recruiterID == recruiterID) &&
            (identical(other.jobDescription, jobDescription) ||
                other.jobDescription == jobDescription) &&
            (identical(other.jobType, jobType) || other.jobType == jobType) &&
            (identical(other.location, location) ||
                other.location == location) &&
            (identical(other.companyName, companyName) ||
                other.companyName == companyName) &&
            (identical(other.postedDate, postedDate) ||
                other.postedDate == postedDate) &&
            (identical(other.closeDate, closeDate) ||
                other.closeDate == closeDate) &&
            const DeepCollectionEquality()
                .equals(other._skillList, _skillList));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      recruiterID,
      jobDescription,
      jobType,
      location,
      companyName,
      postedDate,
      closeDate,
      const DeepCollectionEquality().hash(_skillList));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SearchJobsResponseDataDtoImplCopyWith<_$SearchJobsResponseDataDtoImpl>
      get copyWith => __$$SearchJobsResponseDataDtoImplCopyWithImpl<
          _$SearchJobsResponseDataDtoImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$SearchJobsResponseDataDtoImplToJson(
      this,
    );
  }
}

abstract class _SearchJobsResponseDataDto extends SearchJobsResponseDataDto {
  factory _SearchJobsResponseDataDto(
      {required final String id,
      required final String recruiterID,
      required final String jobDescription,
      required final String jobType,
      required final String location,
      required final String companyName,
      required final String postedDate,
      required final String closeDate,
      required final List<String> skillList}) = _$SearchJobsResponseDataDtoImpl;
  _SearchJobsResponseDataDto._() : super._();

  factory _SearchJobsResponseDataDto.fromJson(Map<String, dynamic> json) =
      _$SearchJobsResponseDataDtoImpl.fromJson;

  @override
  String get id;
  @override
  String get recruiterID;
  @override
  String get jobDescription;
  @override
  String get jobType;
  @override
  String get location;
  @override
  String get companyName;
  @override
  String get postedDate;
  @override
  String get closeDate;
  @override
  List<String> get skillList;
  @override
  @JsonKey(ignore: true)
  _$$SearchJobsResponseDataDtoImplCopyWith<_$SearchJobsResponseDataDtoImpl>
      get copyWith => throw _privateConstructorUsedError;
}
