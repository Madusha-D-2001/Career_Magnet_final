import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kt_dart/kt.dart';

import '../../domain/search_jobs/search_jobs_response_data.dart';

part 'search_jobs_response_data_dto.freezed.dart';
part 'search_jobs_response_data_dto.g.dart';

@freezed
class SearchJobsResponseDataDto with _$SearchJobsResponseDataDto {
  factory SearchJobsResponseDataDto({
    required String id,
    required String recruiterID,
    required String jobDescription,
    required String jobType,
    required String location,
    required String companyName,
    required String postedDate,
    required String closeDate,
    required List<String> skillList,
  }) = _SearchJobsResponseDataDto;

  factory SearchJobsResponseDataDto.fromJson(Map<String, dynamic> json) =>
      _$SearchJobsResponseDataDtoFromJson(json);

  factory SearchJobsResponseDataDto.fromDomain(SearchJobsResponseData domain) {
    return SearchJobsResponseDataDto(
      id: domain.id,
      recruiterID: domain.recruiterID,
      jobDescription: domain.jobDescription,
      jobType: domain.jobType,
      location: domain.location,
      companyName: domain.companyName,
      postedDate: domain.postedDate,
      closeDate: domain.closeDate,
      skillList: domain.skillList.asList(),
    );
  }

  const SearchJobsResponseDataDto._();

  SearchJobsResponseData toDomain() {
    return SearchJobsResponseData(
      id: id,
      recruiterID: recruiterID,
      jobDescription: jobDescription,
      jobType: jobType,
      location: location,
      companyName: companyName,
      postedDate: postedDate,
      closeDate: closeDate,
      skillList: skillList.toImmutableList(),
    );
  }
}
