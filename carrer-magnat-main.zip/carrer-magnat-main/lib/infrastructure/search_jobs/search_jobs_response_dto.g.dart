// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'search_jobs_response_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$SearchJobsResponseDtoImpl _$$SearchJobsResponseDtoImplFromJson(
        Map<String, dynamic> json) =>
    _$SearchJobsResponseDtoImpl(
      code: (json['code'] as num).toInt(),
      message: json['message'] as String,
      data: (json['data'] as List<dynamic>)
          .map((e) =>
              SearchJobsResponseDataDto.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$SearchJobsResponseDtoImplToJson(
        _$SearchJobsResponseDtoImpl instance) =>
    <String, dynamic>{
      'code': instance.code,
      'message': instance.message,
      'data': instance.data,
    };
