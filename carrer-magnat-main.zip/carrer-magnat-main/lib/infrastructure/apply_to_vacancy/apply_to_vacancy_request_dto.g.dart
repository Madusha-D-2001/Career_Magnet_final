// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'apply_to_vacancy_request_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$ApplyToVacancyRequestDtoImpl _$$ApplyToVacancyRequestDtoImplFromJson(
        Map<String, dynamic> json) =>
    _$ApplyToVacancyRequestDtoImpl(
      userID: json['userID'] as String,
      hiringAnnouncementID: json['hiringAnnouncementID'] as String,
    );

Map<String, dynamic> _$$ApplyToVacancyRequestDtoImplToJson(
        _$ApplyToVacancyRequestDtoImpl instance) =>
    <String, dynamic>{
      'userID': instance.userID,
      'hiringAnnouncementID': instance.hiringAnnouncementID,
    };
