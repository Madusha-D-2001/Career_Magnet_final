// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'apply_to_vacancy_request_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

ApplyToVacancyRequestDto _$ApplyToVacancyRequestDtoFromJson(
    Map<String, dynamic> json) {
  return _ApplyToVacancyRequestDto.fromJson(json);
}

/// @nodoc
mixin _$ApplyToVacancyRequestDto {
  String get userID => throw _privateConstructorUsedError;
  String get hiringAnnouncementID => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ApplyToVacancyRequestDtoCopyWith<ApplyToVacancyRequestDto> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ApplyToVacancyRequestDtoCopyWith<$Res> {
  factory $ApplyToVacancyRequestDtoCopyWith(ApplyToVacancyRequestDto value,
          $Res Function(ApplyToVacancyRequestDto) then) =
      _$ApplyToVacancyRequestDtoCopyWithImpl<$Res, ApplyToVacancyRequestDto>;
  @useResult
  $Res call({String userID, String hiringAnnouncementID});
}

/// @nodoc
class _$ApplyToVacancyRequestDtoCopyWithImpl<$Res,
        $Val extends ApplyToVacancyRequestDto>
    implements $ApplyToVacancyRequestDtoCopyWith<$Res> {
  _$ApplyToVacancyRequestDtoCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? userID = null,
    Object? hiringAnnouncementID = null,
  }) {
    return _then(_value.copyWith(
      userID: null == userID
          ? _value.userID
          : userID // ignore: cast_nullable_to_non_nullable
              as String,
      hiringAnnouncementID: null == hiringAnnouncementID
          ? _value.hiringAnnouncementID
          : hiringAnnouncementID // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ApplyToVacancyRequestDtoImplCopyWith<$Res>
    implements $ApplyToVacancyRequestDtoCopyWith<$Res> {
  factory _$$ApplyToVacancyRequestDtoImplCopyWith(
          _$ApplyToVacancyRequestDtoImpl value,
          $Res Function(_$ApplyToVacancyRequestDtoImpl) then) =
      __$$ApplyToVacancyRequestDtoImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String userID, String hiringAnnouncementID});
}

/// @nodoc
class __$$ApplyToVacancyRequestDtoImplCopyWithImpl<$Res>
    extends _$ApplyToVacancyRequestDtoCopyWithImpl<$Res,
        _$ApplyToVacancyRequestDtoImpl>
    implements _$$ApplyToVacancyRequestDtoImplCopyWith<$Res> {
  __$$ApplyToVacancyRequestDtoImplCopyWithImpl(
      _$ApplyToVacancyRequestDtoImpl _value,
      $Res Function(_$ApplyToVacancyRequestDtoImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? userID = null,
    Object? hiringAnnouncementID = null,
  }) {
    return _then(_$ApplyToVacancyRequestDtoImpl(
      userID: null == userID
          ? _value.userID
          : userID // ignore: cast_nullable_to_non_nullable
              as String,
      hiringAnnouncementID: null == hiringAnnouncementID
          ? _value.hiringAnnouncementID
          : hiringAnnouncementID // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ApplyToVacancyRequestDtoImpl extends _ApplyToVacancyRequestDto {
  _$ApplyToVacancyRequestDtoImpl(
      {required this.userID, required this.hiringAnnouncementID})
      : super._();

  factory _$ApplyToVacancyRequestDtoImpl.fromJson(Map<String, dynamic> json) =>
      _$$ApplyToVacancyRequestDtoImplFromJson(json);

  @override
  final String userID;
  @override
  final String hiringAnnouncementID;

  @override
  String toString() {
    return 'ApplyToVacancyRequestDto(userID: $userID, hiringAnnouncementID: $hiringAnnouncementID)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ApplyToVacancyRequestDtoImpl &&
            (identical(other.userID, userID) || other.userID == userID) &&
            (identical(other.hiringAnnouncementID, hiringAnnouncementID) ||
                other.hiringAnnouncementID == hiringAnnouncementID));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, userID, hiringAnnouncementID);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ApplyToVacancyRequestDtoImplCopyWith<_$ApplyToVacancyRequestDtoImpl>
      get copyWith => __$$ApplyToVacancyRequestDtoImplCopyWithImpl<
          _$ApplyToVacancyRequestDtoImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ApplyToVacancyRequestDtoImplToJson(
      this,
    );
  }
}

abstract class _ApplyToVacancyRequestDto extends ApplyToVacancyRequestDto {
  factory _ApplyToVacancyRequestDto(
          {required final String userID,
          required final String hiringAnnouncementID}) =
      _$ApplyToVacancyRequestDtoImpl;
  _ApplyToVacancyRequestDto._() : super._();

  factory _ApplyToVacancyRequestDto.fromJson(Map<String, dynamic> json) =
      _$ApplyToVacancyRequestDtoImpl.fromJson;

  @override
  String get userID;
  @override
  String get hiringAnnouncementID;
  @override
  @JsonKey(ignore: true)
  _$$ApplyToVacancyRequestDtoImplCopyWith<_$ApplyToVacancyRequestDtoImpl>
      get copyWith => throw _privateConstructorUsedError;
}
