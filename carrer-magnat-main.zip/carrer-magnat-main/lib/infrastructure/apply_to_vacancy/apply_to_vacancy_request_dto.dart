import 'package:carrermagnet/domain/apply_to_vacancy/apply_to_vacancy_request.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'apply_to_vacancy_request_dto.freezed.dart';
part 'apply_to_vacancy_request_dto.g.dart';

@freezed
class ApplyToVacancyRequestDto with _$ApplyToVacancyRequestDto {
  factory ApplyToVacancyRequestDto({
    required String userID,
    required String hiringAnnouncementID,
  }) = _ApplyToVacancyRequestDto;

  factory ApplyToVacancyRequestDto.fromJson(Map<String, dynamic> json) =>
      _$ApplyToVacancyRequestDtoFromJson(json);

  factory ApplyToVacancyRequestDto.fromDomain(ApplyToVacancyRequest domain) {
    return ApplyToVacancyRequestDto(
      userID: domain.userID,
      hiringAnnouncementID: domain.hiringAnnouncementID,
    );
  }

  const ApplyToVacancyRequestDto._();

  ApplyToVacancyRequest toDomain() {
    return ApplyToVacancyRequest(
      userID: userID,
      hiringAnnouncementID: hiringAnnouncementID,
    );
  }
}
