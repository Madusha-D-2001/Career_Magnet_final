// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'project_data_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

ProjectDataDto _$ProjectDataDtoFromJson(Map<String, dynamic> json) {
  return _ProjectDataDto.fromJson(json);
}

/// @nodoc
mixin _$ProjectDataDto {
  String get project_id => throw _privateConstructorUsedError;
  String get project_name => throw _privateConstructorUsedError;
  String get description => throw _privateConstructorUsedError;
  List<String> get used_skills => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ProjectDataDtoCopyWith<ProjectDataDto> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProjectDataDtoCopyWith<$Res> {
  factory $ProjectDataDtoCopyWith(
          ProjectDataDto value, $Res Function(ProjectDataDto) then) =
      _$ProjectDataDtoCopyWithImpl<$Res, ProjectDataDto>;
  @useResult
  $Res call(
      {String project_id,
      String project_name,
      String description,
      List<String> used_skills});
}

/// @nodoc
class _$ProjectDataDtoCopyWithImpl<$Res, $Val extends ProjectDataDto>
    implements $ProjectDataDtoCopyWith<$Res> {
  _$ProjectDataDtoCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? project_id = null,
    Object? project_name = null,
    Object? description = null,
    Object? used_skills = null,
  }) {
    return _then(_value.copyWith(
      project_id: null == project_id
          ? _value.project_id
          : project_id // ignore: cast_nullable_to_non_nullable
              as String,
      project_name: null == project_name
          ? _value.project_name
          : project_name // ignore: cast_nullable_to_non_nullable
              as String,
      description: null == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String,
      used_skills: null == used_skills
          ? _value.used_skills
          : used_skills // ignore: cast_nullable_to_non_nullable
              as List<String>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ProjectDataDtoImplCopyWith<$Res>
    implements $ProjectDataDtoCopyWith<$Res> {
  factory _$$ProjectDataDtoImplCopyWith(_$ProjectDataDtoImpl value,
          $Res Function(_$ProjectDataDtoImpl) then) =
      __$$ProjectDataDtoImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String project_id,
      String project_name,
      String description,
      List<String> used_skills});
}

/// @nodoc
class __$$ProjectDataDtoImplCopyWithImpl<$Res>
    extends _$ProjectDataDtoCopyWithImpl<$Res, _$ProjectDataDtoImpl>
    implements _$$ProjectDataDtoImplCopyWith<$Res> {
  __$$ProjectDataDtoImplCopyWithImpl(
      _$ProjectDataDtoImpl _value, $Res Function(_$ProjectDataDtoImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? project_id = null,
    Object? project_name = null,
    Object? description = null,
    Object? used_skills = null,
  }) {
    return _then(_$ProjectDataDtoImpl(
      project_id: null == project_id
          ? _value.project_id
          : project_id // ignore: cast_nullable_to_non_nullable
              as String,
      project_name: null == project_name
          ? _value.project_name
          : project_name // ignore: cast_nullable_to_non_nullable
              as String,
      description: null == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String,
      used_skills: null == used_skills
          ? _value._used_skills
          : used_skills // ignore: cast_nullable_to_non_nullable
              as List<String>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ProjectDataDtoImpl extends _ProjectDataDto {
  _$ProjectDataDtoImpl(
      {required this.project_id,
      required this.project_name,
      required this.description,
      required final List<String> used_skills})
      : _used_skills = used_skills,
        super._();

  factory _$ProjectDataDtoImpl.fromJson(Map<String, dynamic> json) =>
      _$$ProjectDataDtoImplFromJson(json);

  @override
  final String project_id;
  @override
  final String project_name;
  @override
  final String description;
  final List<String> _used_skills;
  @override
  List<String> get used_skills {
    if (_used_skills is EqualUnmodifiableListView) return _used_skills;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_used_skills);
  }

  @override
  String toString() {
    return 'ProjectDataDto(project_id: $project_id, project_name: $project_name, description: $description, used_skills: $used_skills)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ProjectDataDtoImpl &&
            (identical(other.project_id, project_id) ||
                other.project_id == project_id) &&
            (identical(other.project_name, project_name) ||
                other.project_name == project_name) &&
            (identical(other.description, description) ||
                other.description == description) &&
            const DeepCollectionEquality()
                .equals(other._used_skills, _used_skills));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, project_id, project_name,
      description, const DeepCollectionEquality().hash(_used_skills));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ProjectDataDtoImplCopyWith<_$ProjectDataDtoImpl> get copyWith =>
      __$$ProjectDataDtoImplCopyWithImpl<_$ProjectDataDtoImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ProjectDataDtoImplToJson(
      this,
    );
  }
}

abstract class _ProjectDataDto extends ProjectDataDto {
  factory _ProjectDataDto(
      {required final String project_id,
      required final String project_name,
      required final String description,
      required final List<String> used_skills}) = _$ProjectDataDtoImpl;
  _ProjectDataDto._() : super._();

  factory _ProjectDataDto.fromJson(Map<String, dynamic> json) =
      _$ProjectDataDtoImpl.fromJson;

  @override
  String get project_id;
  @override
  String get project_name;
  @override
  String get description;
  @override
  List<String> get used_skills;
  @override
  @JsonKey(ignore: true)
  _$$ProjectDataDtoImplCopyWith<_$ProjectDataDtoImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
