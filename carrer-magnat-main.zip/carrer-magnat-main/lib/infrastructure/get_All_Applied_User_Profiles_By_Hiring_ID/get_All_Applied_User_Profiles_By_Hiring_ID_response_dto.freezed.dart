// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'get_All_Applied_User_Profiles_By_Hiring_ID_response_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

GetAllAppliedUserProfilesByHiringIdResponseDto
    _$GetAllAppliedUserProfilesByHiringIdResponseDtoFromJson(
        Map<String, dynamic> json) {
  return _GetAllAppliedUserProfilesByHiringIdResponseDto.fromJson(json);
}

/// @nodoc
mixin _$GetAllAppliedUserProfilesByHiringIdResponseDto {
  int get code => throw _privateConstructorUsedError;
  String get message => throw _privateConstructorUsedError;
  List<GetAllAppliedUserProfilesByHiringIdDataDto> get data =>
      throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $GetAllAppliedUserProfilesByHiringIdResponseDtoCopyWith<
          GetAllAppliedUserProfilesByHiringIdResponseDto>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GetAllAppliedUserProfilesByHiringIdResponseDtoCopyWith<$Res> {
  factory $GetAllAppliedUserProfilesByHiringIdResponseDtoCopyWith(
          GetAllAppliedUserProfilesByHiringIdResponseDto value,
          $Res Function(GetAllAppliedUserProfilesByHiringIdResponseDto) then) =
      _$GetAllAppliedUserProfilesByHiringIdResponseDtoCopyWithImpl<$Res,
          GetAllAppliedUserProfilesByHiringIdResponseDto>;
  @useResult
  $Res call(
      {int code,
      String message,
      List<GetAllAppliedUserProfilesByHiringIdDataDto> data});
}

/// @nodoc
class _$GetAllAppliedUserProfilesByHiringIdResponseDtoCopyWithImpl<$Res,
        $Val extends GetAllAppliedUserProfilesByHiringIdResponseDto>
    implements $GetAllAppliedUserProfilesByHiringIdResponseDtoCopyWith<$Res> {
  _$GetAllAppliedUserProfilesByHiringIdResponseDtoCopyWithImpl(
      this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? code = null,
    Object? message = null,
    Object? data = null,
  }) {
    return _then(_value.copyWith(
      code: null == code
          ? _value.code
          : code // ignore: cast_nullable_to_non_nullable
              as int,
      message: null == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String,
      data: null == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as List<GetAllAppliedUserProfilesByHiringIdDataDto>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$GetAllAppliedUserProfilesByHiringIdResponseDtoImplCopyWith<
        $Res>
    implements $GetAllAppliedUserProfilesByHiringIdResponseDtoCopyWith<$Res> {
  factory _$$GetAllAppliedUserProfilesByHiringIdResponseDtoImplCopyWith(
          _$GetAllAppliedUserProfilesByHiringIdResponseDtoImpl value,
          $Res Function(_$GetAllAppliedUserProfilesByHiringIdResponseDtoImpl)
              then) =
      __$$GetAllAppliedUserProfilesByHiringIdResponseDtoImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {int code,
      String message,
      List<GetAllAppliedUserProfilesByHiringIdDataDto> data});
}

/// @nodoc
class __$$GetAllAppliedUserProfilesByHiringIdResponseDtoImplCopyWithImpl<$Res>
    extends _$GetAllAppliedUserProfilesByHiringIdResponseDtoCopyWithImpl<$Res,
        _$GetAllAppliedUserProfilesByHiringIdResponseDtoImpl>
    implements
        _$$GetAllAppliedUserProfilesByHiringIdResponseDtoImplCopyWith<$Res> {
  __$$GetAllAppliedUserProfilesByHiringIdResponseDtoImplCopyWithImpl(
      _$GetAllAppliedUserProfilesByHiringIdResponseDtoImpl _value,
      $Res Function(_$GetAllAppliedUserProfilesByHiringIdResponseDtoImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? code = null,
    Object? message = null,
    Object? data = null,
  }) {
    return _then(_$GetAllAppliedUserProfilesByHiringIdResponseDtoImpl(
      code: null == code
          ? _value.code
          : code // ignore: cast_nullable_to_non_nullable
              as int,
      message: null == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String,
      data: null == data
          ? _value._data
          : data // ignore: cast_nullable_to_non_nullable
              as List<GetAllAppliedUserProfilesByHiringIdDataDto>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$GetAllAppliedUserProfilesByHiringIdResponseDtoImpl
    extends _GetAllAppliedUserProfilesByHiringIdResponseDto {
  _$GetAllAppliedUserProfilesByHiringIdResponseDtoImpl(
      {required this.code,
      required this.message,
      required final List<GetAllAppliedUserProfilesByHiringIdDataDto> data})
      : _data = data,
        super._();

  factory _$GetAllAppliedUserProfilesByHiringIdResponseDtoImpl.fromJson(
          Map<String, dynamic> json) =>
      _$$GetAllAppliedUserProfilesByHiringIdResponseDtoImplFromJson(json);

  @override
  final int code;
  @override
  final String message;
  final List<GetAllAppliedUserProfilesByHiringIdDataDto> _data;
  @override
  List<GetAllAppliedUserProfilesByHiringIdDataDto> get data {
    if (_data is EqualUnmodifiableListView) return _data;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_data);
  }

  @override
  String toString() {
    return 'GetAllAppliedUserProfilesByHiringIdResponseDto(code: $code, message: $message, data: $data)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetAllAppliedUserProfilesByHiringIdResponseDtoImpl &&
            (identical(other.code, code) || other.code == code) &&
            (identical(other.message, message) || other.message == message) &&
            const DeepCollectionEquality().equals(other._data, _data));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, code, message, const DeepCollectionEquality().hash(_data));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetAllAppliedUserProfilesByHiringIdResponseDtoImplCopyWith<
          _$GetAllAppliedUserProfilesByHiringIdResponseDtoImpl>
      get copyWith =>
          __$$GetAllAppliedUserProfilesByHiringIdResponseDtoImplCopyWithImpl<
                  _$GetAllAppliedUserProfilesByHiringIdResponseDtoImpl>(
              this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$GetAllAppliedUserProfilesByHiringIdResponseDtoImplToJson(
      this,
    );
  }
}

abstract class _GetAllAppliedUserProfilesByHiringIdResponseDto
    extends GetAllAppliedUserProfilesByHiringIdResponseDto {
  factory _GetAllAppliedUserProfilesByHiringIdResponseDto(
      {required final int code,
      required final String message,
      required final List<GetAllAppliedUserProfilesByHiringIdDataDto>
          data}) = _$GetAllAppliedUserProfilesByHiringIdResponseDtoImpl;
  _GetAllAppliedUserProfilesByHiringIdResponseDto._() : super._();

  factory _GetAllAppliedUserProfilesByHiringIdResponseDto.fromJson(
          Map<String, dynamic> json) =
      _$GetAllAppliedUserProfilesByHiringIdResponseDtoImpl.fromJson;

  @override
  int get code;
  @override
  String get message;
  @override
  List<GetAllAppliedUserProfilesByHiringIdDataDto> get data;
  @override
  @JsonKey(ignore: true)
  _$$GetAllAppliedUserProfilesByHiringIdResponseDtoImplCopyWith<
          _$GetAllAppliedUserProfilesByHiringIdResponseDtoImpl>
      get copyWith => throw _privateConstructorUsedError;
}
