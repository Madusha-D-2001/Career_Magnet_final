// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'get_All_Applied_User_Profiles_By_Hiring_ID_data_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$GetAllAppliedUserProfilesByHiringIdDataDtoImpl
    _$$GetAllAppliedUserProfilesByHiringIdDataDtoImplFromJson(
            Map<String, dynamic> json) =>
        _$GetAllAppliedUserProfilesByHiringIdDataDtoImpl(
          user_id: json['user_id'] as String,
          userProfileID: json['userProfileID'] as String,
          first_name: json['first_name'] as String,
          last_name: json['last_name'] as String,
          fullName: json['fullName'] as String,
          address: json['address'] as String,
          birthDay: json['birthDay'] as String,
          email: json['email'] as String,
          contact: json['contact'] as String,
          profileInfo: json['profileInfo'] as String,
          education: json['education'] as String,
          university: json['university'] as String,
          position: json['position'] as String,
          skillList: (json['skillList'] as List<dynamic>)
              .map((e) => e as String)
              .toList(),
          projectDTOS: (json['projectDTOS'] as List<dynamic>)
              .map((e) => ProjectDataDto.fromJson(e as Map<String, dynamic>))
              .toList(),
        );

Map<String, dynamic> _$$GetAllAppliedUserProfilesByHiringIdDataDtoImplToJson(
        _$GetAllAppliedUserProfilesByHiringIdDataDtoImpl instance) =>
    <String, dynamic>{
      'user_id': instance.user_id,
      'userProfileID': instance.userProfileID,
      'first_name': instance.first_name,
      'last_name': instance.last_name,
      'fullName': instance.fullName,
      'address': instance.address,
      'birthDay': instance.birthDay,
      'email': instance.email,
      'contact': instance.contact,
      'profileInfo': instance.profileInfo,
      'education': instance.education,
      'university': instance.university,
      'position': instance.position,
      'skillList': instance.skillList,
      'projectDTOS': instance.projectDTOS,
    };
