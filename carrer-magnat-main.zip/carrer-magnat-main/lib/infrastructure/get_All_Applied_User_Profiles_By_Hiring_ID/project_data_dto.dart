import 'package:carrermagnet/domain/get_All_Applied_User_Profiles_By_Hiring_ID/project_data.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kt_dart/kt.dart';

part 'project_data_dto.freezed.dart';
part 'project_data_dto.g.dart';

@freezed
class ProjectDataDto with _$ProjectDataDto {
  factory ProjectDataDto({
    required String project_id,
    required String project_name,
    required String description,
    required List<String> used_skills,
  }) = _ProjectDataDto;

  factory ProjectDataDto.fromJson(Map<String, dynamic> json) =>
      _$ProjectDataDtoFromJson(json);

  factory ProjectDataDto.fromDomain(ProjectData domain) {
    return ProjectDataDto(
      project_id: domain.project_id,
      project_name: domain.project_name,
      description: domain.description,
      used_skills: domain.used_skills.asList(),
    );
  }

  const ProjectDataDto._();

  ProjectData toDomain() {
    return ProjectData(
      project_id: project_id,
      project_name: project_name,
      description: description,
      used_skills: used_skills.toImmutableList(),
    );
  }
}
