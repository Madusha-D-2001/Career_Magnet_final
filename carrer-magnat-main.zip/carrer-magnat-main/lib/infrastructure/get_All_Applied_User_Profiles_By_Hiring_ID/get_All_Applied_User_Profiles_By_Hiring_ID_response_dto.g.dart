// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'get_All_Applied_User_Profiles_By_Hiring_ID_response_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$GetAllAppliedUserProfilesByHiringIdResponseDtoImpl
    _$$GetAllAppliedUserProfilesByHiringIdResponseDtoImplFromJson(
            Map<String, dynamic> json) =>
        _$GetAllAppliedUserProfilesByHiringIdResponseDtoImpl(
          code: (json['code'] as num).toInt(),
          message: json['message'] as String,
          data: (json['data'] as List<dynamic>)
              .map((e) => GetAllAppliedUserProfilesByHiringIdDataDto.fromJson(
                  e as Map<String, dynamic>))
              .toList(),
        );

Map<String, dynamic>
    _$$GetAllAppliedUserProfilesByHiringIdResponseDtoImplToJson(
            _$GetAllAppliedUserProfilesByHiringIdResponseDtoImpl instance) =>
        <String, dynamic>{
          'code': instance.code,
          'message': instance.message,
          'data': instance.data,
        };
