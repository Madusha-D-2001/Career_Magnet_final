import 'package:carrermagnet/infrastructure/get_All_Applied_User_Profiles_By_Hiring_ID/project_data_dto.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kt_dart/kt.dart';

import '../../domain/get_All_Applied_User_Profiles_By_Hiring_ID/get_All_Applied_User_Profiles_By_Hiring_ID_data.dart';

part 'get_All_Applied_User_Profiles_By_Hiring_ID_data_dto.freezed.dart';
part 'get_All_Applied_User_Profiles_By_Hiring_ID_data_dto.g.dart';

@freezed
class GetAllAppliedUserProfilesByHiringIdDataDto
    with _$GetAllAppliedUserProfilesByHiringIdDataDto {
  factory GetAllAppliedUserProfilesByHiringIdDataDto({
    required String user_id,
    required String userProfileID,
    required String first_name,
    required String last_name,
    required String fullName,
    required String address,
    required String birthDay,
    required String email,
    required String contact,
    required String profileInfo,
    required String education,
    required String university,
    required String position,
    required List<String> skillList,
    required List<ProjectDataDto> projectDTOS,
  }) = _GetAllAppliedUserProfilesByHiringIdDataDto;

  factory GetAllAppliedUserProfilesByHiringIdDataDto.fromJson(
          Map<String, dynamic> json) =>
      _$GetAllAppliedUserProfilesByHiringIdDataDtoFromJson(json);

  factory GetAllAppliedUserProfilesByHiringIdDataDto.fromDomain(
      GetAllAppliedUserProfilesByHiringIdData domain) {
    return GetAllAppliedUserProfilesByHiringIdDataDto(
      user_id: domain.user_id,
      userProfileID: domain.userProfileID,
      first_name: domain.first_name,
      last_name: domain.last_name,
      fullName: domain.fullName,
      address: domain.address,
      birthDay: domain.birthDay,
      email: domain.email,
      contact: domain.contact,
      profileInfo: domain.profileInfo,
      education: domain.education,
      university: domain.university,
      position: domain.position,
      skillList: domain.skillList.asList(),
      projectDTOS:
          domain.projectDTOS.map((p) => ProjectDataDto.fromDomain(p)).asList(),
    );
  }

  const GetAllAppliedUserProfilesByHiringIdDataDto._();

  GetAllAppliedUserProfilesByHiringIdData toDomain() {
    return GetAllAppliedUserProfilesByHiringIdData(
      user_id: user_id,
      userProfileID: userProfileID,
      first_name: first_name,
      last_name: last_name,
      fullName: fullName,
      address: address,
      birthDay: birthDay,
      email: email,
      contact: contact,
      profileInfo: profileInfo,
      education: education,
      university: university,
      position: position,
      skillList: skillList.toImmutableList(),
      projectDTOS: projectDTOS.map((p) => p.toDomain()).toImmutableList(),
    );
  }
}
