// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'get_All_Applied_User_Profiles_By_Hiring_ID_data_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

GetAllAppliedUserProfilesByHiringIdDataDto
    _$GetAllAppliedUserProfilesByHiringIdDataDtoFromJson(
        Map<String, dynamic> json) {
  return _GetAllAppliedUserProfilesByHiringIdDataDto.fromJson(json);
}

/// @nodoc
mixin _$GetAllAppliedUserProfilesByHiringIdDataDto {
  String get user_id => throw _privateConstructorUsedError;
  String get userProfileID => throw _privateConstructorUsedError;
  String get first_name => throw _privateConstructorUsedError;
  String get last_name => throw _privateConstructorUsedError;
  String get fullName => throw _privateConstructorUsedError;
  String get address => throw _privateConstructorUsedError;
  String get birthDay => throw _privateConstructorUsedError;
  String get email => throw _privateConstructorUsedError;
  String get contact => throw _privateConstructorUsedError;
  String get profileInfo => throw _privateConstructorUsedError;
  String get education => throw _privateConstructorUsedError;
  String get university => throw _privateConstructorUsedError;
  String get position => throw _privateConstructorUsedError;
  List<String> get skillList => throw _privateConstructorUsedError;
  List<ProjectDataDto> get projectDTOS => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $GetAllAppliedUserProfilesByHiringIdDataDtoCopyWith<
          GetAllAppliedUserProfilesByHiringIdDataDto>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GetAllAppliedUserProfilesByHiringIdDataDtoCopyWith<$Res> {
  factory $GetAllAppliedUserProfilesByHiringIdDataDtoCopyWith(
          GetAllAppliedUserProfilesByHiringIdDataDto value,
          $Res Function(GetAllAppliedUserProfilesByHiringIdDataDto) then) =
      _$GetAllAppliedUserProfilesByHiringIdDataDtoCopyWithImpl<$Res,
          GetAllAppliedUserProfilesByHiringIdDataDto>;
  @useResult
  $Res call(
      {String user_id,
      String userProfileID,
      String first_name,
      String last_name,
      String fullName,
      String address,
      String birthDay,
      String email,
      String contact,
      String profileInfo,
      String education,
      String university,
      String position,
      List<String> skillList,
      List<ProjectDataDto> projectDTOS});
}

/// @nodoc
class _$GetAllAppliedUserProfilesByHiringIdDataDtoCopyWithImpl<$Res,
        $Val extends GetAllAppliedUserProfilesByHiringIdDataDto>
    implements $GetAllAppliedUserProfilesByHiringIdDataDtoCopyWith<$Res> {
  _$GetAllAppliedUserProfilesByHiringIdDataDtoCopyWithImpl(
      this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? user_id = null,
    Object? userProfileID = null,
    Object? first_name = null,
    Object? last_name = null,
    Object? fullName = null,
    Object? address = null,
    Object? birthDay = null,
    Object? email = null,
    Object? contact = null,
    Object? profileInfo = null,
    Object? education = null,
    Object? university = null,
    Object? position = null,
    Object? skillList = null,
    Object? projectDTOS = null,
  }) {
    return _then(_value.copyWith(
      user_id: null == user_id
          ? _value.user_id
          : user_id // ignore: cast_nullable_to_non_nullable
              as String,
      userProfileID: null == userProfileID
          ? _value.userProfileID
          : userProfileID // ignore: cast_nullable_to_non_nullable
              as String,
      first_name: null == first_name
          ? _value.first_name
          : first_name // ignore: cast_nullable_to_non_nullable
              as String,
      last_name: null == last_name
          ? _value.last_name
          : last_name // ignore: cast_nullable_to_non_nullable
              as String,
      fullName: null == fullName
          ? _value.fullName
          : fullName // ignore: cast_nullable_to_non_nullable
              as String,
      address: null == address
          ? _value.address
          : address // ignore: cast_nullable_to_non_nullable
              as String,
      birthDay: null == birthDay
          ? _value.birthDay
          : birthDay // ignore: cast_nullable_to_non_nullable
              as String,
      email: null == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String,
      contact: null == contact
          ? _value.contact
          : contact // ignore: cast_nullable_to_non_nullable
              as String,
      profileInfo: null == profileInfo
          ? _value.profileInfo
          : profileInfo // ignore: cast_nullable_to_non_nullable
              as String,
      education: null == education
          ? _value.education
          : education // ignore: cast_nullable_to_non_nullable
              as String,
      university: null == university
          ? _value.university
          : university // ignore: cast_nullable_to_non_nullable
              as String,
      position: null == position
          ? _value.position
          : position // ignore: cast_nullable_to_non_nullable
              as String,
      skillList: null == skillList
          ? _value.skillList
          : skillList // ignore: cast_nullable_to_non_nullable
              as List<String>,
      projectDTOS: null == projectDTOS
          ? _value.projectDTOS
          : projectDTOS // ignore: cast_nullable_to_non_nullable
              as List<ProjectDataDto>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$GetAllAppliedUserProfilesByHiringIdDataDtoImplCopyWith<$Res>
    implements $GetAllAppliedUserProfilesByHiringIdDataDtoCopyWith<$Res> {
  factory _$$GetAllAppliedUserProfilesByHiringIdDataDtoImplCopyWith(
          _$GetAllAppliedUserProfilesByHiringIdDataDtoImpl value,
          $Res Function(_$GetAllAppliedUserProfilesByHiringIdDataDtoImpl)
              then) =
      __$$GetAllAppliedUserProfilesByHiringIdDataDtoImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String user_id,
      String userProfileID,
      String first_name,
      String last_name,
      String fullName,
      String address,
      String birthDay,
      String email,
      String contact,
      String profileInfo,
      String education,
      String university,
      String position,
      List<String> skillList,
      List<ProjectDataDto> projectDTOS});
}

/// @nodoc
class __$$GetAllAppliedUserProfilesByHiringIdDataDtoImplCopyWithImpl<$Res>
    extends _$GetAllAppliedUserProfilesByHiringIdDataDtoCopyWithImpl<$Res,
        _$GetAllAppliedUserProfilesByHiringIdDataDtoImpl>
    implements _$$GetAllAppliedUserProfilesByHiringIdDataDtoImplCopyWith<$Res> {
  __$$GetAllAppliedUserProfilesByHiringIdDataDtoImplCopyWithImpl(
      _$GetAllAppliedUserProfilesByHiringIdDataDtoImpl _value,
      $Res Function(_$GetAllAppliedUserProfilesByHiringIdDataDtoImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? user_id = null,
    Object? userProfileID = null,
    Object? first_name = null,
    Object? last_name = null,
    Object? fullName = null,
    Object? address = null,
    Object? birthDay = null,
    Object? email = null,
    Object? contact = null,
    Object? profileInfo = null,
    Object? education = null,
    Object? university = null,
    Object? position = null,
    Object? skillList = null,
    Object? projectDTOS = null,
  }) {
    return _then(_$GetAllAppliedUserProfilesByHiringIdDataDtoImpl(
      user_id: null == user_id
          ? _value.user_id
          : user_id // ignore: cast_nullable_to_non_nullable
              as String,
      userProfileID: null == userProfileID
          ? _value.userProfileID
          : userProfileID // ignore: cast_nullable_to_non_nullable
              as String,
      first_name: null == first_name
          ? _value.first_name
          : first_name // ignore: cast_nullable_to_non_nullable
              as String,
      last_name: null == last_name
          ? _value.last_name
          : last_name // ignore: cast_nullable_to_non_nullable
              as String,
      fullName: null == fullName
          ? _value.fullName
          : fullName // ignore: cast_nullable_to_non_nullable
              as String,
      address: null == address
          ? _value.address
          : address // ignore: cast_nullable_to_non_nullable
              as String,
      birthDay: null == birthDay
          ? _value.birthDay
          : birthDay // ignore: cast_nullable_to_non_nullable
              as String,
      email: null == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String,
      contact: null == contact
          ? _value.contact
          : contact // ignore: cast_nullable_to_non_nullable
              as String,
      profileInfo: null == profileInfo
          ? _value.profileInfo
          : profileInfo // ignore: cast_nullable_to_non_nullable
              as String,
      education: null == education
          ? _value.education
          : education // ignore: cast_nullable_to_non_nullable
              as String,
      university: null == university
          ? _value.university
          : university // ignore: cast_nullable_to_non_nullable
              as String,
      position: null == position
          ? _value.position
          : position // ignore: cast_nullable_to_non_nullable
              as String,
      skillList: null == skillList
          ? _value._skillList
          : skillList // ignore: cast_nullable_to_non_nullable
              as List<String>,
      projectDTOS: null == projectDTOS
          ? _value._projectDTOS
          : projectDTOS // ignore: cast_nullable_to_non_nullable
              as List<ProjectDataDto>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$GetAllAppliedUserProfilesByHiringIdDataDtoImpl
    extends _GetAllAppliedUserProfilesByHiringIdDataDto {
  _$GetAllAppliedUserProfilesByHiringIdDataDtoImpl(
      {required this.user_id,
      required this.userProfileID,
      required this.first_name,
      required this.last_name,
      required this.fullName,
      required this.address,
      required this.birthDay,
      required this.email,
      required this.contact,
      required this.profileInfo,
      required this.education,
      required this.university,
      required this.position,
      required final List<String> skillList,
      required final List<ProjectDataDto> projectDTOS})
      : _skillList = skillList,
        _projectDTOS = projectDTOS,
        super._();

  factory _$GetAllAppliedUserProfilesByHiringIdDataDtoImpl.fromJson(
          Map<String, dynamic> json) =>
      _$$GetAllAppliedUserProfilesByHiringIdDataDtoImplFromJson(json);

  @override
  final String user_id;
  @override
  final String userProfileID;
  @override
  final String first_name;
  @override
  final String last_name;
  @override
  final String fullName;
  @override
  final String address;
  @override
  final String birthDay;
  @override
  final String email;
  @override
  final String contact;
  @override
  final String profileInfo;
  @override
  final String education;
  @override
  final String university;
  @override
  final String position;
  final List<String> _skillList;
  @override
  List<String> get skillList {
    if (_skillList is EqualUnmodifiableListView) return _skillList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_skillList);
  }

  final List<ProjectDataDto> _projectDTOS;
  @override
  List<ProjectDataDto> get projectDTOS {
    if (_projectDTOS is EqualUnmodifiableListView) return _projectDTOS;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_projectDTOS);
  }

  @override
  String toString() {
    return 'GetAllAppliedUserProfilesByHiringIdDataDto(user_id: $user_id, userProfileID: $userProfileID, first_name: $first_name, last_name: $last_name, fullName: $fullName, address: $address, birthDay: $birthDay, email: $email, contact: $contact, profileInfo: $profileInfo, education: $education, university: $university, position: $position, skillList: $skillList, projectDTOS: $projectDTOS)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetAllAppliedUserProfilesByHiringIdDataDtoImpl &&
            (identical(other.user_id, user_id) || other.user_id == user_id) &&
            (identical(other.userProfileID, userProfileID) ||
                other.userProfileID == userProfileID) &&
            (identical(other.first_name, first_name) ||
                other.first_name == first_name) &&
            (identical(other.last_name, last_name) ||
                other.last_name == last_name) &&
            (identical(other.fullName, fullName) ||
                other.fullName == fullName) &&
            (identical(other.address, address) || other.address == address) &&
            (identical(other.birthDay, birthDay) ||
                other.birthDay == birthDay) &&
            (identical(other.email, email) || other.email == email) &&
            (identical(other.contact, contact) || other.contact == contact) &&
            (identical(other.profileInfo, profileInfo) ||
                other.profileInfo == profileInfo) &&
            (identical(other.education, education) ||
                other.education == education) &&
            (identical(other.university, university) ||
                other.university == university) &&
            (identical(other.position, position) ||
                other.position == position) &&
            const DeepCollectionEquality()
                .equals(other._skillList, _skillList) &&
            const DeepCollectionEquality()
                .equals(other._projectDTOS, _projectDTOS));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      user_id,
      userProfileID,
      first_name,
      last_name,
      fullName,
      address,
      birthDay,
      email,
      contact,
      profileInfo,
      education,
      university,
      position,
      const DeepCollectionEquality().hash(_skillList),
      const DeepCollectionEquality().hash(_projectDTOS));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetAllAppliedUserProfilesByHiringIdDataDtoImplCopyWith<
          _$GetAllAppliedUserProfilesByHiringIdDataDtoImpl>
      get copyWith =>
          __$$GetAllAppliedUserProfilesByHiringIdDataDtoImplCopyWithImpl<
                  _$GetAllAppliedUserProfilesByHiringIdDataDtoImpl>(
              this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$GetAllAppliedUserProfilesByHiringIdDataDtoImplToJson(
      this,
    );
  }
}

abstract class _GetAllAppliedUserProfilesByHiringIdDataDto
    extends GetAllAppliedUserProfilesByHiringIdDataDto {
  factory _GetAllAppliedUserProfilesByHiringIdDataDto(
          {required final String user_id,
          required final String userProfileID,
          required final String first_name,
          required final String last_name,
          required final String fullName,
          required final String address,
          required final String birthDay,
          required final String email,
          required final String contact,
          required final String profileInfo,
          required final String education,
          required final String university,
          required final String position,
          required final List<String> skillList,
          required final List<ProjectDataDto> projectDTOS}) =
      _$GetAllAppliedUserProfilesByHiringIdDataDtoImpl;
  _GetAllAppliedUserProfilesByHiringIdDataDto._() : super._();

  factory _GetAllAppliedUserProfilesByHiringIdDataDto.fromJson(
          Map<String, dynamic> json) =
      _$GetAllAppliedUserProfilesByHiringIdDataDtoImpl.fromJson;

  @override
  String get user_id;
  @override
  String get userProfileID;
  @override
  String get first_name;
  @override
  String get last_name;
  @override
  String get fullName;
  @override
  String get address;
  @override
  String get birthDay;
  @override
  String get email;
  @override
  String get contact;
  @override
  String get profileInfo;
  @override
  String get education;
  @override
  String get university;
  @override
  String get position;
  @override
  List<String> get skillList;
  @override
  List<ProjectDataDto> get projectDTOS;
  @override
  @JsonKey(ignore: true)
  _$$GetAllAppliedUserProfilesByHiringIdDataDtoImplCopyWith<
          _$GetAllAppliedUserProfilesByHiringIdDataDtoImpl>
      get copyWith => throw _privateConstructorUsedError;
}
