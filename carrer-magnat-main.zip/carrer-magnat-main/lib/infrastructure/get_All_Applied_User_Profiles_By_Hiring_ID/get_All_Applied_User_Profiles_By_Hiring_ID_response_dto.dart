import 'package:carrermagnet/domain/get_All_Applied_User_Profiles_By_Hiring_ID/get_All_Applied_User_Profiles_By_Hiring_ID_response.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kt_dart/kt.dart';

import 'get_All_Applied_User_Profiles_By_Hiring_ID_data_dto.dart';

part 'get_All_Applied_User_Profiles_By_Hiring_ID_response_dto.freezed.dart';
part 'get_All_Applied_User_Profiles_By_Hiring_ID_response_dto.g.dart';

@freezed
class GetAllAppliedUserProfilesByHiringIdResponseDto
    with _$GetAllAppliedUserProfilesByHiringIdResponseDto {
  factory GetAllAppliedUserProfilesByHiringIdResponseDto({
    required int code,
    required String message,
    required List<GetAllAppliedUserProfilesByHiringIdDataDto> data,
  }) = _GetAllAppliedUserProfilesByHiringIdResponseDto;

  factory GetAllAppliedUserProfilesByHiringIdResponseDto.fromJson(
          Map<String, dynamic> json) =>
      _$GetAllAppliedUserProfilesByHiringIdResponseDtoFromJson(json);

  factory GetAllAppliedUserProfilesByHiringIdResponseDto.fromDomain(
      GetAllAppliedUserProfilesByHiringIdResponse domain) {
    return GetAllAppliedUserProfilesByHiringIdResponseDto(
      code: domain.code,
      message: domain.message,
      data: domain.data
          .map((p) => GetAllAppliedUserProfilesByHiringIdDataDto.fromDomain(p))
          .asList(),
    );
  }

  const GetAllAppliedUserProfilesByHiringIdResponseDto._();

  GetAllAppliedUserProfilesByHiringIdResponse toDomain() {
    return GetAllAppliedUserProfilesByHiringIdResponse(
      code: code,
      message: message,
      data: data.map((p) => p.toDomain()).toImmutableList(),
    );
  }
}
