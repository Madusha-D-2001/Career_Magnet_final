import 'package:carrermagnet/domain/get_all_applied_vacancies/get_all_applied_vacancies_data.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kt_dart/kt.dart';

part 'get_all_applied_vacancies_data_dto.freezed.dart';
part 'get_all_applied_vacancies_data_dto.g.dart';

@freezed
class GetAllAppliedVacanciesDataDto with _$GetAllAppliedVacanciesDataDto {
  factory GetAllAppliedVacanciesDataDto({
    required String hiringId,
    required String companyRespondStatus,
    required String message,
    required String recruiterID,
    required String jobDescription,
    required String jobType,
    required String location,
    required String companyName,
    required String postedDate,
    required String closeDate,
    required List<String> skillList,
  }) = _GetAllAppliedVacanciesDataDto;

  factory GetAllAppliedVacanciesDataDto.fromJson(Map<String, dynamic> json) =>
      _$GetAllAppliedVacanciesDataDtoFromJson(json);

  factory GetAllAppliedVacanciesDataDto.fromDomain(
      GetAllAppliedVacanciesData domain) {
    return GetAllAppliedVacanciesDataDto(
      hiringId: domain.hiringId,
      companyRespondStatus: domain.companyRespondStatus,
      message: domain.message,
      recruiterID: domain.recruiterID,
      jobDescription: domain.jobDescription,
      jobType: domain.jobType,
      location: domain.location,
      companyName: domain.companyName,
      postedDate: domain.postedDate,
      closeDate: domain.closeDate,
      skillList: domain.skillList.asList(),
    );
  }

  const GetAllAppliedVacanciesDataDto._();

  GetAllAppliedVacanciesData toDomain() {
    return GetAllAppliedVacanciesData(
      hiringId: hiringId,
      companyRespondStatus: companyRespondStatus,
      message: message,
      recruiterID: recruiterID,
      jobDescription: jobDescription,
      jobType: jobType,
      location: location,
      companyName: companyName,
      postedDate: postedDate,
      closeDate: closeDate,
      skillList: skillList.toImmutableList(),
    );
  }
}
