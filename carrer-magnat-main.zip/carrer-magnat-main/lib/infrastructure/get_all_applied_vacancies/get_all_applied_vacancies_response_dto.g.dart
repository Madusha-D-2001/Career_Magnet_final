// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'get_all_applied_vacancies_response_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$GetAllAppliedVacanciesResponseDtoImpl
    _$$GetAllAppliedVacanciesResponseDtoImplFromJson(
            Map<String, dynamic> json) =>
        _$GetAllAppliedVacanciesResponseDtoImpl(
          code: (json['code'] as num).toInt(),
          message: json['message'] as String,
          data: (json['data'] as List<dynamic>)
              .map((e) => GetAllAppliedVacanciesDataDto.fromJson(
                  e as Map<String, dynamic>))
              .toList(),
        );

Map<String, dynamic> _$$GetAllAppliedVacanciesResponseDtoImplToJson(
        _$GetAllAppliedVacanciesResponseDtoImpl instance) =>
    <String, dynamic>{
      'code': instance.code,
      'message': instance.message,
      'data': instance.data,
    };
