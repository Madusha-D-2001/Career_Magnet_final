// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'get_all_applied_vacancies_data_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

GetAllAppliedVacanciesDataDto _$GetAllAppliedVacanciesDataDtoFromJson(
    Map<String, dynamic> json) {
  return _GetAllAppliedVacanciesDataDto.fromJson(json);
}

/// @nodoc
mixin _$GetAllAppliedVacanciesDataDto {
  String get hiringId => throw _privateConstructorUsedError;
  String get companyRespondStatus => throw _privateConstructorUsedError;
  String get message => throw _privateConstructorUsedError;
  String get recruiterID => throw _privateConstructorUsedError;
  String get jobDescription => throw _privateConstructorUsedError;
  String get jobType => throw _privateConstructorUsedError;
  String get location => throw _privateConstructorUsedError;
  String get companyName => throw _privateConstructorUsedError;
  String get postedDate => throw _privateConstructorUsedError;
  String get closeDate => throw _privateConstructorUsedError;
  List<String> get skillList => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $GetAllAppliedVacanciesDataDtoCopyWith<GetAllAppliedVacanciesDataDto>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GetAllAppliedVacanciesDataDtoCopyWith<$Res> {
  factory $GetAllAppliedVacanciesDataDtoCopyWith(
          GetAllAppliedVacanciesDataDto value,
          $Res Function(GetAllAppliedVacanciesDataDto) then) =
      _$GetAllAppliedVacanciesDataDtoCopyWithImpl<$Res,
          GetAllAppliedVacanciesDataDto>;
  @useResult
  $Res call(
      {String hiringId,
      String companyRespondStatus,
      String message,
      String recruiterID,
      String jobDescription,
      String jobType,
      String location,
      String companyName,
      String postedDate,
      String closeDate,
      List<String> skillList});
}

/// @nodoc
class _$GetAllAppliedVacanciesDataDtoCopyWithImpl<$Res,
        $Val extends GetAllAppliedVacanciesDataDto>
    implements $GetAllAppliedVacanciesDataDtoCopyWith<$Res> {
  _$GetAllAppliedVacanciesDataDtoCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? hiringId = null,
    Object? companyRespondStatus = null,
    Object? message = null,
    Object? recruiterID = null,
    Object? jobDescription = null,
    Object? jobType = null,
    Object? location = null,
    Object? companyName = null,
    Object? postedDate = null,
    Object? closeDate = null,
    Object? skillList = null,
  }) {
    return _then(_value.copyWith(
      hiringId: null == hiringId
          ? _value.hiringId
          : hiringId // ignore: cast_nullable_to_non_nullable
              as String,
      companyRespondStatus: null == companyRespondStatus
          ? _value.companyRespondStatus
          : companyRespondStatus // ignore: cast_nullable_to_non_nullable
              as String,
      message: null == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String,
      recruiterID: null == recruiterID
          ? _value.recruiterID
          : recruiterID // ignore: cast_nullable_to_non_nullable
              as String,
      jobDescription: null == jobDescription
          ? _value.jobDescription
          : jobDescription // ignore: cast_nullable_to_non_nullable
              as String,
      jobType: null == jobType
          ? _value.jobType
          : jobType // ignore: cast_nullable_to_non_nullable
              as String,
      location: null == location
          ? _value.location
          : location // ignore: cast_nullable_to_non_nullable
              as String,
      companyName: null == companyName
          ? _value.companyName
          : companyName // ignore: cast_nullable_to_non_nullable
              as String,
      postedDate: null == postedDate
          ? _value.postedDate
          : postedDate // ignore: cast_nullable_to_non_nullable
              as String,
      closeDate: null == closeDate
          ? _value.closeDate
          : closeDate // ignore: cast_nullable_to_non_nullable
              as String,
      skillList: null == skillList
          ? _value.skillList
          : skillList // ignore: cast_nullable_to_non_nullable
              as List<String>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$GetAllAppliedVacanciesDataDtoImplCopyWith<$Res>
    implements $GetAllAppliedVacanciesDataDtoCopyWith<$Res> {
  factory _$$GetAllAppliedVacanciesDataDtoImplCopyWith(
          _$GetAllAppliedVacanciesDataDtoImpl value,
          $Res Function(_$GetAllAppliedVacanciesDataDtoImpl) then) =
      __$$GetAllAppliedVacanciesDataDtoImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String hiringId,
      String companyRespondStatus,
      String message,
      String recruiterID,
      String jobDescription,
      String jobType,
      String location,
      String companyName,
      String postedDate,
      String closeDate,
      List<String> skillList});
}

/// @nodoc
class __$$GetAllAppliedVacanciesDataDtoImplCopyWithImpl<$Res>
    extends _$GetAllAppliedVacanciesDataDtoCopyWithImpl<$Res,
        _$GetAllAppliedVacanciesDataDtoImpl>
    implements _$$GetAllAppliedVacanciesDataDtoImplCopyWith<$Res> {
  __$$GetAllAppliedVacanciesDataDtoImplCopyWithImpl(
      _$GetAllAppliedVacanciesDataDtoImpl _value,
      $Res Function(_$GetAllAppliedVacanciesDataDtoImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? hiringId = null,
    Object? companyRespondStatus = null,
    Object? message = null,
    Object? recruiterID = null,
    Object? jobDescription = null,
    Object? jobType = null,
    Object? location = null,
    Object? companyName = null,
    Object? postedDate = null,
    Object? closeDate = null,
    Object? skillList = null,
  }) {
    return _then(_$GetAllAppliedVacanciesDataDtoImpl(
      hiringId: null == hiringId
          ? _value.hiringId
          : hiringId // ignore: cast_nullable_to_non_nullable
              as String,
      companyRespondStatus: null == companyRespondStatus
          ? _value.companyRespondStatus
          : companyRespondStatus // ignore: cast_nullable_to_non_nullable
              as String,
      message: null == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String,
      recruiterID: null == recruiterID
          ? _value.recruiterID
          : recruiterID // ignore: cast_nullable_to_non_nullable
              as String,
      jobDescription: null == jobDescription
          ? _value.jobDescription
          : jobDescription // ignore: cast_nullable_to_non_nullable
              as String,
      jobType: null == jobType
          ? _value.jobType
          : jobType // ignore: cast_nullable_to_non_nullable
              as String,
      location: null == location
          ? _value.location
          : location // ignore: cast_nullable_to_non_nullable
              as String,
      companyName: null == companyName
          ? _value.companyName
          : companyName // ignore: cast_nullable_to_non_nullable
              as String,
      postedDate: null == postedDate
          ? _value.postedDate
          : postedDate // ignore: cast_nullable_to_non_nullable
              as String,
      closeDate: null == closeDate
          ? _value.closeDate
          : closeDate // ignore: cast_nullable_to_non_nullable
              as String,
      skillList: null == skillList
          ? _value._skillList
          : skillList // ignore: cast_nullable_to_non_nullable
              as List<String>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$GetAllAppliedVacanciesDataDtoImpl
    extends _GetAllAppliedVacanciesDataDto {
  _$GetAllAppliedVacanciesDataDtoImpl(
      {required this.hiringId,
      required this.companyRespondStatus,
      required this.message,
      required this.recruiterID,
      required this.jobDescription,
      required this.jobType,
      required this.location,
      required this.companyName,
      required this.postedDate,
      required this.closeDate,
      required final List<String> skillList})
      : _skillList = skillList,
        super._();

  factory _$GetAllAppliedVacanciesDataDtoImpl.fromJson(
          Map<String, dynamic> json) =>
      _$$GetAllAppliedVacanciesDataDtoImplFromJson(json);

  @override
  final String hiringId;
  @override
  final String companyRespondStatus;
  @override
  final String message;
  @override
  final String recruiterID;
  @override
  final String jobDescription;
  @override
  final String jobType;
  @override
  final String location;
  @override
  final String companyName;
  @override
  final String postedDate;
  @override
  final String closeDate;
  final List<String> _skillList;
  @override
  List<String> get skillList {
    if (_skillList is EqualUnmodifiableListView) return _skillList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_skillList);
  }

  @override
  String toString() {
    return 'GetAllAppliedVacanciesDataDto(hiringId: $hiringId, companyRespondStatus: $companyRespondStatus, message: $message, recruiterID: $recruiterID, jobDescription: $jobDescription, jobType: $jobType, location: $location, companyName: $companyName, postedDate: $postedDate, closeDate: $closeDate, skillList: $skillList)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetAllAppliedVacanciesDataDtoImpl &&
            (identical(other.hiringId, hiringId) ||
                other.hiringId == hiringId) &&
            (identical(other.companyRespondStatus, companyRespondStatus) ||
                other.companyRespondStatus == companyRespondStatus) &&
            (identical(other.message, message) || other.message == message) &&
            (identical(other.recruiterID, recruiterID) ||
                other.recruiterID == recruiterID) &&
            (identical(other.jobDescription, jobDescription) ||
                other.jobDescription == jobDescription) &&
            (identical(other.jobType, jobType) || other.jobType == jobType) &&
            (identical(other.location, location) ||
                other.location == location) &&
            (identical(other.companyName, companyName) ||
                other.companyName == companyName) &&
            (identical(other.postedDate, postedDate) ||
                other.postedDate == postedDate) &&
            (identical(other.closeDate, closeDate) ||
                other.closeDate == closeDate) &&
            const DeepCollectionEquality()
                .equals(other._skillList, _skillList));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      hiringId,
      companyRespondStatus,
      message,
      recruiterID,
      jobDescription,
      jobType,
      location,
      companyName,
      postedDate,
      closeDate,
      const DeepCollectionEquality().hash(_skillList));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetAllAppliedVacanciesDataDtoImplCopyWith<
          _$GetAllAppliedVacanciesDataDtoImpl>
      get copyWith => __$$GetAllAppliedVacanciesDataDtoImplCopyWithImpl<
          _$GetAllAppliedVacanciesDataDtoImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$GetAllAppliedVacanciesDataDtoImplToJson(
      this,
    );
  }
}

abstract class _GetAllAppliedVacanciesDataDto
    extends GetAllAppliedVacanciesDataDto {
  factory _GetAllAppliedVacanciesDataDto(
          {required final String hiringId,
          required final String companyRespondStatus,
          required final String message,
          required final String recruiterID,
          required final String jobDescription,
          required final String jobType,
          required final String location,
          required final String companyName,
          required final String postedDate,
          required final String closeDate,
          required final List<String> skillList}) =
      _$GetAllAppliedVacanciesDataDtoImpl;
  _GetAllAppliedVacanciesDataDto._() : super._();

  factory _GetAllAppliedVacanciesDataDto.fromJson(Map<String, dynamic> json) =
      _$GetAllAppliedVacanciesDataDtoImpl.fromJson;

  @override
  String get hiringId;
  @override
  String get companyRespondStatus;
  @override
  String get message;
  @override
  String get recruiterID;
  @override
  String get jobDescription;
  @override
  String get jobType;
  @override
  String get location;
  @override
  String get companyName;
  @override
  String get postedDate;
  @override
  String get closeDate;
  @override
  List<String> get skillList;
  @override
  @JsonKey(ignore: true)
  _$$GetAllAppliedVacanciesDataDtoImplCopyWith<
          _$GetAllAppliedVacanciesDataDtoImpl>
      get copyWith => throw _privateConstructorUsedError;
}
