import 'package:carrermagnet/infrastructure/get_all_applied_vacancies/get_all_applied_vacancies_data_dto.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kt_dart/kt.dart';

import '../../domain/get_all_applied_vacancies/get_all_applied_vacancies_response.dart';

part 'get_all_applied_vacancies_response_dto.freezed.dart';
part 'get_all_applied_vacancies_response_dto.g.dart';

@freezed
class GetAllAppliedVacanciesResponseDto
    with _$GetAllAppliedVacanciesResponseDto {
  factory GetAllAppliedVacanciesResponseDto({
    required int code,
    required String message,
    required List<GetAllAppliedVacanciesDataDto> data,
  }) = _GetAllAppliedVacanciesResponseDto;

  factory GetAllAppliedVacanciesResponseDto.fromJson(
          Map<String, dynamic> json) =>
      _$GetAllAppliedVacanciesResponseDtoFromJson(json);

  factory GetAllAppliedVacanciesResponseDto.fromDomain(
      GetAllAppliedVacanciesResponse domain) {
    return GetAllAppliedVacanciesResponseDto(
      code: domain.code,
      message: domain.message,
      data: domain.data
          .map((p) => GetAllAppliedVacanciesDataDto.fromDomain(p))
          .asList(),
    );
  }

  const GetAllAppliedVacanciesResponseDto._();

  GetAllAppliedVacanciesResponse toDomain() {
    return GetAllAppliedVacanciesResponse(
      code: code,
      message: message,
      data: data.map((p) => p.toDomain()).toImmutableList(),
    );
  }
}
