// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'get_all_applied_vacancies_data_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$GetAllAppliedVacanciesDataDtoImpl
    _$$GetAllAppliedVacanciesDataDtoImplFromJson(Map<String, dynamic> json) =>
        _$GetAllAppliedVacanciesDataDtoImpl(
          hiringId: json['hiringId'] as String,
          companyRespondStatus: json['companyRespondStatus'] as String,
          message: json['message'] as String,
          recruiterID: json['recruiterID'] as String,
          jobDescription: json['jobDescription'] as String,
          jobType: json['jobType'] as String,
          location: json['location'] as String,
          companyName: json['companyName'] as String,
          postedDate: json['postedDate'] as String,
          closeDate: json['closeDate'] as String,
          skillList: (json['skillList'] as List<dynamic>)
              .map((e) => e as String)
              .toList(),
        );

Map<String, dynamic> _$$GetAllAppliedVacanciesDataDtoImplToJson(
        _$GetAllAppliedVacanciesDataDtoImpl instance) =>
    <String, dynamic>{
      'hiringId': instance.hiringId,
      'companyRespondStatus': instance.companyRespondStatus,
      'message': instance.message,
      'recruiterID': instance.recruiterID,
      'jobDescription': instance.jobDescription,
      'jobType': instance.jobType,
      'location': instance.location,
      'companyName': instance.companyName,
      'postedDate': instance.postedDate,
      'closeDate': instance.closeDate,
      'skillList': instance.skillList,
    };
