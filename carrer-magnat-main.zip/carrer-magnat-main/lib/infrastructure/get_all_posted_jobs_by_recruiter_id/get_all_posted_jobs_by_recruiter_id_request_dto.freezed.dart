// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'get_all_posted_jobs_by_recruiter_id_request_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

GetAllPostedJobsByRecruiterIdRequestDto
    _$GetAllPostedJobsByRecruiterIdRequestDtoFromJson(
        Map<String, dynamic> json) {
  return _GetAllPostedJobsByRecruiterIdRequestDto.fromJson(json);
}

/// @nodoc
mixin _$GetAllPostedJobsByRecruiterIdRequestDto {
  int get code => throw _privateConstructorUsedError;
  String get message => throw _privateConstructorUsedError;
  List<GetAllPostedJobsByRecruiterDataDto> get data =>
      throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $GetAllPostedJobsByRecruiterIdRequestDtoCopyWith<
          GetAllPostedJobsByRecruiterIdRequestDto>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GetAllPostedJobsByRecruiterIdRequestDtoCopyWith<$Res> {
  factory $GetAllPostedJobsByRecruiterIdRequestDtoCopyWith(
          GetAllPostedJobsByRecruiterIdRequestDto value,
          $Res Function(GetAllPostedJobsByRecruiterIdRequestDto) then) =
      _$GetAllPostedJobsByRecruiterIdRequestDtoCopyWithImpl<$Res,
          GetAllPostedJobsByRecruiterIdRequestDto>;
  @useResult
  $Res call(
      {int code,
      String message,
      List<GetAllPostedJobsByRecruiterDataDto> data});
}

/// @nodoc
class _$GetAllPostedJobsByRecruiterIdRequestDtoCopyWithImpl<$Res,
        $Val extends GetAllPostedJobsByRecruiterIdRequestDto>
    implements $GetAllPostedJobsByRecruiterIdRequestDtoCopyWith<$Res> {
  _$GetAllPostedJobsByRecruiterIdRequestDtoCopyWithImpl(
      this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? code = null,
    Object? message = null,
    Object? data = null,
  }) {
    return _then(_value.copyWith(
      code: null == code
          ? _value.code
          : code // ignore: cast_nullable_to_non_nullable
              as int,
      message: null == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String,
      data: null == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as List<GetAllPostedJobsByRecruiterDataDto>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$GetAllPostedJobsByRecruiterIdRequestDtoImplCopyWith<$Res>
    implements $GetAllPostedJobsByRecruiterIdRequestDtoCopyWith<$Res> {
  factory _$$GetAllPostedJobsByRecruiterIdRequestDtoImplCopyWith(
          _$GetAllPostedJobsByRecruiterIdRequestDtoImpl value,
          $Res Function(_$GetAllPostedJobsByRecruiterIdRequestDtoImpl) then) =
      __$$GetAllPostedJobsByRecruiterIdRequestDtoImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {int code,
      String message,
      List<GetAllPostedJobsByRecruiterDataDto> data});
}

/// @nodoc
class __$$GetAllPostedJobsByRecruiterIdRequestDtoImplCopyWithImpl<$Res>
    extends _$GetAllPostedJobsByRecruiterIdRequestDtoCopyWithImpl<$Res,
        _$GetAllPostedJobsByRecruiterIdRequestDtoImpl>
    implements _$$GetAllPostedJobsByRecruiterIdRequestDtoImplCopyWith<$Res> {
  __$$GetAllPostedJobsByRecruiterIdRequestDtoImplCopyWithImpl(
      _$GetAllPostedJobsByRecruiterIdRequestDtoImpl _value,
      $Res Function(_$GetAllPostedJobsByRecruiterIdRequestDtoImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? code = null,
    Object? message = null,
    Object? data = null,
  }) {
    return _then(_$GetAllPostedJobsByRecruiterIdRequestDtoImpl(
      code: null == code
          ? _value.code
          : code // ignore: cast_nullable_to_non_nullable
              as int,
      message: null == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String,
      data: null == data
          ? _value._data
          : data // ignore: cast_nullable_to_non_nullable
              as List<GetAllPostedJobsByRecruiterDataDto>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$GetAllPostedJobsByRecruiterIdRequestDtoImpl
    extends _GetAllPostedJobsByRecruiterIdRequestDto {
  _$GetAllPostedJobsByRecruiterIdRequestDtoImpl(
      {required this.code,
      required this.message,
      required final List<GetAllPostedJobsByRecruiterDataDto> data})
      : _data = data,
        super._();

  factory _$GetAllPostedJobsByRecruiterIdRequestDtoImpl.fromJson(
          Map<String, dynamic> json) =>
      _$$GetAllPostedJobsByRecruiterIdRequestDtoImplFromJson(json);

  @override
  final int code;
  @override
  final String message;
  final List<GetAllPostedJobsByRecruiterDataDto> _data;
  @override
  List<GetAllPostedJobsByRecruiterDataDto> get data {
    if (_data is EqualUnmodifiableListView) return _data;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_data);
  }

  @override
  String toString() {
    return 'GetAllPostedJobsByRecruiterIdRequestDto(code: $code, message: $message, data: $data)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetAllPostedJobsByRecruiterIdRequestDtoImpl &&
            (identical(other.code, code) || other.code == code) &&
            (identical(other.message, message) || other.message == message) &&
            const DeepCollectionEquality().equals(other._data, _data));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, code, message, const DeepCollectionEquality().hash(_data));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetAllPostedJobsByRecruiterIdRequestDtoImplCopyWith<
          _$GetAllPostedJobsByRecruiterIdRequestDtoImpl>
      get copyWith =>
          __$$GetAllPostedJobsByRecruiterIdRequestDtoImplCopyWithImpl<
              _$GetAllPostedJobsByRecruiterIdRequestDtoImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$GetAllPostedJobsByRecruiterIdRequestDtoImplToJson(
      this,
    );
  }
}

abstract class _GetAllPostedJobsByRecruiterIdRequestDto
    extends GetAllPostedJobsByRecruiterIdRequestDto {
  factory _GetAllPostedJobsByRecruiterIdRequestDto(
          {required final int code,
          required final String message,
          required final List<GetAllPostedJobsByRecruiterDataDto> data}) =
      _$GetAllPostedJobsByRecruiterIdRequestDtoImpl;
  _GetAllPostedJobsByRecruiterIdRequestDto._() : super._();

  factory _GetAllPostedJobsByRecruiterIdRequestDto.fromJson(
          Map<String, dynamic> json) =
      _$GetAllPostedJobsByRecruiterIdRequestDtoImpl.fromJson;

  @override
  int get code;
  @override
  String get message;
  @override
  List<GetAllPostedJobsByRecruiterDataDto> get data;
  @override
  @JsonKey(ignore: true)
  _$$GetAllPostedJobsByRecruiterIdRequestDtoImplCopyWith<
          _$GetAllPostedJobsByRecruiterIdRequestDtoImpl>
      get copyWith => throw _privateConstructorUsedError;
}
