// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'get_all_posted_jobs_by_recruiter_id_request_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$GetAllPostedJobsByRecruiterIdRequestDtoImpl
    _$$GetAllPostedJobsByRecruiterIdRequestDtoImplFromJson(
            Map<String, dynamic> json) =>
        _$GetAllPostedJobsByRecruiterIdRequestDtoImpl(
          code: (json['code'] as num).toInt(),
          message: json['message'] as String,
          data: (json['data'] as List<dynamic>)
              .map((e) => GetAllPostedJobsByRecruiterDataDto.fromJson(
                  e as Map<String, dynamic>))
              .toList(),
        );

Map<String, dynamic> _$$GetAllPostedJobsByRecruiterIdRequestDtoImplToJson(
        _$GetAllPostedJobsByRecruiterIdRequestDtoImpl instance) =>
    <String, dynamic>{
      'code': instance.code,
      'message': instance.message,
      'data': instance.data,
    };
