// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'get_all_posted_jobs_by_recruiter_data_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

GetAllPostedJobsByRecruiterDataDto _$GetAllPostedJobsByRecruiterDataDtoFromJson(
    Map<String, dynamic> json) {
  return _GetAllPostedJobsByRecruiterDataDto.fromJson(json);
}

/// @nodoc
mixin _$GetAllPostedJobsByRecruiterDataDto {
  String get id => throw _privateConstructorUsedError;
  String get recruiterID => throw _privateConstructorUsedError;
  String get jobDescription => throw _privateConstructorUsedError;
  String get jobType => throw _privateConstructorUsedError;
  String get location => throw _privateConstructorUsedError;
  String get companyName => throw _privateConstructorUsedError;
  String get postedDate => throw _privateConstructorUsedError;
  String get closeDate => throw _privateConstructorUsedError;
  List<String> get skillList => throw _privateConstructorUsedError;
  bool get selectedStatus => throw _privateConstructorUsedError;
  String get selectedUserProfile => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $GetAllPostedJobsByRecruiterDataDtoCopyWith<
          GetAllPostedJobsByRecruiterDataDto>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GetAllPostedJobsByRecruiterDataDtoCopyWith<$Res> {
  factory $GetAllPostedJobsByRecruiterDataDtoCopyWith(
          GetAllPostedJobsByRecruiterDataDto value,
          $Res Function(GetAllPostedJobsByRecruiterDataDto) then) =
      _$GetAllPostedJobsByRecruiterDataDtoCopyWithImpl<$Res,
          GetAllPostedJobsByRecruiterDataDto>;
  @useResult
  $Res call(
      {String id,
      String recruiterID,
      String jobDescription,
      String jobType,
      String location,
      String companyName,
      String postedDate,
      String closeDate,
      List<String> skillList,
      bool selectedStatus,
      String selectedUserProfile});
}

/// @nodoc
class _$GetAllPostedJobsByRecruiterDataDtoCopyWithImpl<$Res,
        $Val extends GetAllPostedJobsByRecruiterDataDto>
    implements $GetAllPostedJobsByRecruiterDataDtoCopyWith<$Res> {
  _$GetAllPostedJobsByRecruiterDataDtoCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? recruiterID = null,
    Object? jobDescription = null,
    Object? jobType = null,
    Object? location = null,
    Object? companyName = null,
    Object? postedDate = null,
    Object? closeDate = null,
    Object? skillList = null,
    Object? selectedStatus = null,
    Object? selectedUserProfile = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      recruiterID: null == recruiterID
          ? _value.recruiterID
          : recruiterID // ignore: cast_nullable_to_non_nullable
              as String,
      jobDescription: null == jobDescription
          ? _value.jobDescription
          : jobDescription // ignore: cast_nullable_to_non_nullable
              as String,
      jobType: null == jobType
          ? _value.jobType
          : jobType // ignore: cast_nullable_to_non_nullable
              as String,
      location: null == location
          ? _value.location
          : location // ignore: cast_nullable_to_non_nullable
              as String,
      companyName: null == companyName
          ? _value.companyName
          : companyName // ignore: cast_nullable_to_non_nullable
              as String,
      postedDate: null == postedDate
          ? _value.postedDate
          : postedDate // ignore: cast_nullable_to_non_nullable
              as String,
      closeDate: null == closeDate
          ? _value.closeDate
          : closeDate // ignore: cast_nullable_to_non_nullable
              as String,
      skillList: null == skillList
          ? _value.skillList
          : skillList // ignore: cast_nullable_to_non_nullable
              as List<String>,
      selectedStatus: null == selectedStatus
          ? _value.selectedStatus
          : selectedStatus // ignore: cast_nullable_to_non_nullable
              as bool,
      selectedUserProfile: null == selectedUserProfile
          ? _value.selectedUserProfile
          : selectedUserProfile // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$GetAllPostedJobsByRecruiterDataDtoImplCopyWith<$Res>
    implements $GetAllPostedJobsByRecruiterDataDtoCopyWith<$Res> {
  factory _$$GetAllPostedJobsByRecruiterDataDtoImplCopyWith(
          _$GetAllPostedJobsByRecruiterDataDtoImpl value,
          $Res Function(_$GetAllPostedJobsByRecruiterDataDtoImpl) then) =
      __$$GetAllPostedJobsByRecruiterDataDtoImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String recruiterID,
      String jobDescription,
      String jobType,
      String location,
      String companyName,
      String postedDate,
      String closeDate,
      List<String> skillList,
      bool selectedStatus,
      String selectedUserProfile});
}

/// @nodoc
class __$$GetAllPostedJobsByRecruiterDataDtoImplCopyWithImpl<$Res>
    extends _$GetAllPostedJobsByRecruiterDataDtoCopyWithImpl<$Res,
        _$GetAllPostedJobsByRecruiterDataDtoImpl>
    implements _$$GetAllPostedJobsByRecruiterDataDtoImplCopyWith<$Res> {
  __$$GetAllPostedJobsByRecruiterDataDtoImplCopyWithImpl(
      _$GetAllPostedJobsByRecruiterDataDtoImpl _value,
      $Res Function(_$GetAllPostedJobsByRecruiterDataDtoImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? recruiterID = null,
    Object? jobDescription = null,
    Object? jobType = null,
    Object? location = null,
    Object? companyName = null,
    Object? postedDate = null,
    Object? closeDate = null,
    Object? skillList = null,
    Object? selectedStatus = null,
    Object? selectedUserProfile = null,
  }) {
    return _then(_$GetAllPostedJobsByRecruiterDataDtoImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      recruiterID: null == recruiterID
          ? _value.recruiterID
          : recruiterID // ignore: cast_nullable_to_non_nullable
              as String,
      jobDescription: null == jobDescription
          ? _value.jobDescription
          : jobDescription // ignore: cast_nullable_to_non_nullable
              as String,
      jobType: null == jobType
          ? _value.jobType
          : jobType // ignore: cast_nullable_to_non_nullable
              as String,
      location: null == location
          ? _value.location
          : location // ignore: cast_nullable_to_non_nullable
              as String,
      companyName: null == companyName
          ? _value.companyName
          : companyName // ignore: cast_nullable_to_non_nullable
              as String,
      postedDate: null == postedDate
          ? _value.postedDate
          : postedDate // ignore: cast_nullable_to_non_nullable
              as String,
      closeDate: null == closeDate
          ? _value.closeDate
          : closeDate // ignore: cast_nullable_to_non_nullable
              as String,
      skillList: null == skillList
          ? _value._skillList
          : skillList // ignore: cast_nullable_to_non_nullable
              as List<String>,
      selectedStatus: null == selectedStatus
          ? _value.selectedStatus
          : selectedStatus // ignore: cast_nullable_to_non_nullable
              as bool,
      selectedUserProfile: null == selectedUserProfile
          ? _value.selectedUserProfile
          : selectedUserProfile // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$GetAllPostedJobsByRecruiterDataDtoImpl
    extends _GetAllPostedJobsByRecruiterDataDto {
  _$GetAllPostedJobsByRecruiterDataDtoImpl(
      {required this.id,
      required this.recruiterID,
      required this.jobDescription,
      required this.jobType,
      required this.location,
      required this.companyName,
      required this.postedDate,
      required this.closeDate,
      required final List<String> skillList,
      required this.selectedStatus,
      required this.selectedUserProfile})
      : _skillList = skillList,
        super._();

  factory _$GetAllPostedJobsByRecruiterDataDtoImpl.fromJson(
          Map<String, dynamic> json) =>
      _$$GetAllPostedJobsByRecruiterDataDtoImplFromJson(json);

  @override
  final String id;
  @override
  final String recruiterID;
  @override
  final String jobDescription;
  @override
  final String jobType;
  @override
  final String location;
  @override
  final String companyName;
  @override
  final String postedDate;
  @override
  final String closeDate;
  final List<String> _skillList;
  @override
  List<String> get skillList {
    if (_skillList is EqualUnmodifiableListView) return _skillList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_skillList);
  }

  @override
  final bool selectedStatus;
  @override
  final String selectedUserProfile;

  @override
  String toString() {
    return 'GetAllPostedJobsByRecruiterDataDto(id: $id, recruiterID: $recruiterID, jobDescription: $jobDescription, jobType: $jobType, location: $location, companyName: $companyName, postedDate: $postedDate, closeDate: $closeDate, skillList: $skillList, selectedStatus: $selectedStatus, selectedUserProfile: $selectedUserProfile)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetAllPostedJobsByRecruiterDataDtoImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.recruiterID, recruiterID) ||
                other.recruiterID == recruiterID) &&
            (identical(other.jobDescription, jobDescription) ||
                other.jobDescription == jobDescription) &&
            (identical(other.jobType, jobType) || other.jobType == jobType) &&
            (identical(other.location, location) ||
                other.location == location) &&
            (identical(other.companyName, companyName) ||
                other.companyName == companyName) &&
            (identical(other.postedDate, postedDate) ||
                other.postedDate == postedDate) &&
            (identical(other.closeDate, closeDate) ||
                other.closeDate == closeDate) &&
            const DeepCollectionEquality()
                .equals(other._skillList, _skillList) &&
            (identical(other.selectedStatus, selectedStatus) ||
                other.selectedStatus == selectedStatus) &&
            (identical(other.selectedUserProfile, selectedUserProfile) ||
                other.selectedUserProfile == selectedUserProfile));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      recruiterID,
      jobDescription,
      jobType,
      location,
      companyName,
      postedDate,
      closeDate,
      const DeepCollectionEquality().hash(_skillList),
      selectedStatus,
      selectedUserProfile);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetAllPostedJobsByRecruiterDataDtoImplCopyWith<
          _$GetAllPostedJobsByRecruiterDataDtoImpl>
      get copyWith => __$$GetAllPostedJobsByRecruiterDataDtoImplCopyWithImpl<
          _$GetAllPostedJobsByRecruiterDataDtoImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$GetAllPostedJobsByRecruiterDataDtoImplToJson(
      this,
    );
  }
}

abstract class _GetAllPostedJobsByRecruiterDataDto
    extends GetAllPostedJobsByRecruiterDataDto {
  factory _GetAllPostedJobsByRecruiterDataDto(
          {required final String id,
          required final String recruiterID,
          required final String jobDescription,
          required final String jobType,
          required final String location,
          required final String companyName,
          required final String postedDate,
          required final String closeDate,
          required final List<String> skillList,
          required final bool selectedStatus,
          required final String selectedUserProfile}) =
      _$GetAllPostedJobsByRecruiterDataDtoImpl;
  _GetAllPostedJobsByRecruiterDataDto._() : super._();

  factory _GetAllPostedJobsByRecruiterDataDto.fromJson(
          Map<String, dynamic> json) =
      _$GetAllPostedJobsByRecruiterDataDtoImpl.fromJson;

  @override
  String get id;
  @override
  String get recruiterID;
  @override
  String get jobDescription;
  @override
  String get jobType;
  @override
  String get location;
  @override
  String get companyName;
  @override
  String get postedDate;
  @override
  String get closeDate;
  @override
  List<String> get skillList;
  @override
  bool get selectedStatus;
  @override
  String get selectedUserProfile;
  @override
  @JsonKey(ignore: true)
  _$$GetAllPostedJobsByRecruiterDataDtoImplCopyWith<
          _$GetAllPostedJobsByRecruiterDataDtoImpl>
      get copyWith => throw _privateConstructorUsedError;
}
