import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kt_dart/kt.dart';

import '../../domain/get_all_posted_jobs_by_recruiter_id/get_all_posted_jobs_by_recruiter_data.dart';

part 'get_all_posted_jobs_by_recruiter_data_dto.freezed.dart';
part 'get_all_posted_jobs_by_recruiter_data_dto.g.dart';

@freezed
class GetAllPostedJobsByRecruiterDataDto
    with _$GetAllPostedJobsByRecruiterDataDto {
  factory GetAllPostedJobsByRecruiterDataDto({
    required String id,
    required String recruiterID,
    required String jobDescription,
    required String jobType,
    required String location,
    required String companyName,
    required String postedDate,
    required String closeDate,
    required List<String> skillList,
    required bool selectedStatus,
    required String selectedUserProfile,
  }) = _GetAllPostedJobsByRecruiterDataDto;

  factory GetAllPostedJobsByRecruiterDataDto.fromJson(
          Map<String, dynamic> json) =>
      _$GetAllPostedJobsByRecruiterDataDtoFromJson(json);

  factory GetAllPostedJobsByRecruiterDataDto.fromDomain(
      GetAllPostedJobsByRecruiterData domain) {
    return GetAllPostedJobsByRecruiterDataDto(
      id: domain.id,
      recruiterID: domain.recruiterID,
      jobDescription: domain.jobDescription,
      jobType: domain.jobType,
      location: domain.location,
      companyName: domain.companyName,
      postedDate: domain.postedDate,
      closeDate: domain.closeDate,
      skillList: domain.skillList.asList(),
      selectedStatus: domain.selectedStatus,
      selectedUserProfile: domain.selectedUserProfile,
    );
  }
  const GetAllPostedJobsByRecruiterDataDto._();

  GetAllPostedJobsByRecruiterData toDomain() {
    return GetAllPostedJobsByRecruiterData(
      id: id,
      recruiterID: recruiterID,
      jobDescription: jobDescription,
      jobType: jobType,
      location: location,
      companyName: companyName,
      postedDate: postedDate,
      closeDate: closeDate,
      skillList: skillList.toImmutableList(),
      selectedStatus: selectedStatus,
      selectedUserProfile: selectedUserProfile,
    );
  }
}
