import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kt_dart/kt.dart';

import '../../domain/get_all_posted_jobs_by_recruiter_id/get_all_posted_jobs_by_recruiter_id_request.dart';
import 'get_all_posted_jobs_by_recruiter_data_dto.dart';

part 'get_all_posted_jobs_by_recruiter_id_request_dto.freezed.dart';
part 'get_all_posted_jobs_by_recruiter_id_request_dto.g.dart';

@freezed
class GetAllPostedJobsByRecruiterIdRequestDto
    with _$GetAllPostedJobsByRecruiterIdRequestDto {
  factory GetAllPostedJobsByRecruiterIdRequestDto({
    required int code,
    required String message,
    required List<GetAllPostedJobsByRecruiterDataDto> data,
  }) = _GetAllPostedJobsByRecruiterIdRequestDto;

  factory GetAllPostedJobsByRecruiterIdRequestDto.fromJson(
          Map<String, dynamic> json) =>
      _$GetAllPostedJobsByRecruiterIdRequestDtoFromJson(json);

  factory GetAllPostedJobsByRecruiterIdRequestDto.fromDomain(
      GetAllPostedJobsByRecruiterIdRequest domain) {
    return GetAllPostedJobsByRecruiterIdRequestDto(
      code: domain.code,
      message: domain.message,
      data: domain.data
          .map((p) => GetAllPostedJobsByRecruiterDataDto.fromDomain(p))
          .asList(),
    );
  }

  const GetAllPostedJobsByRecruiterIdRequestDto._();

  GetAllPostedJobsByRecruiterIdRequest toDomain() {
    return GetAllPostedJobsByRecruiterIdRequest(
      code: code,
      message: message,
      data: data.map((p) => p.toDomain()).toImmutableList(),
    );
  }
}
