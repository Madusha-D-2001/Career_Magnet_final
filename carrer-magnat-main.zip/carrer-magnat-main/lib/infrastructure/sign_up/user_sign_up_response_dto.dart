import 'package:freezed_annotation/freezed_annotation.dart';

import '../../domain/sign_up/user_sign_up_response.dart';
import 'user_data_dto.dart';

part 'user_sign_up_response_dto.freezed.dart';
part 'user_sign_up_response_dto.g.dart';

@freezed
class UserSignUpResponseDto with _$UserSignUpResponseDto {
  factory UserSignUpResponseDto({
    required int code,
    required String message,
    required UserDataDto data,
  }) = _UserSignUpResponseDto;

  factory UserSignUpResponseDto.fromJson(Map<String, dynamic> json) =>
      _$UserSignUpResponseDtoFromJson(json);

  factory UserSignUpResponseDto.fromDomain(UserSignUpResponse domain) {
    return UserSignUpResponseDto(
      code: domain.code,
      message: domain.message,
      data: UserDataDto.fromDomain(domain.data),
    );
  }

  const UserSignUpResponseDto._();

  UserSignUpResponse toDomain() {
    return UserSignUpResponse(
      code: code,
      message: message,
      data: data.toDomain(),
    );
  }
}
