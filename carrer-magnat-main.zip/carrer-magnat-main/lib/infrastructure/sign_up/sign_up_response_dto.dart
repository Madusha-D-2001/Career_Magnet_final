import 'package:carrermagnet/domain/sign_up/sign_up_response.dart';
import 'package:carrermagnet/infrastructure/sign_up/data_dto.dart';

import 'package:freezed_annotation/freezed_annotation.dart';

part 'sign_up_response_dto.freezed.dart';
part 'sign_up_response_dto.g.dart';

@freezed
class SignUpResponseDto with _$SignUpResponseDto {
  factory SignUpResponseDto({
    required int code,
    required String message,
    required DataDto data,
  }) = _SignUpResponseDto;

  factory SignUpResponseDto.fromJson(Map<String, dynamic> json) =>
      _$SignUpResponseDtoFromJson(json);

  factory SignUpResponseDto.fromDomain(SignUpResponse domain) {
    return SignUpResponseDto(
        code: domain.code,
        message: domain.message,
        data: DataDto.fromDomain(domain.data));
  }

  const SignUpResponseDto._();

  SignUpResponse toDomain() {
    return SignUpResponse(
      code: code,
      message: message,
      data: data.toDomain(),
    );
  }
}
