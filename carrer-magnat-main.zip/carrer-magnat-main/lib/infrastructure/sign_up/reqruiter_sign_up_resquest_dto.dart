import 'package:carrermagnet/domain/sign_up/reqruiter_sign_up_resquest.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'reqruiter_sign_up_resquest_dto.freezed.dart';
part 'reqruiter_sign_up_resquest_dto.g.dart';

@freezed
class ReqruiterSignUpResquestDto with _$ReqruiterSignUpResquestDto {
  factory ReqruiterSignUpResquestDto({
    required String first_name,
    required String last_name,
    required String email,
    required String contact,
    required String password,
    required String company,
  }) = _ReqruiterSignUpResquestDto;

  factory ReqruiterSignUpResquestDto.fromJson(Map<String, dynamic> json) =>
      _$ReqruiterSignUpResquestDtoFromJson(json);

  factory ReqruiterSignUpResquestDto.fromDomain(
      ReqruiterSignUpResquest domain) {
    return ReqruiterSignUpResquestDto(
      first_name: domain.first_name,
      last_name: domain.last_name,
      email: domain.email,
      contact: domain.contact,
      password: domain.password,
      company: domain.company,
    );
  }

  const ReqruiterSignUpResquestDto._();

  ReqruiterSignUpResquest toDomain() {
    return ReqruiterSignUpResquest(
      first_name: first_name,
      last_name: last_name,
      email: email,
      contact: contact,
      password: password,
      company: company,
    );
  }
}
