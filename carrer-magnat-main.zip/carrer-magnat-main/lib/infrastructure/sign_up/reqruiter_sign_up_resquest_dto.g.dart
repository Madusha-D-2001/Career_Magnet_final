// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'reqruiter_sign_up_resquest_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$ReqruiterSignUpResquestDtoImpl _$$ReqruiterSignUpResquestDtoImplFromJson(
        Map<String, dynamic> json) =>
    _$ReqruiterSignUpResquestDtoImpl(
      first_name: json['first_name'] as String,
      last_name: json['last_name'] as String,
      email: json['email'] as String,
      contact: json['contact'] as String,
      password: json['password'] as String,
      company: json['company'] as String,
    );

Map<String, dynamic> _$$ReqruiterSignUpResquestDtoImplToJson(
        _$ReqruiterSignUpResquestDtoImpl instance) =>
    <String, dynamic>{
      'first_name': instance.first_name,
      'last_name': instance.last_name,
      'email': instance.email,
      'contact': instance.contact,
      'password': instance.password,
      'company': instance.company,
    };
