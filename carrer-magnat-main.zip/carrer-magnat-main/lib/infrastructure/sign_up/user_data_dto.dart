import 'package:carrermagnet/domain/sign_up/user_data.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'user_data_dto.freezed.dart';
part 'user_data_dto.g.dart';

@freezed
class UserDataDto with _$UserDataDto {
  factory UserDataDto({
    required String user_id,
    required String role,
    required String access_token,
    required String refresh_token,
  }) = _UserDataDto;

  factory UserDataDto.fromJson(Map<String, dynamic> json) =>
      _$UserDataDtoFromJson(json);

  factory UserDataDto.fromDomain(UserData domain) {
    return UserDataDto(
      user_id: domain.user_id,
      role: domain.role,
      access_token: domain.access_token,
      refresh_token: domain.refresh_token,
    );
  }

  const UserDataDto._();

  UserData toDomain() {
    return UserData(
      user_id: user_id,
      role: role,
      access_token: access_token,
      refresh_token: refresh_token,
    );
  }
}
