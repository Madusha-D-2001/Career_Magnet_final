// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'sign_up_request_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$SignUpRequestDtoImpl _$$SignUpRequestDtoImplFromJson(
        Map<String, dynamic> json) =>
    _$SignUpRequestDtoImpl(
      first_name: json['first_name'] as String,
      last_name: json['last_name'] as String,
      email: json['email'] as String,
      contact: json['contact'] as String,
      password: json['password'] as String,
    );

Map<String, dynamic> _$$SignUpRequestDtoImplToJson(
        _$SignUpRequestDtoImpl instance) =>
    <String, dynamic>{
      'first_name': instance.first_name,
      'last_name': instance.last_name,
      'email': instance.email,
      'contact': instance.contact,
      'password': instance.password,
    };
