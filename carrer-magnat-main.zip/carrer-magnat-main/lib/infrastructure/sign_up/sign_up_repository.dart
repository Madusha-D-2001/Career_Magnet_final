import 'package:carrermagnet/domain/core/core_failure.dart';
import 'package:carrermagnet/domain/core/failure.dart';
import 'package:carrermagnet/domain/sign_up/i_sign_up_repository.dart';
import 'package:carrermagnet/domain/sign_up/reqruiter_sign_up_resquest.dart';
import 'package:carrermagnet/domain/sign_up/sign_up_response.dart';
import 'package:carrermagnet/domain/sign_up/sign_up_resquest.dart';
import 'package:carrermagnet/domain/sign_up/user_sign_up_response.dart';
import 'package:carrermagnet/infrastructure/sign_up/sign_up_request_dto.dart';
import 'package:carrermagnet/infrastructure/sign_up/sign_up_response_dto.dart';
import 'package:carrermagnet/utils/log_utils.dart';
import 'package:dartz/dartz.dart';

import '../core/api_helper.dart';
import 'reqruiter_sign_up_resquest_dto.dart';
import 'user_sign_up_response_dto.dart';

class SignUpRepository implements ISignUpRepository {
  SignUpRepository(
    ApiHelper apiHelper,
  ) : _apiHelper = apiHelper;

  final ApiHelper _apiHelper;

  static final LogUtils _logUtils = LogUtils(
    featureName: "SignUp Repository",
    printLog: true,
  );

  // user signUp --------------------------------------------------------------

  @override
  Future<Either<Failure, UserSignUpResponse>> signUp(
      SignUpRequest signUpRequest) async {
    try {
      final res = await _apiHelper.callApi(
        'careermagnet/api/v1/user/user_sign_up',
        method: RestMethods.post,
        data: SignUpRequestDto.fromDomain(signUpRequest).toJson(),
      );

      if (res.success) {
        return right(
            UserSignUpResponseDto.fromJson(res.data as Map<String, dynamic>)
                .toDomain());
      } else {
        return left(
          Failure.core(
            CoreFailure.serverError(res.error ?? res.info!),
          ),
        );
      }
    } catch (e) {
      _logUtils.log("SignUp : Failure: $e");
      return left(
        Failure.core(
          CoreFailure.somethingWentWrong(e),
        ),
      );
    }
  }

  // recruiter Sign Up ----------------------

  @override
  Future<Either<Failure, SignUpResponse>> recruiterSignUp(
      ReqruiterSignUpResquest reqruiterSignUpResquest) async {
    try {
      final res = await _apiHelper.callApi(
        'careermagnet/api/v1/recruiter/recruiterSignUp',
        method: RestMethods.post,
        data: ReqruiterSignUpResquestDto.fromDomain(reqruiterSignUpResquest)
            .toJson(),
      );

      if (res.success) {
        return right(
            SignUpResponseDto.fromJson(res.data as Map<String, dynamic>)
                .toDomain());
      } else {
        return left(
          Failure.core(
            CoreFailure.serverError(res.error ?? res.info!),
          ),
        );
      }
    } catch (e) {
      _logUtils.log("SignUp : Failure: $e");
      return left(
        Failure.core(
          CoreFailure.somethingWentWrong(e),
        ),
      );
    }
  }
}
