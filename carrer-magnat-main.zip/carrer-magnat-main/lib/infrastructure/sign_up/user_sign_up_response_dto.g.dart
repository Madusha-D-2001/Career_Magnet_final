// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'user_sign_up_response_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$UserSignUpResponseDtoImpl _$$UserSignUpResponseDtoImplFromJson(
        Map<String, dynamic> json) =>
    _$UserSignUpResponseDtoImpl(
      code: (json['code'] as num).toInt(),
      message: json['message'] as String,
      data: UserDataDto.fromJson(json['data'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$$UserSignUpResponseDtoImplToJson(
        _$UserSignUpResponseDtoImpl instance) =>
    <String, dynamic>{
      'code': instance.code,
      'message': instance.message,
      'data': instance.data,
    };
