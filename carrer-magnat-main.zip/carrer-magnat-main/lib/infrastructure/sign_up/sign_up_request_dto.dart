import 'package:carrermagnet/domain/sign_up/sign_up_resquest.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'sign_up_request_dto.freezed.dart';
part 'sign_up_request_dto.g.dart';

@freezed
class SignUpRequestDto with _$SignUpRequestDto {
  factory SignUpRequestDto({
    required String first_name,
    required String last_name,
    required String email,
    required String contact,
    required String password,
  }) = _SignUpRequestDto;

  factory SignUpRequestDto.fromJson(Map<String, dynamic> json) =>
      _$SignUpRequestDtoFromJson(json);

  factory SignUpRequestDto.fromDomain(SignUpRequest domain) {
    return SignUpRequestDto(
      first_name: domain.first_name,
      last_name: domain.last_name,
      email: domain.email,
      contact: domain.contact,
      password: domain.password,
    );
  }

  const SignUpRequestDto._();

  SignUpRequest toDomain() {
    return SignUpRequest(
      first_name: first_name,
      last_name: last_name,
      email: email,
      contact: contact,
      password: password,
    );
  }
}
