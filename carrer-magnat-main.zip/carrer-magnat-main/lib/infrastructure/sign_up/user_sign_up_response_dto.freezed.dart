// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'user_sign_up_response_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

UserSignUpResponseDto _$UserSignUpResponseDtoFromJson(
    Map<String, dynamic> json) {
  return _UserSignUpResponseDto.fromJson(json);
}

/// @nodoc
mixin _$UserSignUpResponseDto {
  int get code => throw _privateConstructorUsedError;
  String get message => throw _privateConstructorUsedError;
  UserDataDto get data => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $UserSignUpResponseDtoCopyWith<UserSignUpResponseDto> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $UserSignUpResponseDtoCopyWith<$Res> {
  factory $UserSignUpResponseDtoCopyWith(UserSignUpResponseDto value,
          $Res Function(UserSignUpResponseDto) then) =
      _$UserSignUpResponseDtoCopyWithImpl<$Res, UserSignUpResponseDto>;
  @useResult
  $Res call({int code, String message, UserDataDto data});

  $UserDataDtoCopyWith<$Res> get data;
}

/// @nodoc
class _$UserSignUpResponseDtoCopyWithImpl<$Res,
        $Val extends UserSignUpResponseDto>
    implements $UserSignUpResponseDtoCopyWith<$Res> {
  _$UserSignUpResponseDtoCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? code = null,
    Object? message = null,
    Object? data = null,
  }) {
    return _then(_value.copyWith(
      code: null == code
          ? _value.code
          : code // ignore: cast_nullable_to_non_nullable
              as int,
      message: null == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String,
      data: null == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as UserDataDto,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $UserDataDtoCopyWith<$Res> get data {
    return $UserDataDtoCopyWith<$Res>(_value.data, (value) {
      return _then(_value.copyWith(data: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$UserSignUpResponseDtoImplCopyWith<$Res>
    implements $UserSignUpResponseDtoCopyWith<$Res> {
  factory _$$UserSignUpResponseDtoImplCopyWith(
          _$UserSignUpResponseDtoImpl value,
          $Res Function(_$UserSignUpResponseDtoImpl) then) =
      __$$UserSignUpResponseDtoImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({int code, String message, UserDataDto data});

  @override
  $UserDataDtoCopyWith<$Res> get data;
}

/// @nodoc
class __$$UserSignUpResponseDtoImplCopyWithImpl<$Res>
    extends _$UserSignUpResponseDtoCopyWithImpl<$Res,
        _$UserSignUpResponseDtoImpl>
    implements _$$UserSignUpResponseDtoImplCopyWith<$Res> {
  __$$UserSignUpResponseDtoImplCopyWithImpl(_$UserSignUpResponseDtoImpl _value,
      $Res Function(_$UserSignUpResponseDtoImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? code = null,
    Object? message = null,
    Object? data = null,
  }) {
    return _then(_$UserSignUpResponseDtoImpl(
      code: null == code
          ? _value.code
          : code // ignore: cast_nullable_to_non_nullable
              as int,
      message: null == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String,
      data: null == data
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as UserDataDto,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$UserSignUpResponseDtoImpl extends _UserSignUpResponseDto {
  _$UserSignUpResponseDtoImpl(
      {required this.code, required this.message, required this.data})
      : super._();

  factory _$UserSignUpResponseDtoImpl.fromJson(Map<String, dynamic> json) =>
      _$$UserSignUpResponseDtoImplFromJson(json);

  @override
  final int code;
  @override
  final String message;
  @override
  final UserDataDto data;

  @override
  String toString() {
    return 'UserSignUpResponseDto(code: $code, message: $message, data: $data)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$UserSignUpResponseDtoImpl &&
            (identical(other.code, code) || other.code == code) &&
            (identical(other.message, message) || other.message == message) &&
            (identical(other.data, data) || other.data == data));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, code, message, data);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$UserSignUpResponseDtoImplCopyWith<_$UserSignUpResponseDtoImpl>
      get copyWith => __$$UserSignUpResponseDtoImplCopyWithImpl<
          _$UserSignUpResponseDtoImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$UserSignUpResponseDtoImplToJson(
      this,
    );
  }
}

abstract class _UserSignUpResponseDto extends UserSignUpResponseDto {
  factory _UserSignUpResponseDto(
      {required final int code,
      required final String message,
      required final UserDataDto data}) = _$UserSignUpResponseDtoImpl;
  _UserSignUpResponseDto._() : super._();

  factory _UserSignUpResponseDto.fromJson(Map<String, dynamic> json) =
      _$UserSignUpResponseDtoImpl.fromJson;

  @override
  int get code;
  @override
  String get message;
  @override
  UserDataDto get data;
  @override
  @JsonKey(ignore: true)
  _$$UserSignUpResponseDtoImplCopyWith<_$UserSignUpResponseDtoImpl>
      get copyWith => throw _privateConstructorUsedError;
}
