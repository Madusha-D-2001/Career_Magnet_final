import 'package:carrermagnet/infrastructure/core/providers.dart';
import 'package:carrermagnet/infrastructure/sign_up/sign_up_repository.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

final signUpRepositoryProvider = Provider.autoDispose<SignUpRepository>((ref) {
  final apiHelper = ref.watch(apiHelperProvider);

  return SignUpRepository(apiHelper);
});
