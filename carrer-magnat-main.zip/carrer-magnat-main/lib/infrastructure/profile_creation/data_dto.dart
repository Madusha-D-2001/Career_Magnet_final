import 'package:carrermagnet/domain/profile_creation/data.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'data_dto.freezed.dart';
part 'data_dto.g.dart';

@freezed
class DataDto with _$DataDto {
  factory DataDto({
    required String user_profile_id,
  }) = _DataDto;

  factory DataDto.fromJson(Map<String, dynamic> json) =>
      _$DataDtoFromJson(json);

  factory DataDto.fromDomain(Data domain) {
    return DataDto(
      user_profile_id: domain.user_profile_id,
    );
  }

  DataDto._();

  Data toDomain() {
    return Data(
      user_profile_id: user_profile_id,
    );
  }
}
