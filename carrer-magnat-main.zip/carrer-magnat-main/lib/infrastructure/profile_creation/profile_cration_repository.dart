import 'package:carrermagnet/domain/addNewProject/add_new_project_request.dart';
import 'package:carrermagnet/domain/add_hiring_announcement/add_hiring_announcement_response.dart';
import 'package:carrermagnet/domain/apply_to_vacancy/apply_to_vacancy_request.dart';
import 'package:carrermagnet/domain/core/core_failure.dart';
import 'package:carrermagnet/domain/core/failure.dart';
import 'package:carrermagnet/domain/get_all_applied_vacancies/get_all_applied_vacancies_response.dart';
import 'package:carrermagnet/domain/get_all_job/get_all_job_response.dart';
import 'package:carrermagnet/domain/get_user_profile/get_user_profile_response.dart';
import 'package:carrermagnet/domain/profile_creation/i_profile_creation_repository.dart';
import 'package:carrermagnet/domain/profile_creation/profile_creation_request.dart';
import 'package:carrermagnet/domain/profile_creation/profile_creation_response.dart';
import 'package:carrermagnet/domain/search_jobs/search_jobs_request.dart';
import 'package:carrermagnet/domain/search_jobs/search_jobs_response.dart';
import 'package:carrermagnet/infrastructure/core/api_helper.dart';
import 'package:carrermagnet/infrastructure/get_user_profile/get_user_profile_response_dto.dart';
import 'package:carrermagnet/infrastructure/profile_creation/profile_creation_request_dto.dart';
import 'package:carrermagnet/infrastructure/profile_creation/profile_creation_response_dto.dart';
import 'package:carrermagnet/utils/log_utils.dart';
import 'package:dartz/dartz.dart';

import '../addNewProject/add_new_project_request_dto.dart';
import '../add_hiring_announcement/add_hiring_announcement_response_dto.dart';
import '../apply_to_vacancy/apply_to_vacancy_request_dto.dart';
import '../get_all_applied_vacancies/get_all_applied_vacancies_response_dto.dart';
import '../get_all_job/get_all_job_response_dto.dart';
import '../search_jobs/search_jobs_request_dto.dart';
import '../search_jobs/search_jobs_response_dto.dart';

class ProfileCreationRepository implements IProfileCreationRepository {
  ProfileCreationRepository(
    ApiHelper apiHelper,
  ) : _apiHelper = apiHelper;

  final ApiHelper _apiHelper;

  static final LogUtils _logUtils = LogUtils(
    featureName: "Profile Creation  Repository",
    printLog: true,
  );

  // profile creation ----------------------------------------------------------

  @override
  Future<Either<Failure, ProfileCreationResponse>> profileCreation(
      ProfileCreationRequest profileCreationRequest) async {
    try {
      final res = await _apiHelper.callApi(
        'careermagnet/api/v1/user/user_profile_creation',
        method: RestMethods.post,
        data: ProfileCreationRequestDto.fromDomain(profileCreationRequest)
            .toJson(),
      );

      _logUtils.log("Profile Creation : Response: $res");

      if (res.success) {
        return right(ProfileCreationResponseDto.fromJson(
                res.data as Map<String, dynamic>)
            .toDomain());
      } else {
        return left(
          Failure.core(
            CoreFailure.serverError(res.error ?? res.info!),
          ),
        );
      }
    } catch (e) {
      _logUtils.log("Profile Creation : Failure: $e");
      return left(
        Failure.core(
          CoreFailure.somethingWentWrong(e),
        ),
      );
    }
  }

  // get User Profile Detail ----------------------------------------------------------

  @override
  Future<Either<Failure, GetUserProfileResponse>> getUserProfileDetail(
      String email) async {
    try {
      final res = await _apiHelper.callApi(
        'careermagnet/api/v1/user/get_user_profile?email=$email',
        method: RestMethods.get,
      );

      _logUtils.log("get User Profile Detail : Response: $res");

      if (res.success) {
        return right(
          GetUserPrfileResponseDto.fromJson(res.data as Map<String, dynamic>)
              .toDomain(),
        );
      } else {
        return left(
          Failure.core(
            CoreFailure.serverError(res.error ?? res.info!),
          ),
        );
      }
    } catch (e) {
      _logUtils.log("get User Profile Detail : Failure: $e");
      _logUtils.log("InCatch : Failure: $e");
      return left(
        Failure.core(
          CoreFailure.somethingWentWrong(e),
        ),
      );
    }
  }

  // add new project -----------------------------------------------------------
  @override
  Future<Either<Failure, AddHiringAnnouncementResponse>> addNewProject(
      AddNewProjectRequest addNewProjectRequest) async {
    try {
      final res = await _apiHelper.callApi(
        'careermagnet/api/v1/project/addNewProject',
        method: RestMethods.post,
        data: AddNewProjectRequestDto.fromDomain(addNewProjectRequest).toJson(),
      );

      _logUtils.log("add New Project : Response: $res");

      if (res.success) {
        return right(
          AddHiringAnnouncementResponseDto.fromJson(
                  res.data as Map<String, dynamic>)
              .toDomain(),
        );
      } else {
        return left(
          Failure.core(
            CoreFailure.serverError(res.error ?? res.info!),
          ),
        );
      }
    } catch (e) {
      _logUtils.log("add New Project : Failure: $e");
      _logUtils.log("InCatch : Failure: $e");
      return left(
        Failure.core(
          CoreFailure.somethingWentWrong(e),
        ),
      );
    }
  }

  // remove project ------------------------------------------------------------
  @override
  Future<Either<Failure, AddHiringAnnouncementResponse>> removeProject(
      String projectID) async {
    try {
      final res = await _apiHelper.callApi(
        '/careermagnet/api/v1/project/removeProject?projectID=$projectID',
        method: RestMethods.delete,
      );

      _logUtils.log("remove Project : Response: $res");

      if (res.success) {
        return right(
          AddHiringAnnouncementResponseDto.fromJson(
                  res.data as Map<String, dynamic>)
              .toDomain(),
        );
      } else {
        return left(
          Failure.core(
            CoreFailure.serverError(res.error ?? res.info!),
          ),
        );
      }
    } catch (e) {
      _logUtils.log("remove Project : Failure: $e");
      _logUtils.log("InCatch : Failure: $e");
      return left(
        Failure.core(
          CoreFailure.somethingWentWrong(e),
        ),
      );
    }
  }

  //search Job ----------------------------------------------------------------

  @override
  Future<Either<Failure, GetAllJobResponse>> searchJob(
      SearchJobsRequest searchJobsRequest) async {
    try {
      final res = await _apiHelper.callApi(
        'careermagnet/api/v1/user/searchJobs',
        method: RestMethods.post,
        data: SearchJobsRequestDto.fromDomain(searchJobsRequest).toJson(),
      );

      _logUtils.log("SearchJobsResponse : Response: $res");

      if (res.success) {
        return right(
          GetAllJobResponseDto.fromJson(res.data as Map<String, dynamic>)
              .toDomain(),
        );
      } else {
        return left(
          Failure.core(
            CoreFailure.serverError(res.error ?? res.info!),
          ),
        );
      }
    } catch (e) {
      _logUtils.log("Search Jobs Response : Failure: $e");
      _logUtils.log("InCatch : Failure: $e");
      return left(
        Failure.core(
          CoreFailure.somethingWentWrong(e),
        ),
      );
    }
  }

  // apply Job vacancy ------------------

  @override
  Future<Either<Failure, AddHiringAnnouncementResponse>> applyJob(
      ApplyToVacancyRequest applyToVacancyRequest) async {
    try {
      final res = await _apiHelper.callApi(
        'careermagnet/api/v1/user/applyToVacancy',
        method: RestMethods.post,
        data:
            ApplyToVacancyRequestDto.fromDomain(applyToVacancyRequest).toJson(),
      );

      _logUtils.log("AddHiring Announcement  : Response: $res");

      if (res.success) {
        return right(
          AddHiringAnnouncementResponseDto.fromJson(
                  res.data as Map<String, dynamic>)
              .toDomain(),
        );
      } else {
        return left(
          Failure.core(
            CoreFailure.serverError(res.error ?? res.info!),
          ),
        );
      }
    } catch (e) {
      _logUtils.log("Search Jobs Response  : Failure: $e");
      _logUtils.log("InCatch : Failure: $e");
      return left(
        Failure.core(
          CoreFailure.somethingWentWrong(e),
        ),
      );
    }
  }

  // get All Jobs ---------------------
  @override
  Future<Either<Failure, GetAllJobResponse>> getAllJobs() async {
    try {
      final res = await _apiHelper.callApi(
        'careermagnet/api/v1/user/getAllJobs',
        method: RestMethods.get,
      );

      _logUtils.log("get All Jobs : Response: $res");

      if (res.success) {
        return right(
          GetAllJobResponseDto.fromJson(res.data as Map<String, dynamic>)
              .toDomain(),
        );
      } else {
        return left(
          Failure.core(
            CoreFailure.serverError(res.error ?? res.info!),
          ),
        );
      }
    } catch (e) {
      _logUtils.log("get All Jobs : Failure: $e");
      _logUtils.log("InCatch : Failure: $e");
      return left(
        Failure.core(
          CoreFailure.somethingWentWrong(e),
        ),
      );
    }
  }

  // get All Suggested Jobs ---------------------

  @override
  Future<Either<Failure, GetAllJobResponse>> getAllSuggestedJob(
      String email) async {
    try {
      final res = await _apiHelper.callApi(
        'careermagnet/api/v1/user/get_suggested_jobs?email=$email',
        method: RestMethods.get,
      );

      _logUtils.log("get All Suggested Jobs : Response: $res");

      if (res.success) {
        return right(
          GetAllJobResponseDto.fromJson(res.data as Map<String, dynamic>)
              .toDomain(),
        );
      } else {
        return left(
          Failure.core(
            CoreFailure.serverError(res.error ?? res.info!),
          ),
        );
      }
    } catch (e) {
      _logUtils.log("get All Suggested Jobs : Failure: $e");
      _logUtils.log("InCatch : Failure: $e");
      return left(
        Failure.core(
          CoreFailure.somethingWentWrong(e),
        ),
      );
    }
  }

  @override
  Future<Either<Failure, GetAllAppliedVacanciesResponse>>
      getAllAppliedVacancies(String email) async {
    try {
      final res = await _apiHelper.callApi(
        'careermagnet/api/v1/user/getAllAppliedVacancies?userID=$email',
        method: RestMethods.get,
      );

      _logUtils.log("Get All Applied Vacancies Response: $res");

      if (res.success) {
        return right(
          GetAllAppliedVacanciesResponseDto.fromJson(
                  res.data as Map<String, dynamic>)
              .toDomain(),
        );
      } else {
        return left(
          Failure.core(
            CoreFailure.serverError(res.error ?? res.info!),
          ),
        );
      }
    } catch (e) {
      _logUtils.log("Get All Applied Vacancies Response : Failure: $e");
      _logUtils.log("InCatch : Failure: $e");
      return left(
        Failure.core(
          CoreFailure.somethingWentWrong(e),
        ),
      );
    }
  }
}
