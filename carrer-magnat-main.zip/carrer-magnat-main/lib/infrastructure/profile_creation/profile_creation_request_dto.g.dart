// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'profile_creation_request_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$ProfileCreationRequestDtoImpl _$$ProfileCreationRequestDtoImplFromJson(
        Map<String, dynamic> json) =>
    _$ProfileCreationRequestDtoImpl(
      email: json['email'] as String,
      fullName: json['fullName'] as String,
      address: json['address'] as String,
      birthDay: json['birthDay'] as String,
      profileInfo: json['profileInfo'] as String,
      education: json['education'] as String,
      university: json['university'] as String,
      position: json['position'] as String,
      skillList: json['skillList'] as List<dynamic>,
    );

Map<String, dynamic> _$$ProfileCreationRequestDtoImplToJson(
        _$ProfileCreationRequestDtoImpl instance) =>
    <String, dynamic>{
      'email': instance.email,
      'fullName': instance.fullName,
      'address': instance.address,
      'birthDay': instance.birthDay,
      'profileInfo': instance.profileInfo,
      'education': instance.education,
      'university': instance.university,
      'position': instance.position,
      'skillList': instance.skillList,
    };
