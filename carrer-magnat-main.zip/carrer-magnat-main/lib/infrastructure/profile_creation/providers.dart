import 'package:carrermagnet/infrastructure/core/providers.dart';
import 'package:carrermagnet/infrastructure/profile_creation/profile_cration_repository.dart';

import 'package:hooks_riverpod/hooks_riverpod.dart';

final profileCreationRepositoryProvider =
    Provider.autoDispose<ProfileCreationRepository>((ref) {
  final apiHelper = ref.watch(apiHelperProvider);

  return ProfileCreationRepository(apiHelper);
});
