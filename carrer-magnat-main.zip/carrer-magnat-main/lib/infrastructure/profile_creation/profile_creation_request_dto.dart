import 'package:carrermagnet/domain/profile_creation/profile_creation_request.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kt_dart/kt.dart';

part 'profile_creation_request_dto.freezed.dart';
part 'profile_creation_request_dto.g.dart';

@freezed
class ProfileCreationRequestDto with _$ProfileCreationRequestDto {
  factory ProfileCreationRequestDto({
    required String email,
    required String fullName,
    required String address,
    required String birthDay,
    required String profileInfo,
    required String education,
    required String university,
    required String position,
    required List skillList,
  }) = _ProfileCreationRequestDto;

  factory ProfileCreationRequestDto.fromJson(Map<String, dynamic> json) =>
      _$ProfileCreationRequestDtoFromJson(json);

  const ProfileCreationRequestDto._();

  factory ProfileCreationRequestDto.fromDomain(ProfileCreationRequest domain) {
    return ProfileCreationRequestDto(
      email: domain.email,
      fullName: domain.fullName,
      address: domain.address,
      birthDay: domain.birthDay,
      profileInfo: domain.profileInfo,
      education: domain.education,
      university: domain.university,
      position: domain.position,
      skillList: domain.skillList,
      // skillList: domain.skillList
      //     ?.map((p) => ProfileCreationRequestDto.fromDomain(domain))
      //     .asList(),
    );
  }

  ProfileCreationRequest toDomain() {
    return ProfileCreationRequest(
      email: email,
      fullName: fullName,
      address: address,
      birthDay: birthDay,
      profileInfo: profileInfo,
      education: education,
      university: university,
      position: position,
      skillList: skillList,
      //skillList: skillList!.map((p) => p.toDomain()).toImmutableList(),
    );
  }
}
