// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'profile_creation_response_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$ProfileCreationResponseDtoImpl _$$ProfileCreationResponseDtoImplFromJson(
        Map<String, dynamic> json) =>
    _$ProfileCreationResponseDtoImpl(
      code: (json['code'] as num).toInt(),
      message: json['message'] as String,
      data: DataDto.fromJson(json['data'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$$ProfileCreationResponseDtoImplToJson(
        _$ProfileCreationResponseDtoImpl instance) =>
    <String, dynamic>{
      'code': instance.code,
      'message': instance.message,
      'data': instance.data,
    };
