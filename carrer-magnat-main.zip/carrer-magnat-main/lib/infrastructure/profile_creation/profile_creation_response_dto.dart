import 'package:carrermagnet/domain/profile_creation/profile_creation_response.dart';
import 'package:carrermagnet/infrastructure/profile_creation/data_dto.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'profile_creation_response_dto.freezed.dart';
part 'profile_creation_response_dto.g.dart';

@freezed
class ProfileCreationResponseDto with _$ProfileCreationResponseDto {
  factory ProfileCreationResponseDto({
    required int code,
    required String message,
    required DataDto data,
  }) = _ProfileCreationResponseDto;

  factory ProfileCreationResponseDto.fromJson(Map<String, dynamic> json) =>
      _$ProfileCreationResponseDtoFromJson(json);

  factory ProfileCreationResponseDto.fromDomain(
      ProfileCreationResponse domain) {
    return ProfileCreationResponseDto(
      code: domain.code,
      message: domain.message,
      data: DataDto.fromDomain(domain.data),
    );
  }
  const ProfileCreationResponseDto._();

  ProfileCreationResponse toDomain() {
    return ProfileCreationResponse(
      code: code,
      message: message,
      data: data.toDomain(),
    );
  }
}
