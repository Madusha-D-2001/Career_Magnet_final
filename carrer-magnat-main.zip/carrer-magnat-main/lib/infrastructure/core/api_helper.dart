import 'package:carrermagnet/application/app_state/app_state.dart';
import 'package:carrermagnet/config.dart';
import 'package:carrermagnet/infrastructure/core/base_request_response.dart';
import 'package:carrermagnet/infrastructure/core/providers.dart';
import 'package:carrermagnet/utils/app_utils.dart';
import 'package:carrermagnet/utils/log_utils.dart';
import 'package:dio/dio.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

enum RestMethods { post, get, delete, put }

class ApiHelper {
  ApiHelper(
    this._read, {
    required this.dio,
    required this.appState,
  }) {
    dio.options.baseUrl = Config.serverUrl;
  }

  Dio dio;

  final LogUtils _logUtils = LogUtils(
    featureName: 'ApiHelper',
    printLog: true,
  );

  final Ref _read;
  final AppState appState;

  Future<BaseResponse> callApi<T>(
    String path, {
    dynamic data,
    RestMethods method = RestMethods.get,
    bool isAttachedFiles = false,
  }) async {
    try {
      Response<dynamic> res;

      if (AppUtils.tempToken.isNotEmpty) {
        dio.options.headers.remove('authorization');
        dio.options.headers['authorization'] = "Bearer ${AppUtils.tempToken}";
      } else {
        if (appState.accessToken.isNotEmpty) {
          dio.options.headers.remove('authorization');
          dio.options.headers['authorization'] =
              "Bearer ${_read.read(authTokenProvider)}";
        }
      }

      if (data != null) {
        data = Map<String, dynamic>.from(data);
      } else {
        data = getDefaultParams();
      }

      _logUtils.log("data  :: request :: ${data}");

      if (isAttachedFiles) {
        dio.options.headers['content-type'] = 'multipart/form-data';
      } else {
        dio.options.headers['content-type'] = 'application/json';
      }

      if (method == RestMethods.post) {
        res = await dio.post(path, data: data);
      } else if (method == RestMethods.delete) {
        res = await dio.delete(path,
            queryParameters:
                data != null ? data as Map<String, dynamic> : null);
      } else if (method == RestMethods.put) {
        res = await dio.put(path, data: data);
      } else {
        res = await dio.get(path,
            queryParameters:
                data != null ? data as Map<String, dynamic> : null);
      }

      _logUtils.log("Response  ::::  $path :: response :: ${res}");
      _logUtils.log("Response  ::::  $path :: response :: ${res.data}");

      switch (res.statusCode) {
        case 200:
          _logUtils.log("200 :: $path :: response :: ${res.data}");
          final statusCode = (res.data as Map<String, dynamic>)['statusCode'];
          if (statusCode != null && (statusCode as int) != 200) {
            return BaseResponse.fromErrorResponse(res.data);
          }
          final response = BaseResponse(
            success: true,
            code: 200,
            data: res.data,
          );

          return response;
        case 201:
          _logUtils.log("201 :: $path :: response :: ${res.data}");
          final statusCode = (res.data as Map<String, dynamic>)['statusCode'];
          if (statusCode != null && (statusCode as int) != 201) {
            return BaseResponse.fromErrorResponse(res.data);
          }
          final response = BaseResponse(
            success: true,
            code: 201,
            data: res.data,
          );

          return response;

        default:
          if (res.data is bool || res.data == {}) {
            return BaseResponse(
              success: false,
              code: 404,
              info: "Unexpected Error", //TODO: Localization
              // No localization needed
              error: 'response data missing', //TODO: Localization
            );
          } else {
            return BaseResponse.fromErrorResponse(res.data);
          }
      }
    } on DioException {
      return BaseResponse(
        success: false,
        code: 999,
        info:
            "Your request cannot be processed at this time. Please try again", //TODO: Localization
        // No localization needed
        error:
            'Your request cannot be processed at this time. Please try again',
      );
    } catch (e) {
      _logUtils.log("Response  :::: In Catch ::::::::::::::::::::::::::::");
      return BaseResponse(
        success: false,
        code: 999,
        info:
            "Your request cannot be processed at this time. Please try again", //TODO: Localization
        // No localization needed
        error: Config.isDebugMode ? e.toString() : 'Dio Error',
      );
    }
  }

  Map<String, dynamic> getDefaultParams() {
    return {
      // "country_id": _read.read(appStateNotifierProvider).appConfig.countryId,
    };
  }
}
