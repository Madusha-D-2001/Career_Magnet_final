import 'package:carrermagnet/domain/add_hiring_announcement/add_hiring_announcement_request.dart';
import 'package:carrermagnet/domain/add_hiring_announcement/add_hiring_announcement_response.dart';
import 'package:carrermagnet/domain/core/failure.dart';
import 'package:carrermagnet/domain/get_All_Applied_User_Profiles_By_Hiring_ID/get_All_Applied_User_Profiles_By_Hiring_ID_response.dart';
import 'package:carrermagnet/domain/get_all_posted_jobs_by_recruiter_id/get_all_posted_jobs_by_recruiter_id_request.dart';
import 'package:carrermagnet/domain/recruiter/i_recruiter_repository.dart';
import 'package:carrermagnet/domain/response_To_Application/response_to_application.dart';
import 'package:carrermagnet/infrastructure/core/api_helper.dart';
import 'package:carrermagnet/utils/log_utils.dart';
import 'package:dartz/dartz.dart';

import '../../domain/core/core_failure.dart';
import '../add_hiring_announcement/add_hiring_announcement_request_dto.dart';
import '../add_hiring_announcement/add_hiring_announcement_response_dto.dart';
import '../get_All_Applied_User_Profiles_By_Hiring_ID/get_All_Applied_User_Profiles_By_Hiring_ID_response_dto.dart';
import '../get_all_posted_jobs_by_recruiter_id/get_all_posted_jobs_by_recruiter_id_request_dto.dart';
import '../response_To_Application/response_to_application_dto.dart';

class RecruiterRepository extends IRecruiterRepository {
  RecruiterRepository(
    ApiHelper apiHelper,
  ) : _apiHelper = apiHelper;

  final ApiHelper _apiHelper;

  static final LogUtils _logUtils = LogUtils(
    featureName: "Recruiter Repository",
    printLog: true,
  );

  // add Hiring Announcement ---------------------------------------------------
  @override
  Future<Either<Failure, AddHiringAnnouncementResponse>> addHiringAnnouncement(
      AddHiringAnnouncementRequest addHiringAnnouncementRequest) async {
    try {
      final res = await _apiHelper.callApi(
        'careermagnet/api/v1/recruiter/addHiringAnnouncement',
        method: RestMethods.post,
        data: AddHiringAnnouncementRequestDto.fromDomain(
                addHiringAnnouncementRequest)
            .toJson(),
      );

      _logUtils.log("add Hiring Announcement : Response: $res");

      if (res.success) {
        return right(AddHiringAnnouncementResponseDto.fromJson(
                res.data as Map<String, dynamic>)
            .toDomain());
      } else {
        return left(
          Failure.core(
            CoreFailure.serverError(res.error ?? res.info!),
          ),
        );
      }
    } catch (e) {
      _logUtils.log("add Hiring Announcement : Failure: $e");
      return left(
        Failure.core(
          CoreFailure.somethingWentWrong(e),
        ),
      );
    }
  }

  // get All Posted Jobs By Recruiter ID ---------------------------------------------

  @override
  Future<Either<Failure, GetAllPostedJobsByRecruiterIdRequest>>
      getAllPostedJobsByRecruiterID(String recruiterID) async {
    try {
      final res = await _apiHelper.callApi(
        'careermagnet/api/v1/recruiter/getAllPostedJobsByRecruiterID?recruiterID=$recruiterID',
        method: RestMethods.get,
      );

      _logUtils.log("get All Posted Jobs By Recruiter ID : Response: $res");

      if (res.success) {
        return right(GetAllPostedJobsByRecruiterIdRequestDto.fromJson(
                res.data as Map<String, dynamic>)
            .toDomain());
      } else {
        return left(
          Failure.core(
            CoreFailure.serverError(res.error ?? res.info!),
          ),
        );
      }
    } catch (e) {
      _logUtils.log("get All Posted Jobs By Recruiter ID : Failure: $e");
      return left(
        Failure.core(
          CoreFailure.somethingWentWrong(e),
        ),
      );
    }
  }

  //delete Hiring Announcement -------------------------------------------------

  @override
  Future<Either<Failure, AddHiringAnnouncementResponse>>
      deleteHiringAnnouncement(String hiringID) async {
    try {
      final res = await _apiHelper.callApi(
        'careermagnet/api/v1/recruiter/deleteHiringAnnouncement?hiringID=$hiringID',
        method: RestMethods.delete,
      );

      _logUtils.log("delete Hiring Announcement : Response: $res");

      if (res.success) {
        return right(AddHiringAnnouncementResponseDto.fromJson(
                res.data as Map<String, dynamic>)
            .toDomain());
      } else {
        return left(
          Failure.core(
            CoreFailure.serverError(res.error ?? res.info!),
          ),
        );
      }
    } catch (e) {
      _logUtils.log("delete Hiring Announcement : Failure: $e");
      return left(
        Failure.core(
          CoreFailure.somethingWentWrong(e),
        ),
      );
    }
  }

  // Get All Applied User Profiles By Hiring  -----------------

  @override
  Future<Either<Failure, GetAllAppliedUserProfilesByHiringIdResponse>>
      getAllAppliedUserProfilesByHiringID(String hiringID) async {
    try {
      final res = await _apiHelper.callApi(
        'careermagnet/api/v1/recruiter/getAllAppliedUserProfilesByHiringID?hiringID=$hiringID',
        method: RestMethods.get,
      );

      _logUtils
          .log("Get All Applied User Profiles By Hiring Id Response: $res");

      if (res.success) {
        return right(GetAllAppliedUserProfilesByHiringIdResponseDto.fromJson(
                res.data as Map<String, dynamic>)
            .toDomain());
      } else {
        return left(
          Failure.core(
            CoreFailure.serverError(res.error ?? res.info!),
          ),
        );
      }
    } catch (e) {
      _logUtils
          .log("Get All Applied User Profiles By Hiring Id : : Failure: $e");
      return left(
        Failure.core(
          CoreFailure.somethingWentWrong(e),
        ),
      );
    }
  }

  // send response to ----------------------------------------------------------

  @override
  Future<Either<Failure, AddHiringAnnouncementResponse>> sendReponse(
      ResponseToApplication responseToApplication) async {
    try {
      final res = await _apiHelper.callApi(
        'careermagnet/api/v1/recruiter/responseToApplication',
        method: RestMethods.post,
      );

      _logUtils.log("send Reponse: $res");

      if (res.success) {
        return right(AddHiringAnnouncementResponseDto.fromJson(
                res.data as Map<String, dynamic>)
            .toDomain());
      } else {
        return left(
          Failure.core(
            CoreFailure.serverError(res.error ?? res.info!),
          ),
        );
      }
    } catch (e) {
      _logUtils.log("send Reponse : : Failure: $e");
      return left(
        Failure.core(
          CoreFailure.somethingWentWrong(e),
        ),
      );
    }
  }

  // --------------------------------------
}
