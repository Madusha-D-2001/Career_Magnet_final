import 'package:carrermagnet/infrastructure/core/providers.dart';

import 'package:hooks_riverpod/hooks_riverpod.dart';

import 'recruiter_repository.dart';

final recruiterRepositoryProvider =
    Provider.autoDispose<RecruiterRepository>((ref) {
  final apiHelper = ref.watch(apiHelperProvider);

  return RecruiterRepository(apiHelper);
});
