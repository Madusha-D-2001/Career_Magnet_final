// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'add_new_project_request_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$AddNewProjectRequestDtoImpl _$$AddNewProjectRequestDtoImplFromJson(
        Map<String, dynamic> json) =>
    _$AddNewProjectRequestDtoImpl(
      user_profile_id: json['user_profile_id'] as String,
      project_name: json['project_name'] as String,
      description: json['description'] as String,
      used_skills: (json['used_skills'] as List<dynamic>)
          .map((e) => e as String)
          .toList(),
    );

Map<String, dynamic> _$$AddNewProjectRequestDtoImplToJson(
        _$AddNewProjectRequestDtoImpl instance) =>
    <String, dynamic>{
      'user_profile_id': instance.user_profile_id,
      'project_name': instance.project_name,
      'description': instance.description,
      'used_skills': instance.used_skills,
    };
