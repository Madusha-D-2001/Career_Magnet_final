import 'package:carrermagnet/domain/addNewProject/add_new_project_request.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kt_dart/kt.dart';

part 'add_new_project_request_dto.freezed.dart';
part 'add_new_project_request_dto.g.dart';

@freezed
class AddNewProjectRequestDto with _$AddNewProjectRequestDto {
  factory AddNewProjectRequestDto({
    required String user_profile_id,
    required String project_name,
    required String description,
    required List<String> used_skills,
  }) = _AddNewProjectRequestDto;

  factory AddNewProjectRequestDto.fromJson(Map<String, dynamic> json) =>
      _$AddNewProjectRequestDtoFromJson(json);

  factory AddNewProjectRequestDto.fromDomain(AddNewProjectRequest domain) {
    return AddNewProjectRequestDto(
      user_profile_id: domain.user_profile_id,
      project_name: domain.project_name,
      description: domain.description,
      used_skills: domain.used_skills.asList(),
    );
  }

  const AddNewProjectRequestDto._();

  AddNewProjectRequest toDomain() {
    return AddNewProjectRequest(
      user_profile_id: user_profile_id,
      project_name: project_name,
      description: description,
      used_skills: used_skills.toImmutableList(),
    );
  }
}
