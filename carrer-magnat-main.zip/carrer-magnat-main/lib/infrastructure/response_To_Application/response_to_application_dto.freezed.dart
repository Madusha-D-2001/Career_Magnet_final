// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'response_to_application_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

ResponseToApplicationDto _$ResponseToApplicationDtoFromJson(
    Map<String, dynamic> json) {
  return _ResponseToApplicationDto.fromJson(json);
}

/// @nodoc
mixin _$ResponseToApplicationDto {
  String get hiringID => throw _privateConstructorUsedError;
  String get userID => throw _privateConstructorUsedError;
  String get companyRespondStatus => throw _privateConstructorUsedError;
  String get message => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ResponseToApplicationDtoCopyWith<ResponseToApplicationDto> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ResponseToApplicationDtoCopyWith<$Res> {
  factory $ResponseToApplicationDtoCopyWith(ResponseToApplicationDto value,
          $Res Function(ResponseToApplicationDto) then) =
      _$ResponseToApplicationDtoCopyWithImpl<$Res, ResponseToApplicationDto>;
  @useResult
  $Res call(
      {String hiringID,
      String userID,
      String companyRespondStatus,
      String message});
}

/// @nodoc
class _$ResponseToApplicationDtoCopyWithImpl<$Res,
        $Val extends ResponseToApplicationDto>
    implements $ResponseToApplicationDtoCopyWith<$Res> {
  _$ResponseToApplicationDtoCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? hiringID = null,
    Object? userID = null,
    Object? companyRespondStatus = null,
    Object? message = null,
  }) {
    return _then(_value.copyWith(
      hiringID: null == hiringID
          ? _value.hiringID
          : hiringID // ignore: cast_nullable_to_non_nullable
              as String,
      userID: null == userID
          ? _value.userID
          : userID // ignore: cast_nullable_to_non_nullable
              as String,
      companyRespondStatus: null == companyRespondStatus
          ? _value.companyRespondStatus
          : companyRespondStatus // ignore: cast_nullable_to_non_nullable
              as String,
      message: null == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ResponseToApplicationDtoImplCopyWith<$Res>
    implements $ResponseToApplicationDtoCopyWith<$Res> {
  factory _$$ResponseToApplicationDtoImplCopyWith(
          _$ResponseToApplicationDtoImpl value,
          $Res Function(_$ResponseToApplicationDtoImpl) then) =
      __$$ResponseToApplicationDtoImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String hiringID,
      String userID,
      String companyRespondStatus,
      String message});
}

/// @nodoc
class __$$ResponseToApplicationDtoImplCopyWithImpl<$Res>
    extends _$ResponseToApplicationDtoCopyWithImpl<$Res,
        _$ResponseToApplicationDtoImpl>
    implements _$$ResponseToApplicationDtoImplCopyWith<$Res> {
  __$$ResponseToApplicationDtoImplCopyWithImpl(
      _$ResponseToApplicationDtoImpl _value,
      $Res Function(_$ResponseToApplicationDtoImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? hiringID = null,
    Object? userID = null,
    Object? companyRespondStatus = null,
    Object? message = null,
  }) {
    return _then(_$ResponseToApplicationDtoImpl(
      hiringID: null == hiringID
          ? _value.hiringID
          : hiringID // ignore: cast_nullable_to_non_nullable
              as String,
      userID: null == userID
          ? _value.userID
          : userID // ignore: cast_nullable_to_non_nullable
              as String,
      companyRespondStatus: null == companyRespondStatus
          ? _value.companyRespondStatus
          : companyRespondStatus // ignore: cast_nullable_to_non_nullable
              as String,
      message: null == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ResponseToApplicationDtoImpl extends _ResponseToApplicationDto {
  _$ResponseToApplicationDtoImpl(
      {required this.hiringID,
      required this.userID,
      required this.companyRespondStatus,
      required this.message})
      : super._();

  factory _$ResponseToApplicationDtoImpl.fromJson(Map<String, dynamic> json) =>
      _$$ResponseToApplicationDtoImplFromJson(json);

  @override
  final String hiringID;
  @override
  final String userID;
  @override
  final String companyRespondStatus;
  @override
  final String message;

  @override
  String toString() {
    return 'ResponseToApplicationDto(hiringID: $hiringID, userID: $userID, companyRespondStatus: $companyRespondStatus, message: $message)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ResponseToApplicationDtoImpl &&
            (identical(other.hiringID, hiringID) ||
                other.hiringID == hiringID) &&
            (identical(other.userID, userID) || other.userID == userID) &&
            (identical(other.companyRespondStatus, companyRespondStatus) ||
                other.companyRespondStatus == companyRespondStatus) &&
            (identical(other.message, message) || other.message == message));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode =>
      Object.hash(runtimeType, hiringID, userID, companyRespondStatus, message);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ResponseToApplicationDtoImplCopyWith<_$ResponseToApplicationDtoImpl>
      get copyWith => __$$ResponseToApplicationDtoImplCopyWithImpl<
          _$ResponseToApplicationDtoImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ResponseToApplicationDtoImplToJson(
      this,
    );
  }
}

abstract class _ResponseToApplicationDto extends ResponseToApplicationDto {
  factory _ResponseToApplicationDto(
      {required final String hiringID,
      required final String userID,
      required final String companyRespondStatus,
      required final String message}) = _$ResponseToApplicationDtoImpl;
  _ResponseToApplicationDto._() : super._();

  factory _ResponseToApplicationDto.fromJson(Map<String, dynamic> json) =
      _$ResponseToApplicationDtoImpl.fromJson;

  @override
  String get hiringID;
  @override
  String get userID;
  @override
  String get companyRespondStatus;
  @override
  String get message;
  @override
  @JsonKey(ignore: true)
  _$$ResponseToApplicationDtoImplCopyWith<_$ResponseToApplicationDtoImpl>
      get copyWith => throw _privateConstructorUsedError;
}
