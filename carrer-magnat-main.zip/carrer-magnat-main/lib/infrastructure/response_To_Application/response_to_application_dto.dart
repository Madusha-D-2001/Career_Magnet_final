import 'package:carrermagnet/domain/response_To_Application/response_to_application.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'response_to_application_dto.freezed.dart';
part 'response_to_application_dto.g.dart';

@freezed
class ResponseToApplicationDto with _$ResponseToApplicationDto {
  factory ResponseToApplicationDto({
    required String hiringID,
    required String userID,
    required String companyRespondStatus,
    required String message,
  }) = _ResponseToApplicationDto;

  factory ResponseToApplicationDto.fromJson(Map<String, dynamic> json) =>
      _$ResponseToApplicationDtoFromJson(json);

  factory ResponseToApplicationDto.fromDomain(ResponseToApplication domain) {
    return ResponseToApplicationDto(
      hiringID: domain.hiringID,
      userID: domain.userID,
      companyRespondStatus: domain.companyRespondStatus,
      message: domain.message,
    );
  }

  const ResponseToApplicationDto._();

  ResponseToApplication toDomain() {
    return ResponseToApplication(
      hiringID: hiringID,
      userID: userID,
      companyRespondStatus: companyRespondStatus,
      message: message,
    );
  }
}
