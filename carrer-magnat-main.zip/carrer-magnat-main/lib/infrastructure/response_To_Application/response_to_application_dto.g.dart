// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'response_to_application_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$ResponseToApplicationDtoImpl _$$ResponseToApplicationDtoImplFromJson(
        Map<String, dynamic> json) =>
    _$ResponseToApplicationDtoImpl(
      hiringID: json['hiringID'] as String,
      userID: json['userID'] as String,
      companyRespondStatus: json['companyRespondStatus'] as String,
      message: json['message'] as String,
    );

Map<String, dynamic> _$$ResponseToApplicationDtoImplToJson(
        _$ResponseToApplicationDtoImpl instance) =>
    <String, dynamic>{
      'hiringID': instance.hiringID,
      'userID': instance.userID,
      'companyRespondStatus': instance.companyRespondStatus,
      'message': instance.message,
    };
