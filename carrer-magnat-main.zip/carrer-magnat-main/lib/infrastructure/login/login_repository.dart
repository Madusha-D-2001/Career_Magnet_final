import 'package:carrermagnet/domain/core/core_failure.dart';
import 'package:carrermagnet/domain/core/failure.dart';
import 'package:carrermagnet/domain/login/i_login_repository.dart';
import 'package:carrermagnet/domain/login/login_request.dart';
import 'package:carrermagnet/domain/login/login_response.dart';
import 'package:carrermagnet/infrastructure/core/api_helper.dart';
import 'package:carrermagnet/infrastructure/login/login_request_dto.dart';
import 'package:carrermagnet/infrastructure/login/login_response_dto.dart';
import 'package:carrermagnet/utils/log_utils.dart';
import 'package:dartz/dartz.dart';

class LoginRepository implements ILoginRepository {
  LoginRepository(
    ApiHelper apiHelper,
  ) : _apiHelper = apiHelper;
  final ApiHelper _apiHelper;

  static final LogUtils _logUtils = LogUtils(
    featureName: "LoginRepository",
    printLog: true,
  );

  @override
  Future<Either<Failure, LoginResponse>> login(
      LoginRequest loginRequest) async {
    try {
      final res = await _apiHelper.callApi(
        'careermagnet/api/v1/auth/login',
        method: RestMethods.post,
        data: LoginRequestDto.fromDomain(loginRequest).toJson(),
      );

      if (res.success) {
        return right(LoginResponseDto.fromJson(res.data as Map<String, dynamic>)
            .toDomain());
      } else {
        return left(
          Failure.core(
            CoreFailure.serverError(res.error ?? res.info!),
          ),
        );
      }
    } catch (e) {
      _logUtils.log("login : Failure: $e");
      return left(
        Failure.core(
          CoreFailure.somethingWentWrong(e),
        ),
      );
    }
  }
}
