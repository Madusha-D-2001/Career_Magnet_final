import 'package:carrermagnet/infrastructure/core/providers.dart';
import 'package:carrermagnet/infrastructure/login/login_repository.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

final loginRepositoryProvider = Provider.autoDispose<LoginRepository>((ref) {
  final apiHelper = ref.watch(apiHelperProvider);

  return LoginRepository(apiHelper);
});
