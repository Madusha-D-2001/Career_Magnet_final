import 'package:carrermagnet/domain/login/data.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'data_dto.freezed.dart';
part 'data_dto.g.dart';

@freezed
class DataDto with _$DataDto {
  factory DataDto({
    required String user_id,
    required String role,
    required String access_token,
    required String refresh_token,
  }) = _DataDto;

  factory DataDto.fromJson(Map<String, dynamic> json) =>
      _$DataDtoFromJson(json);

  factory DataDto.fromDomain(Data domain) {
    return DataDto(
      user_id: domain.user_id,
      role: domain.role,
      access_token: domain.access_token,
      refresh_token: domain.refresh_token,
    );
  }

  const DataDto._();

  Data toDomain() {
    return Data(
      user_id: user_id,
      role: role,
      access_token: access_token,
      refresh_token: refresh_token,
    );
  }
}
