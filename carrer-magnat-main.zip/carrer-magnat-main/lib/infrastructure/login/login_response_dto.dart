import 'package:carrermagnet/domain/login/login_response.dart';
import 'package:carrermagnet/infrastructure/login/data_dto.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'login_response_dto.freezed.dart';
part 'login_response_dto.g.dart';

@freezed
class LoginResponseDto with _$LoginResponseDto {
  factory LoginResponseDto({
    required int code,
    required String message,
    required DataDto data,
  }) = _LoginResponseDto;

  factory LoginResponseDto.fromJson(Map<String, dynamic> json) =>
      _$LoginResponseDtoFromJson(json);

  factory LoginResponseDto.fromDomain(LoginResponse domain) {
    return LoginResponseDto(
      code: domain.code,
      message: domain.message,
      data: DataDto.fromDomain(domain.data),
    );
  }

  const LoginResponseDto._();

  LoginResponse toDomain() {
    return LoginResponse(
      code: code,
      message: message,
      data: data.toDomain(),
    );
  }
}
