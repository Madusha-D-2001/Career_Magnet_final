// import '../domain/core/failure.dart';
// import '../l10n/l10n.dart';

// //TODO: Localization

// extension FailureX on Failure {
//   String toErrorString(AppLocalizations localizations) {
//     return when(
//       authentication: (failure) => localizations.failuresAuthError,
//       storage: (storageFailure) => localizations.failuresStorageError,
//       network: (failure) => localizations.failuresNetwork,
//       core: (coreFailure) => coreFailure.when(
//         serverError: (message) => "Server Error",
//         unexpected: () => localizations.failuresUnexpected,
//         somethingWentWrong: (e) => e.toString(),
//         ignoreWarning: () => '',
//         userAlreadyExitsError: (e) => localizations.failuresUserAlreadyExists,
//         paymentError: (message, details) => "$message $details",
//       ),
//     );
//   }
// }
