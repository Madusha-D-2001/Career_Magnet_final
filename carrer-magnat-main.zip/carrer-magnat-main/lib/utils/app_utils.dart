mixin AppUtils {
  static String tempToken = "";
}
