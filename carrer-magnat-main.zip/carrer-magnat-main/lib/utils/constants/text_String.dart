class GText {
// login screen
  static const String userName = "User Name";
  static const String phoneNumber = "Phone Number";
  static const String password = "Password";
  static const String confirmPassword = "Confirm Password";

  static const String firstName = "First Name";
  static const String lastName = "Last Name";
  static const String email = "E-mail";
  static const String newPassword = "New Password";
  static const String phoneNo = "Phone Number";
  static const String remeberMe = "Remember Me";
  static const String forgetPassword = "Forget Password";
  static const String signIn = "Sign In";
  static const String createAccount = "Create Account";
  static const String alreadyHaveAccount = "Already Have Account";

  // recycle guide line title
  static const String glass = "Glass Recycling";
  static const String metal = "Metal Recycling";
  static const String paper = "Paper Recycling";
  static const String ewaste = "E-Waste Recycling";
  static const String plastic = "Plastic Recycling";
  static const String organic = "Organic Recycling";

  // recycle guide description

  static const String glassSub = "Rinse, Remove Lids, Recycle Clean Glass";
  static const String metalSub =
      "Separate Metals, Flatten Cans, Clean for recycling";
  static const String paperSub =
      "Remove non-paper items, Flatten, Keep Clean for recycling.";
  static const String ewasteSub =
      "Layer Waste, Aerate, Use Compost for Sustainability";
  static const String plesticSub =
      "Rinse, Check Symbols, Flatten for efficient recycling.";
  static const String organicSub =
      "Layer Waste, Aerate, Use Compost for Sustainability.";
}
