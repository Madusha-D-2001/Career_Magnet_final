import 'package:flutter/material.dart';

class JColors {
  static const Color splashBackgroundColor = Color.fromRGBO(31, 49, 157, 1);

  //splash screen
}
