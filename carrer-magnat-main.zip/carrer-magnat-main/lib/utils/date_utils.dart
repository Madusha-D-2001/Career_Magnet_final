import 'package:intl/intl.dart';

mixin LocalDateUtils {
  static DateFormat showingFormat = DateFormat("MMM dd, yyyy");
  static DateFormat timeFormat = DateFormat("hh:mm a");

  static DateTime getDateFromDateAndTime(String date, String time) {
    return DateFormat("MMM d, yyyy h:mm a").parse("$date $time");
  }

  static String convertDateFormat(DateTime date) {
    String formattedDate = DateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'").format(date);

    return formattedDate;
  }

  static String getFormatedDate(String date) {
    if (date.isNotEmpty) {
      final dateArray = date.split("-");
      return "${dateArray[0]}-${dateArray[1]}-${dateArray[2].split("T")[0]} ${dateArray[2].split("T")[1].split(".")[0]}";
    }
    return DateFormat("yyyy-MM-dd hh:mm:ss").format(DateTime.now());
  }
}
