package com.example.carrermagnet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
